﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.Repositories
{
    public class WarehouseRepository : IWarehouseRepository
    {
        private readonly AssetFlowDbContext _context;
        private readonly IAssetLogRepository _log;


        public WarehouseRepository(IAssetLogRepository assetLogRepository, AssetFlowDbContext context)
        {
            _context = context;
            _log = assetLogRepository;
        }

        public async Task<IReadOnlyList<WarehouseCustomerClearance>> GetClearanceAfterIdAsync(long lastId)
        {
            return await _context.WarehouseCustomerClearances
            .AsNoTracking()
            .Where(x => x.WarehouseCustomerClearanceId > lastId)
            .OrderBy(x => x.receiveTime).ThenBy(x => x.WarehouseCustomerClearanceId).ThenBy(x => x.Id)
            .ToListAsync();
        }

        public async Task<IReadOnlyList<WarehouseCustomerClearance>> GetClearanceAfterIdAsync(long lastId, long uniqueId, long warehouseId)
        {
            return await _context.WarehouseCustomerClearances
                          .AsNoTracking()
                          .Where(x => x.WarehouseCustomerClearanceId > lastId)
                          .Where(x =>
                          x.warehouseGroupID == warehouseId &&
                          x.uniqueID == uniqueId)
                          .OrderBy(x => x.receiveTime).ThenBy(x => x.WarehouseCustomerClearanceId).ThenBy(x => x.Id)
                          .ToListAsync();

        }

        public async Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId)
        {
            return await _context.WarehouseCustomerEntrances
         .AsNoTracking()
         .Where(x => x.WarehouseCustomerEntranceId > lastId)
         .OrderBy(x => x.receiveTime).ThenBy(x => x.WarehouseCustomerEntranceId).ThenBy(x => x.Id)
         .ToListAsync();
        }

        public async Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId, long uniqueId, long warehouseId)
        {
            return await _context.WarehouseCustomerEntrances
                          .AsNoTracking()
                          .Where(x => x.WarehouseCustomerEntranceId > lastId)
                          .Where(x =>
                          x.warehouseGroupID == warehouseId &&
                          x.uniqueID == uniqueId)
                          .OrderBy(x => x.receiveTime).ThenBy(x => x.WarehouseCustomerEntranceId).ThenBy(x => x.Id)
                          .ToListAsync();
        }













        public async Task BulkUpsertWarehouseCustomerClearanceAsync(IReadOnlyCollection<WarehouseCustomerClearance> entities)
        {
            if (entities == null || entities.Count == 0) return;

            var config = new BulkConfig
            {
                BatchSize = 5000,
                UseTempDB = true,
                UpdateByProperties =
                [
                    nameof(WarehouseCustomerClearance.WarehouseCustomerClearanceId)
                ]
            };

            await using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                await _context.BulkInsertOrUpdateAsync(entities, config);
                await tx.CommitAsync();
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                _log.LogIt(ex);
                throw;
            }
        }



        public async Task BulkUpsertWarehouseCustomerEntranceAsync(IReadOnlyCollection<WarehouseCustomerEntrance> entities)
        {
            if (entities == null || entities.Count == 0) return;

            var config = new BulkConfig
            {
                BatchSize = 5000,
                UseTempDB = true,
                UpdateByProperties =
                [
                       nameof(WarehouseCustomerEntrance.WarehouseCustomerEntranceId)
                ]
            };

            await using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                await _context.BulkInsertOrUpdateAsync(entities, config);
                await tx.CommitAsync();
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                _log.LogIt(ex);
                throw;
            }
        }
    }
}
