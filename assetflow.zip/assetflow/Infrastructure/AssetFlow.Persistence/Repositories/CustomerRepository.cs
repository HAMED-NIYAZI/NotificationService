﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Persistence.DbContext;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Headers;

namespace AssetFlow.Persistence.Repositories;



public sealed class CustomerRepository : ICustomerRepository
{
    private readonly AssetFlowDbContext _context;

    private static CustomerCache _cache = CustomerCache.Empty;

    private static long _lastRefreshTicks;

    private static readonly TimeSpan CacheDuration =
        TimeSpan.FromMinutes(10);
    private static readonly JsonSerializerSettings _jsonSettings = new JsonSerializerSettings
    {
        NullValueHandling = NullValueHandling.Ignore,
        DateFormatHandling = DateFormatHandling.IsoDateFormat
    };
    private static readonly SemaphoreSlim RefreshLock = new(1, 1);
    private readonly HttpClient _httpClient;

    public CustomerRepository(AssetFlowDbContext context)
    {
        _context = context;

        var handler = new HttpClientHandler
        {
            AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
        };
        _httpClient = new HttpClient(handler)
        {
            Timeout = TimeSpan.FromSeconds(AppConfig.UniqueCodeApiSettings.RequestTimeoutSeconds)
        };
        _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        _httpClient.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
        _httpClient.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("deflate"));

    }

    public long? GetUniqueID(long? customerId)
    {
        EnsureCacheLoaded();

        if (customerId is null)
            return null;

        var cache = Volatile.Read(ref _cache);

        return cache.UniqueIdByCustomerId.TryGetValue(
            customerId.Value,
            out var uniqueId)
            ? uniqueId
            : null;
    }

    public long? GetCustomerId(long? uniqueId)
    {
        EnsureCacheLoaded();

        if (uniqueId is null)
            return null;

        var cache = Volatile.Read(ref _cache);

        long? res= cache.CustomerIdByUniqueId.TryGetValue(
            uniqueId.Value,
            out var customerId)
            ? customerId
            : 0;


        return res;
    }

    public long? CustomerID_IMEByUniqueID(long? uniqueId)
    {
        EnsureCacheLoaded();

        if (uniqueId is null)
            return null;

        var cache = Volatile.Read(ref _cache);

        return cache.CustomerImeByUniqueId.TryGetValue(
            uniqueId.Value,
            out var customerIme)
            ? customerIme
            : null;
    }

    public long? CustomerID_IMEByCustomerId(long? customerId)
    {
        EnsureCacheLoaded();

        if (customerId is null)
            return null;

        var cache = Volatile.Read(ref _cache);

        return cache.CustomerImeByCustomerId.TryGetValue(
            customerId.Value,
            out var customerIme)
            ? customerIme
            : null;
    }

    private void EnsureCacheLoaded()
    {
        var lastRefresh = new DateTime(
            Volatile.Read(ref _lastRefreshTicks),
            DateTimeKind.Utc);

        var needsRefresh =
            _cache == CustomerCache.Empty ||
            DateTime.UtcNow - lastRefresh >= CacheDuration;

        if (!needsRefresh)
            return;

        // این متد sync است ولی فقط برای جلوگیری از
        // multiple refresh استفاده می‌شود.
        RefreshCache();
    }

    private void RefreshCache()
    {
        if (!RefreshLock.Wait(0))
            return;

        try
        {
            var lastRefresh = new DateTime(
                Volatile.Read(ref _lastRefreshTicks),
                DateTimeKind.Utc);

            // Thread دیگری ممکن است قبل از ما Cache را Refresh کرده باشد.
            if (_cache != CustomerCache.Empty &&
                DateTime.UtcNow - lastRefresh < CacheDuration)
            {
                return;
            }

            ReloadCustomerMappingsAsync()
                .GetAwaiter()
                .GetResult();
        }
        finally
        {
            RefreshLock.Release();
        }
    }

    public async Task ReloadCustomerMappingsAsync()
    {
        var customers = await _context.Customers
            .AsNoTracking()
            .Select(x => new CustomerMapping
            {
                CustomerId = x.CustomerID,
                UniqueId = x.UniqueID,
                CustomerIme = x.CustomerID_IME
            })
            .ToListAsync();

        var uniqueIdByCustomerId =
            new Dictionary<long, long?>(customers.Count);

        var customerIdByUniqueId =
            new Dictionary<long, long>(customers.Count);

        var customerImeByCustomerId =
            new Dictionary<long, long?>(customers.Count);

        var customerImeByUniqueId =
            new Dictionary<long, long>(customers.Count);

        foreach (var customer in customers)
        {
            uniqueIdByCustomerId[customer.CustomerId] =
                customer.UniqueId;

            customerImeByCustomerId[customer.CustomerId] =
                customer.CustomerIme;

            if (customer.UniqueId.HasValue)
            {
                customerIdByUniqueId[customer.UniqueId.Value] =
                    customer.CustomerId;

                if (customer.CustomerIme.HasValue)
                {
                    customerImeByUniqueId[customer.UniqueId.Value] =
                        customer.CustomerIme.Value;
                }
            }
        }

        var newCache = new CustomerCache(
            uniqueIdByCustomerId,
            customerIdByUniqueId,
            customerImeByCustomerId,
            customerImeByUniqueId);

        // Cache جدید کامل آماده شده.
        // بعد از این خط همه درخواست‌ها Cache جدید را می‌بینند.
        Volatile.Write(ref _cache, newCache);

        Volatile.Write(
            ref _lastRefreshTicks,
            DateTime.UtcNow.Ticks);
    }


    public async Task<long> GetUniqeIdFromApi(long customerId)
    {
        try
        {
            ApiTokenDto.TokenUniqueCodeApp = null;
            ApiTokenDto.TokenCustomerApp = null;

            string url = $"https://customerapp.ime.co.ir:20200/odata/exchange/derivativesMinimalCustomer?$select=Id&$filter=(DerivativeCode eq '{customerId}')";
            await GetTokenCustomerApp();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ApiTokenDto.TokenCustomerApp);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode) throw new HttpRequestException($"API request failed: {(int)response.StatusCode}");

            var odataResponse = JsonConvert.DeserializeObject<ODataResponse<CustomerCodeItemDto>>(content, _jsonSettings);
            var data = odataResponse?.Value ?? new List<CustomerCodeItemDto>();

            var customerIme = data[0].Id;


            url = $"https://uniquecode.ime.co.ir:20200/odata/exchange/Aggregated?$select=Id,Name,UpdatedDate,ExternalId,PrivateId,DisplayCode,ShadowEntityTypeId&$filter=(IsFinancialMarket eq true OR IsDerivativesMarket eq true) and ( PrivateId eq {customerIme})";
            await GetTokenUniqueCodeApp();
            request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ApiTokenDto.TokenUniqueCodeApp);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            response = await _httpClient.SendAsync(request);
            content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode) throw new HttpRequestException($"API request failed: {(int)response.StatusCode}");

            odataResponse = JsonConvert.DeserializeObject<ODataResponse<CustomerCodeItemDto>>(content, _jsonSettings);
            data = odataResponse?.Value ?? new List<CustomerCodeItemDto>();
            {

                var firstData = data[0];


                var existingCustomer = _context.Customers.Local.FirstOrDefault(c => c.CustomerID == customerId)
                                       ?? await _context.Customers.FirstOrDefaultAsync(c => c.CustomerID == customerId);

                if (existingCustomer != null)
                {
                    existingCustomer.RecTime = firstData.UpdatedDate;
                    existingCustomer.CustomerID_IME = firstData.CustomerID_IME;
                    existingCustomer.DisplayCode = firstData.DisplayCode;
                    existingCustomer.UniqueID = firstData.Id;
                    existingCustomer.CustomerName = firstData.Name;
                    existingCustomer.NationalID = firstData.NationalID;
                    existingCustomer.CustomerType = (short)firstData.ShadowEntityTypeId;
                    existingCustomer.Status = 'A';
                }
                else
                {
                    await _context.Customers.AddAsync(new Domain.Entities.Customer
                    {
                        CustomerID = customerId,
                        RecTime = firstData.UpdatedDate,
                        CustomerID_IME = firstData.CustomerID_IME,
                        DisplayCode = firstData.DisplayCode,
                        UniqueID = firstData.Id,
                        CustomerName = firstData.Name,
                        NationalID = firstData.NationalID,
                        CustomerType = (short)firstData.ShadowEntityTypeId,
                        Status = 'A'
                    });
                }

                await _context.SaveChangesAsync();
            }

            return data[0].Id;
        }
        catch (Exception ex)
        {
            ApiTokenDto.TokenUniqueCodeApp = null;
            return 0;
        }


        async Task GetTokenUniqueCodeApp()
        {
            if (!string.IsNullOrEmpty(ApiTokenDto.TokenUniqueCodeApp)) return;

            var authUrl = AppConfig.UniqueCodeApiSettings.IME_AuthUrl;
            var response = new HttpResponseMessage();

            try
            {
                var formContent = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("client_id", AppConfig.UniqueCodeApiSettings.IME_ClientId),
                    new KeyValuePair<string, string>("client_secret", AppConfig.UniqueCodeApiSettings.IME_ClientSecret),
                    new KeyValuePair<string, string>("grant_type",  AppConfig.UniqueCodeApiSettings.IME_Grant_Type),
                    new KeyValuePair<string, string>("scope", AppConfig.UniqueCodeApiSettings.IME_Scope)
                });

                response = await _httpClient.PostAsync(authUrl, formContent);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {

                    ApiTokenDto.TokenUniqueCodeApp = null;
                }

                var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(responseBody);

                ApiTokenDto.TokenUniqueCodeApp = tokenResponse.AccessToken;





            }
            catch (Exception ex)
            {
                ApiTokenDto.TokenUniqueCodeApp = null;


            }
        }

        async Task GetTokenCustomerApp()
        {
            if (!string.IsNullOrEmpty(ApiTokenDto.TokenCustomerApp)) return;

            var authUrl = AppConfig.UniqueCodeApiSettings.IME_AuthUrl;
            var response = new HttpResponseMessage();

            try
            {
                var formContent = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("client_id", AppConfig.UniqueCodeApiSettings.IME_ClientId_CustomerApp),
                    new KeyValuePair<string, string>("client_secret", AppConfig.UniqueCodeApiSettings.IME_ClientSecret_CustomerApp),
                    new KeyValuePair<string, string>("grant_type",  AppConfig.UniqueCodeApiSettings.IME_Grant_Type_CustomerApp),
                    new KeyValuePair<string, string>("scope", AppConfig.UniqueCodeApiSettings.IME_Scope_CustomerApp)
                });

                response = await _httpClient.PostAsync(authUrl, formContent);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {

                    ApiTokenDto.TokenCustomerApp = null;
                }

                var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(responseBody);

                ApiTokenDto.TokenCustomerApp = tokenResponse.AccessToken;


            }
            catch (Exception ex)
            {
                ApiTokenDto.TokenCustomerApp = null;

            }
        }

    }

    public static class ApiTokenDto
    {
        public static string? TokenUniqueCodeApp { get; set; }
        public static string? TokenCustomerApp { get; set; }
        //public static DateTime ExpiresAt { get; set; }
        //public static DateTime CreatedAt { get; set; }
        //public static bool IsActive { get; set; }
    }

    public class TokenResponse
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }
    }
    public static class AppConfig
    {
        public static UniqueCodeApiSettings UniqueCodeApiSettings { get; set; } = new();
    }

    public class UniqueCodeApiSettings
    {
        //client_credentials

        public string IME_ClientId { get; set; } = string.Empty;
        public string IME_ClientSecret { get; set; } = string.Empty;
        public string IME_Scope { get; set; } = string.Empty;
        public string IME_Grant_Type { get; set; } = string.Empty;
        public string IME_SsoUrl { get; set; } = string.Empty;


        public string IME_ClientId_CustomerApp { get; set; } = string.Empty;
        public string IME_ClientSecret_CustomerApp { get; set; } = string.Empty;
        public string IME_Scope_CustomerApp { get; set; } = string.Empty;
        public string IME_Grant_Type_CustomerApp { get; set; } = string.Empty;




        public string IME_BaseUrl { get; set; } = string.Empty;
        public string IME_AuthUrl { get; set; } = string.Empty;
        public string IME_CustomerCodeUrl { get; set; } = string.Empty;
        public string IME_ShadowEntityTypeUrl { get; set; } = string.Empty;
        public string IME_CustomerCodeQuery { get; set; } = string.Empty;
        public string IME_CustomerCodeSelectQuery { get; set; } = string.Empty;
        public string IME_CustomerCodeByIdPath { get; set; } = string.Empty;
        public string IME_CustomerDerivativesUrl { get; set; } = string.Empty;



        public string IME_SectorFundDerivativesUrl { get; set; } = string.Empty;



        public int RequestTimeoutSeconds { get; set; }

    }

    private sealed class CustomerMapping
    {
        public long CustomerId { get; init; }

        public long? UniqueId { get; init; }

        public long? CustomerIme { get; init; }
    }

    private sealed class CustomerCache
    {
        public static readonly CustomerCache Empty =
            new(
                new Dictionary<long, long?>(),
                new Dictionary<long, long>(),
                new Dictionary<long, long?>(),
                new Dictionary<long, long>());

        public Dictionary<long, long?> UniqueIdByCustomerId { get; }

        public Dictionary<long, long> CustomerIdByUniqueId { get; }

        public Dictionary<long, long?> CustomerImeByCustomerId { get; }

        public Dictionary<long, long> CustomerImeByUniqueId { get; }

        public CustomerCache(
            Dictionary<long, long?> uniqueIdByCustomerId,
            Dictionary<long, long> customerIdByUniqueId,
            Dictionary<long, long?> customerImeByCustomerId,
            Dictionary<long, long> customerImeByUniqueId)
        {
            UniqueIdByCustomerId = uniqueIdByCustomerId;
            CustomerIdByUniqueId = customerIdByUniqueId;
            CustomerImeByCustomerId = customerImeByCustomerId;
            CustomerImeByUniqueId = customerImeByUniqueId;
        }
    }


    public class CustomerCodeItemDto
    {
        // Id,Name,UpdatedDate,ExternalId,PrivateId,DisplayCode,ShadowEntityTypeId

        /// <summary>
        /// کد یکتای موجودیت
        /// </summary>
        public int Id { get; set; }


        /// <summary>
        /// شناسه موجودیت که پیشتر به عنوان شناسه عمومی شناخته شده بود
        /// IMEcode
        /// </summary>
        public int PrivateId { get; set; }



        /// <summary>
        /// نام موجودیت
        /// </summary>
        public string Name { get; set; }


        /// <summary>
        /// شناسه/شماره ملی
        /// </summary>
        public string ExternalId { get; set; }


        /// <summary>
        /// نشانگر نوع موجودیت
        /// </summary>
        public int ShadowEntityTypeId { get; set; }


        /// <summary>
        /// تاریخ آخرین ویرایش مرتبط
        /// </summary>
        public DateTime UpdatedDate { get; set; }

        /// <summary>
        /// کد جهت نمایش
        /// </summary>
        public string DisplayCode { get; set; }



        /// <summary>
        /// CustomerId
        /// </summary>
        public long CustomerId { get; set; }


        /// <summary>
        /// NationalID
        /// </summary>
        public string NationalID { get { return ExternalId; } }


        /// <summary>
        /// CustomerID_IME
        /// </summary>
        public long? CustomerID_IME { get { return PrivateId; } }
    }
    public class ODataResponse<T>
    {
        [JsonProperty("value")]
        public List<T> Value { get; set; }
    }
    public class AggregatedCode
    {
        public long Id { get; set; }
        public long CustomerId { get; set; }
        public long PortfolioId { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public ShadowEntityType ShadowEntityType { get; set; }
    }
    public class ShadowEntityType
    {
        public long Id { get; set; }
        public int Value { get; set; }
        public string Name { get; set; }
    }
}
