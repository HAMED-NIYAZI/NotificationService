﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Runtime.CompilerServices;
using System.Text;

namespace AssetFlow.Persistence.Repositories;

public class AssetLogRepository : IAssetLogRepository
{
    private readonly IDbContextFactory<AssetFlowDbContext> _contextFactory;
    private readonly string _logFilePath;

    private static readonly SemaphoreSlim FileLock = new(1, 1);

    public AssetLogRepository(
        IDbContextFactory<AssetFlowDbContext> contextFactory)
    {
        _contextFactory = contextFactory;

        var configuredFolder = "Logs";

        var logFileName = "assetflow-log.txt";

        var logFolder = Path.IsPathRooted(configuredFolder)
           ? configuredFolder
           : Path.Combine(AppContext.BaseDirectory, configuredFolder);

        Directory.CreateDirectory(logFolder);

        _logFilePath = Path.Combine(logFolder, logFileName);
    }

    public async Task LogIt(AssetLog assetLog)
    {
        ArgumentNullException.ThrowIfNull(assetLog);

        await SaveToDatabaseAsync(assetLog);
        await WriteToFileAsync(assetLog);
    }

    public async Task LogIt(
        Exception? exception,
        string? error = null,
        AssetTransaction? transaction = null,
        [CallerMemberName] string memberName = "",
        [CallerFilePath] string file = "",
        [CallerLineNumber] int line = 0)
    {
        var assetLog = new AssetLog
        {
            Description = error ?? exception?.Message ?? string.Empty,

            Exception = exception is not null
                ? JsonConvert.SerializeObject(exception)
                : null,

            Function =
                $"className={Path.GetFileNameWithoutExtension(file)} " +
                $"memberName={memberName} " +
                $"line={line} " +
                $"file={file}",

            UniqueId = transaction?.UniqueId,
            CallerUserId = transaction?.Id
        };

        await SaveToDatabaseAsync(assetLog);
        await WriteToFileAsync(assetLog);
    }

    private async Task SaveToDatabaseAsync(AssetLog assetLog)
    {
        await using var context =
            await _contextFactory.CreateDbContextAsync();

        await context.AssetLogs.AddAsync(assetLog);
        await context.SaveChangesAsync();
    }

    private async Task WriteToFileAsync(AssetLog assetLog)
    {
        var logText = new StringBuilder()
            .AppendLine("==================================================")
            .AppendLine($"Date: {DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}")
            .AppendLine($"Description: {assetLog.Description}")
            .AppendLine($"Function: {assetLog.Function}")
            .AppendLine($"UniqueId: {assetLog.UniqueId}")
            .AppendLine($"CallerUserId: {assetLog.CallerUserId}")
            .AppendLine($"Exception: {assetLog.Exception}")
            .ToString();

        await FileLock.WaitAsync();

        try
        {
            await File.AppendAllTextAsync(
                _logFilePath,
                logText,
                Encoding.UTF8);
        }
        finally
        {
            FileLock.Release();
        }
    }
}
