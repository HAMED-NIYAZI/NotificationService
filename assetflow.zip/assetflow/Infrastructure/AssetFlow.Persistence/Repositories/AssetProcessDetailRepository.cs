﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace AssetFlow.Persistence.Repositories
{
    public class AssetProcessDetailRepository : IAssetProcessDetailRepository
    {
        private readonly AssetFlowDbContext _context;


        public AssetProcessDetailRepository(AssetFlowDbContext context)
        {
            _context = context;
        }

        public async Task<AssetProcessDetail?> Get(Expression<Func<AssetProcessDetail, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetProcessDetails.FirstOrDefaultAsync(predicate, cancellationToken);
        }

        public async Task<List<AssetProcessDetail>?> GetAll(Expression<Func<AssetProcessDetail, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetProcessDetails.Where(predicate).ToListAsync(cancellationToken);
        }

        public async Task<List<AssetProcessDetail>?> GetAll(long UniqueId, int SymbolId, int WarehouseId, CancellationToken cancellationToken = default)
        {
            return await _context.AssetProcessDetails.Where(x =>
            x.UniqueId == UniqueId &&
            x.SymbolId == SymbolId &&
            x.WarehouseId == WarehouseId
            ).ToListAsync(cancellationToken);
        }

        public async Task<bool> AddAsync(AssetProcessDetail assetProcess, CancellationToken cancellationToken = default)
        {
            await _context.AssetProcessDetails.AddAsync(assetProcess, cancellationToken); return true;
        }
        public async Task<bool> AddRangeAsync(List<AssetProcessDetail> assetProcess, CancellationToken cancellationToken = default)
        {
            await _context.AssetProcessDetails.AddRangeAsync(assetProcess, cancellationToken); return true;
        }
    }
}
