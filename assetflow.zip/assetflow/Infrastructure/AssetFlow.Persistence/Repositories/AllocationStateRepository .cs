﻿using AssetFlow.Domain.Entities; // مسیر انتیتی شما
using AssetFlow.Persistence.DbContext;
using global::AssetFlow.Domain.Contracts;
using Microsoft.EntityFrameworkCore;
namespace AssetFlow.Persistence.Repositories;




public class AllocationStateRepository : IAllocationStateRepository
{
    private readonly IDbContextFactory<AssetFlowDbContext> _contextFactory;

    public AllocationStateRepository(IDbContextFactory<AssetFlowDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<AllocationState?> GetByKeysAsync(long uniqueId, int warehouseId, int symbolId)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        return await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
                x.UniqueId == uniqueId &&
                x.WarehouseId == warehouseId &&
                x.SymbolId == symbolId
                 );
    }


    public async Task UpsertAsync(AllocationState entity)
    {
        await using var context = await _contextFactory.CreateDbContextAsync();

        var existing = await context.AllocationStates
            .FirstOrDefaultAsync(x => x.UniqueId == entity.UniqueId && x.WarehouseId == entity.WarehouseId);

        if (existing == null)
        {
            await context.AllocationStates.AddAsync(entity);
        }
        else
        {
            existing.IsBlocked = entity.IsBlocked;
            if (entity.LastSnapshotBalance is not null) existing.LastSnapshotBalance = entity.LastSnapshotBalance;
            if (entity.LastSnapshotDate is not null) existing.LastSnapshotDate = entity.LastSnapshotDate;

            if (entity.WarehouseBalance is not null) existing.WarehouseBalance = entity.WarehouseBalance;
            if (entity.WarehouseDate is not null) existing.WarehouseDate = entity.WarehouseDate;
            if (entity.MarketBalance is not null) existing.MarketBalance = entity.MarketBalance;
            if (entity.MarketDate is not null) existing.MarketDate = entity.MarketDate;

        }

        await context.SaveChangesAsync();
    }


}

