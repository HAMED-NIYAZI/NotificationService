﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.Repositories
{
    public class CdcTradeRepository : ICdcTradeRepository
    {
        private readonly CdcDbContext _context;
        private IReadOnlyList<SettelmentPrice> _settelmentPrices = [];

        public CdcTradeRepository(CdcDbContext context)
        {
            _context = context;
            ReloadSettelmentPriceAsync().Wait();
        }


        public async Task<IReadOnlyList<CdcTrade>> GetAfterIdAsync(int lastTradeId, int take, CancellationToken cancellationToken = default)
        {
            return await _context.CDCTrades
                .AsNoTracking()
                .Where(x =>
                    x.TradeID > lastTradeId &&
                    x.BuyerCustomerID != x.SellerCustomerID &&
                    !_context.CancelledTradeCdcs.Any(c => c.TradeID == x.TradeID))
                .OrderBy(x => x.RecCreateTime)
                .ThenBy(x => x.TradeID)
                .Take(take)
                .ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<CdcTrade>> GetAfterIdAsync(long lastTradeId, long uniqueId, long warehouseId, long symbolId)
        {
            return await _context.CDCTrades
                .AsNoTracking()
                .Where(x =>
                x.TradeID > lastTradeId &&
                (x.BuyerCustomerID == uniqueId || x.SellerCustomerID == uniqueId) &&
                x.ContractID == symbolId &&
                !_context.CancelledTradeCdcs.Any(c => c.TradeID == x.TradeID))
                .OrderBy(x => x.RecCreateTime)
                .ThenBy(x => x.TradeID)
                .ToListAsync();
        }



        public async Task<decimal> GetSettelmentPriceWithSymbolId(int symbolId, DateTime dateTime)
        {
            DateTime nextDate = dateTime.Date.AddDays(1);

            SettelmentPrice? settlement = _settelmentPrices?
                .Where(x => x.SymbolId == symbolId && x.Date <= nextDate)
                .OrderByDescending(x => x.Date)
                .FirstOrDefault();

            return settlement?.Price ?? 0;
        }



        public async Task ReloadSettelmentPriceAsync()
        {
            _settelmentPrices = await _context.SettlementPrices.ToListAsync();
        }


        public async Task<IReadOnlyList<CdcTrade>> SyncSettelmentPriceAsync(long lastTradeId, long uniqueId, long warehouseId, long symbolId)
        {
            return await _context.CDCTrades
                .AsNoTracking()
                .Where(x => (x.BuyerCustomerID == uniqueId || x.SellerCustomerID == uniqueId) && x.ContractID == symbolId && x.TradeID > lastTradeId)
                .OrderBy(x => x.RecCreateTime).ThenBy(x => x.TradeID)
                .ToListAsync();

        }

    }
}
