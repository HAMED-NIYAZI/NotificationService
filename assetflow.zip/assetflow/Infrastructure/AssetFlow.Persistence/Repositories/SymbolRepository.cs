﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;

namespace AssetFlow.Persistence.Repositories
{
    public class SymbolRepository : ISymbolRepository
    {
        private readonly AssetFlowDbContext _context;
        private static Dictionary<int, int> _symbolToWarehouse = [];
        private static Dictionary<int, int> _warehouseToSymbol = [];
        private static bool isLoadedWarehouse = _warehouseToSymbol?.Count > 0;
        private static bool isLoadedSymbol = _symbolToWarehouse?.Count > 0;
        private static IReadOnlyList<Symbol> allSymbols = [];

        public SymbolRepository(AssetFlowDbContext context)
        {
            _context = context;
            ReloadSymbolMappingsAsync();
        }

        public int GetWarehouseId(int symbolId)
        {
            if (!isLoadedSymbol)
            {
                ReloadSymbolMappingsAsync();
            }

            return _symbolToWarehouse.TryGetValue(symbolId, out int id) ? id : 0;
        }

        public int GetSymbolId(int warehouseId)
        {
            if (!isLoadedWarehouse)
            {
                ReloadSymbolMappingsAsync();
            }

            return _warehouseToSymbol.TryGetValue(warehouseId, out int id) ? id : 0;
        }

        public decimal? GetConversionRate(int warehouseId)
        {
            if (allSymbols is null || allSymbols.Count == 0)
            {
                ReloadSymbolMappingsAsync();
            }

            var onversionRate = allSymbols.SingleOrDefault(x => x.WarehouseId == warehouseId).ConversionRate;
            return onversionRate;
        }

        public void ReloadSymbolMappingsAsync()
        {
            List<Symbol> mappings = _context.Symbols.ToList();
            allSymbols = mappings;
            _symbolToWarehouse = mappings.ToDictionary(x => x.SymbolId, x => x.WarehouseId);
            _warehouseToSymbol = mappings.ToDictionary(x => x.WarehouseId, x => x.SymbolId);
            isLoadedSymbol = _symbolToWarehouse?.Count > 0;
            isLoadedWarehouse = _warehouseToSymbol?.Count > 0;
        }

        public bool IsLodedWarehouse()
        {
            return _warehouseToSymbol.Count > 0;
        }

        public async Task<IReadOnlyList<Symbol>> GetAll()
        {
            if (allSymbols.Count > 0)
            {
                return allSymbols;
            }
            ReloadSymbolMappingsAsync();
            return allSymbols;
        }
    }
}
