﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.Repositories;

public class MarketRepository : IMarketRepository
{
    private readonly AssetFlowDbContext _context;
    private readonly IAssetLogRepository _log;

    public MarketRepository(IAssetLogRepository log, AssetFlowDbContext context)
    {
        _context = context;
        _log = log;
    }
    public async Task BulkUpsertAsync(IReadOnlyCollection<MarketCustomerClearance> entities)
    {
        try
        {
            if (entities == null || entities.Count == 0) return;



            var zeroReferenceCount = entities.Count(x => x.referenceId == 0);
            var totalCount = entities.Count;


            var config = new BulkConfig
            {
                BatchSize = 5000,

                // ۱. کلید تطبیق برای عملیات Upsert
                UpdateByProperties = [nameof(MarketCustomerClearance.referenceId)],

                // ۲. مستثنی کردن Id از دستور Insert (دیتابیس خودش IDENTITY(1,1) تولید کند)
                PropertiesToExclude = [nameof(MarketCustomerClearance.Id)],

                // ۳. مستثنی کردن Id از دستور Update
                PropertiesToExcludeOnUpdate = [nameof(MarketCustomerClearance.Id)],

                // ۴. اگر نیازی به برگشت مقدار Id در آبجکت‌های C# ندارید، false بگذارید تا تداخل ایجاد نشود
                SetOutputIdentity = false
            };

            await _context.BulkInsertOrUpdateAsync(entities, config);
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);

        }

    }





    public async Task<IReadOnlyList<ClearanceWarehouse>> GetClearanceAfterIdAsync(long lastId)
    {
        return (IReadOnlyList<ClearanceWarehouse>)await _context.MarketCustomerClearances
        .FromSqlInterpolated($@"
        SELECT   [referenceId] ReferenceId
        ,[executedQuantity] ExecutedQuantity
        ,[receiveTime] ReceiveTime
        ,[warehouseGroupID]
        --,[customerID_IME] Request_IMECustomerID
        ,[uniqueID] UniqueID
        -- ,[clearanceType] 
        ,[MarketCustomerClearanceId]
        ,warehouseGroupID Warehouse_ResponseID
        FROM  [dbo].[MarketCustomerClearances]
        Where MarketCustomerClearanceId>{lastId} 
        ")
        .AsNoTracking()
        .ToListAsync();
    }

    public async Task<IReadOnlyList<ClearanceWarehouse>> GetClearanceAfterIdAsync(long lastId, long uniqueID, long warehouseId)
    {

        return (IReadOnlyList<ClearanceWarehouse>)await _context.MarketCustomerClearances
        .FromSqlInterpolated($@"
        SELECT   [referenceId] ReferenceId
        ,[executedQuantity] ExecutedQuantity
        ,[receiveTime] ReceiveTime
        ,[warehouseGroupID]
        --,[customerID_IME] Request_IMECustomerID
        ,[uniqueID] UniqueID
        -- ,[clearanceType] 
        ,[MarketCustomerClearanceId]
        ,warehouseGroupID Warehouse_ResponseID
        FROM  [dbo].[MarketCustomerClearances]
        Where MarketCustomerClearanceId>{lastId} and warehouseGroupID={warehouseId} and uniqueID={uniqueID}")
        .AsNoTracking()
        .ToListAsync();

    }

    public async Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId, long uniqueID, long warehouseId, CancellationToken cancellationToken = default)
    {
        return (IReadOnlyList<WarehouseCustomerEntrance>)await _context.MarketCustomerClearances
        .FromSqlInterpolated($@"
        SELECT   [referenceId]
        ,[assetQuantity] ExecutedQuantity
        ,[receiveTime] ReceiveTime
        ,[warehouseGroupID] Warehouse_ResponseID
       -- ,[customerID_IME] Request_IMECustomerID
        ,[uniqueID]
        ,[WarehouseCustomerEntranceId] ID
        FROM  [dbo].[WarehouseCustomerEntrances]
        where WarehouseCustomerEntranceId>{lastId} and warehouseGroupID={warehouseId} and uniqueID={uniqueID} 
        ")
        .AsNoTracking()
        .ToListAsync();



    }

    public async Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId, CancellationToken cancellationToken = default)
    {

        return (IReadOnlyList<WarehouseCustomerEntrance>)await _context.MarketCustomerClearances
        .FromSqlInterpolated($@"
        SELECT   [referenceId]
        ,[assetQuantity] ExecutedQuantity
        ,[receiveTime] ReceiveTime
        ,[warehouseGroupID] Warehouse_ResponseID
        --,[customerID_IME] Request_IMECustomerID
        ,[uniqueID]
        ,[WarehouseCustomerEntranceId] ID
        FROM  [dbo].[WarehouseCustomerEntrances]
        where WarehouseCustomerEntranceId>{lastId}
        ")
        .AsNoTracking()
        .ToListAsync();

    }



}

