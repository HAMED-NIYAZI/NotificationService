﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using EFCore.BulkExtensions;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Linq.Expressions;

namespace AssetFlow.Persistence.Repositories;

public class AssetTransactionRepository : IAssetTransactionRepository
{
    private readonly AssetFlowDbContext _context;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IAssetLogRepository _log;
    private readonly ISymbolRepository _symbolRepository;


    public AssetTransactionRepository(AssetFlowDbContext context, IUnitOfWork unitOfWork, IAssetLogRepository logRepository, ISymbolRepository symbolRepository)
    {
        _context = context;
        _unitOfWork = unitOfWork;
        _log = logRepository;
        _symbolRepository = symbolRepository;
    }

    public async Task<AssetTransaction?> GetByIdAsync(long id, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<AssetTransaction?> GetByIdWithDetailsAsync(long id, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<IReadOnlyList<AssetTransaction>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.AsNoTracking().ToListAsync(cancellationToken);
    }


    public async Task<List<AssetTransaction>> GetAll(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.Where(predicate).ToListAsync(cancellationToken);
    }
    public async Task<IReadOnlyList<AssetTransaction>> FindAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.AsNoTracking().Where(predicate).ToListAsync(cancellationToken);
    }

    public async Task<AssetTransaction?> FirstOrDefaultAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.FirstOrDefaultAsync(predicate, cancellationToken);
    }

    public async Task<bool> ExistsAsync(long id, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.AnyAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<bool> AnyAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.AnyAsync(predicate, cancellationToken);
    }

    public async Task<int> CountAsync(Expression<Func<AssetTransaction, bool>>? predicate = null, CancellationToken cancellationToken = default)
    {
        return predicate is null
            ? await _context.AssetTransactions.CountAsync(cancellationToken)
            : await _context.AssetTransactions.CountAsync(predicate, cancellationToken);
    }

    public async Task<bool> AddAsync(AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
    {
        await _context.AssetTransactions.AddAsync(assetTransaction, cancellationToken); return true;

    }

    public async Task<bool> AddRangeAsync(IEnumerable<AssetTransaction> assetTransactions, CancellationToken cancellationToken = default)
    {
        await _context.AssetTransactions.AddRangeAsync(assetTransactions, cancellationToken); return true;

    }

    public async Task<bool> Update(AssetTransaction assetTransaction)
    {
        _context.AssetTransactions.Attach(assetTransaction);
        _context.Entry(assetTransaction).Property(x => x.Status).IsModified = true;
        _context.AssetTransactions.Update(assetTransaction);
        return true;

    }

    public async Task<bool> UpdateStatusAsync(AssetTransaction assetTransaction)
    {
        AssetTransaction? trackedEntity = _context.AssetTransactions.Local
            .FirstOrDefault(x => x.Id == assetTransaction.Id);

        if (trackedEntity != null)
        {
            trackedEntity.Status = assetTransaction.Status;
        }
        else
        {
            _context.AssetTransactions.Attach(assetTransaction);
            _context.Entry(assetTransaction)
                .Property(x => x.Status)
                .IsModified = true;
        }


        return true;
    }


    public async Task<bool> UpdateRange(IEnumerable<AssetTransaction> assetTransactions)
    {
        _context.AssetTransactions.AttachRange(assetTransactions);
        _context.AssetTransactions.UpdateRange(assetTransactions);
        return true;
    }

    public async Task<bool> Delete(AssetTransaction assetTransaction)
    {
        _context.AssetTransactions.Remove(assetTransaction);
        return true;
    }

    public async Task<bool> DeleteRange(IEnumerable<AssetTransaction> assetTransactions)
    {
        _context.AssetTransactions.RemoveRange(assetTransactions);
        return true;
    }


    public async Task<long> GetMaxTradeIdAsync(CancellationToken cancellationToken = default)
    {
        long maxTradeId = await _context.AssetTransactions.MaxAsync(x => x.TradeId, cancellationToken) ?? 0;
        return maxTradeId;
    }

    public async Task<long> GetMaxTradeIdAsync(long uniqueId, long warehouseId, long symbolId)
    {
        long maxTradeId = await _context.AssetTransactions.Where(x =>
        x.UniqueId == uniqueId &&
        x.WarehouseId == warehouseId &&
        x.SymbolId == symbolId
        ).MaxAsync(x => x.TradeId) ?? 0;
        return maxTradeId;
    }

    public async Task<List<AssetTransaction>> GetAllUnTouchedAsync()
    {
        return await _context.AssetTransactions
        .AsNoTracking()
             .Where(x => x.Status == AssetTransactionStatus.UnTouched)
        //    .Where(x => x.Status == AssetTransactionStatus.UnTouched && x.UniqueId == 725038)
        .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).Take(500000)
        .ToListAsync();
    }
    public async Task<List<AssetTransaction>> GetAllUnTouchedWithTrackingAsync()
    {
       // return await _context.AssetTransactions
       //.Where(x => x.Status == AssetTransactionStatus.UnTouched )
       // // .Where(x => x.Status == AssetTransactionStatus.UnTouched && x.UniqueId==658390 && x.WarehouseId==38)
       // .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).Take(1000000)
       // .ToListAsync();

        return await _context.AssetTransactions
    .Where(x =>
        x.Status == AssetTransactionStatus.UnTouched
        &&
        !_context.AllocationStates.Any(a =>
            a.UniqueId == x.UniqueId &&
            a.WarehouseId == x.WarehouseId &&
            a.IsBlocked))
    .OrderBy(x => x.AssetTransactionCreateDate)
    .ThenBy(x => x.Id)
    //.Take(2_000_000)
    .ToListAsync();

    }

    public async Task<List<AssetTransaction>> GetAllUnTouchedAsync(int take = 1000000, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions
        .AsNoTracking()
        .Where(x => x.Status == AssetTransactionStatus.UnTouched)
                    .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id)
        .Take(take)
        .ToListAsync(cancellationToken);
    }

    public async Task<List<AssetTransaction>> GetAllUnTouchedAsync(long uniqueId, long warehouseId, long symbolId, int take = 1000000, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions
        .AsNoTracking()
        .Where(x => x.Status == AssetTransactionStatus.UnTouched && x.UniqueId == uniqueId && x.UniqueId == uniqueId && x.WarehouseId == warehouseId && x.SymbolId == symbolId)
                    .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id)
        .Take(take)
        .ToListAsync(cancellationToken);
    }
    public async Task<long> GetLastAssetTransactionIdAsync(long uniqueId, int warehouseId, int symbolId)
    {
        AssetAllocation? lastSnapshot = await _context.AssetAllocations.Where(x =>
    x.UniqueId == uniqueId &&
    x.WarehouseId == warehouseId &&
    x.SymbolId == symbolId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

        return lastSnapshot is not null || lastSnapshot?.Id > 0 ? lastSnapshot.AssetTransactionId : 0;

    }

    public async Task<bool> CheckAbnormalTransactionsAsync(long uniqueId, int warehouseId, int symbolId = 0, long? referenceId = null, CancellationToken cancellationToken = default)
    {

        try
        {


            CustomerInvalidData? hasConflict = await GetCustomerInvalidDataAsync(uniqueId, warehouseId);
            if (hasConflict is not null || hasConflict?.Id > 0)
            {
                return true;
            }

            symbolId = symbolId == 0 ? _symbolRepository.GetSymbolId(warehouseId) : symbolId;

            var lastAssetTransactionId = await GetLastAssetTransactionIdAsync(uniqueId, warehouseId, symbolId);

            List<AssetTransaction> transactions = await _context.AssetTransactions
                                                    .Where(x =>
                                                        x.UniqueId == uniqueId &&
                                                        x.WarehouseId == warehouseId &&
                                                        x.SymbolId == symbolId && (!referenceId.HasValue || x.ReferenceId == referenceId.Value) &&
                                                        x.Quantity > 0 &&
                                                        x.Id >= lastAssetTransactionId)
                                                    .OrderBy(x => x.AssetTransactionCreateDate)
                                                    .ThenBy(x => x.Id)
                                                    .ToListAsync(cancellationToken);

            if (transactions.Count == 0)
            {
                return false;
            }

            decimal runningBalance = 0;
            bool isAbnormalDetected = false;

            foreach (AssetTransaction? assetTransaction in transactions)
            {
                decimal signedQuantity = GetSignedQuantity(assetTransaction.Quantity, assetTransaction.Direction);

                runningBalance += signedQuantity;

                if (runningBalance < 0)
                {
                    isAbnormalDetected = true;
                }

                if (isAbnormalDetected)
                {
                    await SaveCustomerInvalidDataAsync(new CustomerInvalidData
                    {
                        WarehouseId = assetTransaction.WarehouseId
                    ,
                        UniqueId = assetTransaction.UniqueId
                    ,
                        SymbolId = assetTransaction.SymbolId
                    ,
                        AssetTransactionId = assetTransaction.Id
                    ,
                        Description = "AbnormalDetected"
                    });


                    await _unitOfWork.SaveChangesAsync(cancellationToken);

                    LogIt(transactions, uniqueId, warehouseId, symbolId);
                    return true;
                }
                else
                {
                    continue;
                }

            }
            await RemoveCustomerInvalidDataAsync(uniqueId, warehouseId, symbolId);
            await _unitOfWork.SaveChangesAsync(cancellationToken);
            return false;

        }
        catch (Exception ex)
        {
            await _unitOfWork.RollbackAsync(cancellationToken);
            await _log.LogIt(ex);
            return false;

        }
    }


    public async Task<bool> CheckAbnormalTransactionsByReferenceIdAsync(long uniqueId, long? referenceId = null, CancellationToken cancellationToken = default)
    {
        int warehouseId = 0;
        int symbolId = 0;

        AssetTransaction? data = await _context.AssetTransactions
                        .Where(x => x.UniqueId == uniqueId && x.ReferenceId == referenceId)
                        .FirstOrDefaultAsync();
        if (data is not null)
        {
            warehouseId = data.WarehouseId;
            symbolId = data.SymbolId;

            return await CheckAbnormalTransactionsAsync(uniqueId, warehouseId, symbolId, referenceId);
        }
        else
        {
            return false;
        }
    }

    private static decimal GetSignedQuantity(decimal quantity, AssetDirection direction)
    {
        return direction == AssetDirection.In ? quantity : -quantity;
    }

    public async Task<long> GetMaxEntranceIdAsync(CancellationToken cancellationToken = default)
    {
        long maxTradeId = await _context.AssetTransactions.MaxAsync(x => x.EntranceId, cancellationToken) ?? 0;
        return maxTradeId;
    }

    public async Task<long> GetMaxEntranceIdAsync(long uniqueId, long warehouseId, long symbolId)
    {
        long maxTradeId = await _context.AssetTransactions.Where(x =>
                                                                    x.UniqueId == uniqueId &&
                                                                    x.WarehouseId == warehouseId &&
                                                                    x.SymbolId == symbolId).MaxAsync(x => x.EntranceId) ?? 0;
        return maxTradeId;
    }

    public async Task<long> GetMaxClearanceIdAsync()
    {
        long maxTradeId = await _context.AssetTransactions.MaxAsync(x => x.ClearanceId) ?? 0;
        return maxTradeId;
    }

    public async Task<long> GetMaxClearanceIdAsync(long uniqueId, long warehouseId)
    {
        long maxTradeId = await _context.AssetTransactions.Where(x =>
                                                                    x.UniqueId == uniqueId &&
                                                                    x.WarehouseId == warehouseId
                                                                    ).MaxAsync(x => x.ClearanceId) ?? 0;
        return maxTradeId;
    }

    private void LogIt(List<AssetTransaction> transactions, long uniqueId, int warehouseId, int symbolId)
    {
        string transactionRange = transactions != null && transactions.Any() ? $"{transactions.Min(x => x.Id)} ... {transactions.Max(x => x.Id)}" : "No Transactions";
        _log.LogIt(null, $"UniqueId={uniqueId} with WarehouseId={warehouseId} and with SymbolId={symbolId} " + $"Has TransactionIds in ({transactionRange})");
    }

    public async Task<List<AssetTransaction>?> GetYoungerDataAsync(long uniqueId, int warehouseId, DateTime assetTransactionCreateDate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions
        .Where(x => x.WarehouseId == warehouseId && x.UniqueId == uniqueId && x.AssetTransactionCreateDate > assetTransactionCreateDate && x.Status == AssetTransactionStatus.Committed)
        .Include(x => x.Allocations)
        .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id)
        .ToListAsync(cancellationToken);
    }

    public async Task<List<AssetTransaction>?> GetYoungerDataAsync2(long uniqueId, int warehouseId, int symbolId, DateTime assetTransactionCreateDate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions
        .Where(x => x.WarehouseId == warehouseId && x.SymbolId == symbolId && x.UniqueId == uniqueId && x.AssetTransactionCreateDate > assetTransactionCreateDate && x.Status == AssetTransactionStatus.Committed)
        .Include(x => x.Allocations)
        .OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id)
        .ToListAsync(cancellationToken);
    }
    public async Task RemoveFalseAllocatedData2(List<AssetTransaction>? latestAssetTransactions)
    {
        if (latestAssetTransactions == null || latestAssetTransactions.Count == 0)
        {
            return;
        }

        var ids = latestAssetTransactions
            .Select(x => x.Id)
            .Distinct()
            .ToList();

        await using IDbContextTransaction transaction = await _context.Database.BeginTransactionAsync();

        await _context.AssetAllocations
            .Where(x => ids.Contains(x.AssetTransactionId))
            .ExecuteDeleteAsync();

        await _context.AssetTransactions
            .Where(x => ids.Contains(x.Id))
            .ExecuteUpdateAsync(setters => setters
                .SetProperty(x => x.Status, AssetTransactionStatus.UnTouched));

        await transaction.CommitAsync();
    }

    public async Task RemoveFalseAllocatedData(List<AssetTransaction>? latestAssetTransactions)
    {
        if (latestAssetTransactions == null || latestAssetTransactions.Count == 0) { return; }

        await using var transaction = await _context.Database.BeginTransactionAsync();

        try
        {
            var transactionIds = latestAssetTransactions.Select(x => x.Id).Distinct().ToList();
            //حذف الوکیشن ها
            await _context.AssetAllocations
            .Where(x => transactionIds.Contains(x.AssetTransactionId))
            .ExecuteDeleteAsync();


            //ویرایش تراکنشها
            await _context.AssetTransactions
            .Where(x => transactionIds.Contains(x.Id))
            .ExecuteUpdateAsync(setters => setters
            .SetProperty(x => x.Status, AssetTransactionStatus.UnTouched));

            await transaction.CommitAsync();
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            await _log.LogIt(null, $"Error while RemoveFalseAllocatedData UniqueId={latestAssetTransactions[0].UniqueId} with WarehouseId={latestAssetTransactions[0].WarehouseId} and with SymbolId={latestAssetTransactions[0].SymbolId} " + $"Has TransactionIds in ({latestAssetTransactions[0].Id}... {latestAssetTransactions[latestAssetTransactions.Count - 1].Id})", latestAssetTransactions[0]);
        }
    }

    public async Task RemoveFalseAllocatedDataInMemory(List<AssetTransaction> transactions)
    {
        var allocations = transactions.SelectMany(x => x.Allocations ?? []).ToList();

        var exits = allocations.OfType<AssetExit>().ToList();

        var entries = allocations.OfType<AssetEntry>().ToList();

        // اول Childها
        _context.AssetAllocations.RemoveRange(exits);

        // بعد Parentها
        _context.AssetAllocations.RemoveRange(entries);
        await Task.CompletedTask;
    }
    public async Task BulkInsertAsync(List<AssetTransaction> transactions)
    {
        await _context.BulkInsertAsync(transactions, new BulkConfig
        {
            BatchSize = 10_000,
            SetOutputIdentity = false
        });
    }

    public async Task<bool> SaveCustomerInvalidDataAsync(CustomerInvalidData customerInvalidData)
    {
        await _context.CustomerInvalidData.AddAsync(customerInvalidData); return true;
    }

    public async Task<bool> RemoveCustomerInvalidDataAsync(long uniqueId, int warehouseId, int symbolI)
    {
        var affectedRows = await _context.CustomerInvalidData
            .Where(x => x.UniqueId == uniqueId && x.SymbolId == symbolI && x.WarehouseId == warehouseId)
            .ExecuteDeleteAsync();

        return affectedRows > 0;
    }

    public async Task<CustomerInvalidData> GetCustomerInvalidDataAsync(long uniqueId, int warehouseId)
    {
        CustomerInvalidData? data = await _context.CustomerInvalidData
            .Where(x => x.UniqueId == uniqueId && x.WarehouseId == warehouseId)
            .FirstOrDefaultAsync();

        return data;
    }

    public async Task<IReadOnlyList<AssetTransaction>> GetAllAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default)
    {
        return await _context.AssetTransactions.AsNoTracking().Where(predicate).ToListAsync();
    }

    public async Task<List<AssetTransaction>> GetTrackedGroupTransactionsForRebuildAsync(long uniqueId, int warehouseId, int symbolId)
    {
        return await _context.AssetTransactions
            .AsTracking()
            .Where(x =>
                x.UniqueId == uniqueId &&
                x.WarehouseId == warehouseId &&
                x.SymbolId == symbolId)
            .OrderBy(x => x.AssetTransactionCreateDate)
            .ThenBy(x => x.Id)
            .ToListAsync();
    }
    public IQueryable<AssetTransaction> Query()
    {
        return _context.AssetTransactions.AsQueryable();
    }
}