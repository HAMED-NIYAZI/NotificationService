﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using System.Collections.Concurrent;

namespace AssetFlow.Persistence.Repositories;


public sealed class AllocationStateStore : IAllocationStateStore
{
    public readonly string _lock = "_lock";
    public readonly IAllocationStateRepository _allocationStateRepository;

    public AllocationStateStore(IAllocationStateRepository allocationStateRepository)
    {
        _allocationStateRepository = allocationStateRepository;
    }

    private readonly ConcurrentDictionary<AllocationStateKey, AllocationState> _states = new();

    public async Task<bool> IsBlock(AllocationStateKey key)
    {
        if (!_states.TryGetValue(key, out AllocationState? state))
        {

            state = await GetOrCreate(key);


        }

        return (bool)state.IsBlocked;

    }

    public async Task BlockAsync(AllocationStateKey key)
    {
        if (await IsBlock(key)) return;
        AllocationState state = await GetOrCreate(key);

        state.IsBlocked = true;

        await _allocationStateRepository.UpsertAsync(state);

    }

    public async Task Unblock(AllocationStateKey key)
    {
        if (!await IsBlock(key)) return;


        AllocationState state = await GetOrCreate(key);


        state.IsBlocked = false;

        state.UniqueId = key.UniqueId;
        state.WarehouseId = key.WarehouseId;

        await _allocationStateRepository.UpsertAsync(state);

    }


    public async Task CreateOrUpdateSnapshot(AllocationStateKey key, double balance, DateOnly date)
    {
        AllocationState state = await GetOrCreate(key);

        state.LastSnapshotBalance = balance;
        state.LastSnapshotDate = date;

        await _allocationStateRepository.UpsertAsync(state);

    }

    public async Task CreateOrUpdateBalance(AllocationStateKey key, double balance, DateOnly date)
    {

        AllocationState state = await GetOrCreate(key);

        state.WarehouseBalance = balance;
        state.WarehouseDate = date;

        await _allocationStateRepository.UpsertAsync(state);


    }

    public async Task<bool> IsSyncBalance(AllocationStateKey key)
    {
        AllocationState state = await GetOrCreate(key);
        return state.IsSync;
    }

    public async Task<AllocationState> TryGet(AllocationStateKey key)
    {
        var state = await GetOrCreate(key);
        return state;
    }


    private async Task<AllocationState> GetOrCreate(AllocationStateKey key)
    {
        AllocationState state = _states.GetOrAdd(key, _ => new AllocationState());
        if (state.UniqueId == key.UniqueId && state.WarehouseId == key.WarehouseId)
        {
            return state;
        }

        state.UniqueId = key.UniqueId;
        state.WarehouseId = key.WarehouseId;

        await _allocationStateRepository.UpsertAsync(state);


        return state;
    }
}
