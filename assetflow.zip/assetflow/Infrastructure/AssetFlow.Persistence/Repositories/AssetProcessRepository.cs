﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Dtos;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Mapster;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace AssetFlow.Persistence.Repositories
{
    public class AssetProcessRepository : IAssetProcessRepository
    {
        private readonly AssetFlowDbContext _context;


        public AssetProcessRepository(AssetFlowDbContext context)
        {
            _context = context;
        }

        public async Task<AssetProcessDto?> Get(Expression<Func<AssetProcess, bool>> predicate, CancellationToken cancellationToken = default)
        {

            AssetProcess? assetProcess = await _context.AssetProcesses.Include(x => x.AssetProcessDetails).FirstOrDefaultAsync(predicate, cancellationToken);
            AssetProcessDto? assetProcessDto = assetProcess.Adapt<AssetProcessDto>();
            return assetProcessDto;
        }

        public async Task<List<AssetProcess>?> GetAll(Expression<Func<AssetProcess, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetProcesses.Where(predicate).ToListAsync(cancellationToken);
        }

        public async Task<List<AssetProcess>?> GetAll(int UniqueId, int SymbolId, int WarehouseId, CancellationToken cancellationToken = default)
        {
            return await _context.AssetProcesses.Where(x =>
            x.UniqueId == UniqueId &&
            x.SymbolId == SymbolId &&
            x.WarehouseId == WarehouseId &&
            x.UniqueId == UniqueId
            ).ToListAsync(cancellationToken);
        }

        public async Task<bool> AddAsync(AssetProcess assetProcess, CancellationToken cancellationToken = default)
        {
            await _context.AssetProcesses.AddAsync(assetProcess, cancellationToken); return true;
        }
        public async Task<bool> AddRangeAsync(List<AssetProcess> assetProcesses, CancellationToken cancellationToken = default)
        {
            await _context.AssetProcesses.AddRangeAsync(assetProcesses, cancellationToken); return true;
        }

        public async Task<List<AssetProcessDto>?> GetTaxSummaries(int WarehouseId, DateTime inThisDate, CancellationToken cancellationToken = default)
        {
            var fromDate = inThisDate.Date;
            var toDate = fromDate.AddDays(1);

            var assetProcess = await _context.AssetProcesses
                .Where(x => x.WarehouseId == WarehouseId &&
                            x.AssetProcessDetails.Any(d =>
                                d.AssetAllocation.AssetTransaction.AssetTransactionCreateDate >= fromDate &&
                                d.AssetAllocation.AssetTransaction.AssetTransactionCreateDate < toDate))
                .Include(x => x.AssetProcessDetails
                    .Where(d =>
                        d.AssetAllocation.AssetTransaction.AssetTransactionCreateDate >= fromDate &&
                        d.AssetAllocation.AssetTransaction.AssetTransactionCreateDate < toDate))
                .ThenInclude(d => d.AssetAllocation)
                .ThenInclude(a => a.AssetTransaction)
                .ToListAsync(cancellationToken);

            List<AssetProcessDto>? assetProcessDto = assetProcess.Adapt<List<AssetProcessDto>?>();

            return assetProcessDto;

        }
    }
}
