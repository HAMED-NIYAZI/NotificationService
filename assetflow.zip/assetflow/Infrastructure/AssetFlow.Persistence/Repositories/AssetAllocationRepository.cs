﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace AssetFlow.Persistence.Repositories
{
    public class AssetAllocationRepository : IAssetAllocationRepository
    {
        private readonly AssetFlowDbContext _context;
        private readonly IAssetLogRepository _log;


        public AssetAllocationRepository(IAssetLogRepository log, AssetFlowDbContext context)
        {
            _context = context;
            this._log = log;
        }
        public async Task<bool> Save(AssetAllocation assetEntry, CancellationToken cancellationToken = default)
        {
            await _context.AssetAllocations.AddAsync(assetEntry, cancellationToken);
            return true;
        }
        public async Task<AssetAllocation> Get(Expression<Func<AssetAllocation, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetAllocations.Include(x => x.AssetTransaction).SingleAsync(predicate, cancellationToken);
        }
        public async Task<List<AssetAllocation>> GetAll(Expression<Func<AssetAllocation, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetAllocations.Where(predicate).Include(x => x.AssetTransaction).ToListAsync(cancellationToken);
        }


        public async Task<List<AssetExit>> GetAllAssetAllocation(Expression<Func<AssetExit, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetAllocations
            .OfType<AssetExit>()
            .Include(x => x.AssetTransaction)
            .Include(x => x.AssetAllocation)
            .Where(predicate).OrderBy(x => x.AssetTransaction.AssetTransactionCreateDate)
            .ThenBy(x => x.Id)
            .ToListAsync(cancellationToken);
        }

        public async Task<List<AssetExit>> GetAllAssetAllocationForTaxSummaries(int WarehouseId, DateTime toThisDate, CancellationToken cancellationToken = default)
        {

            DateTime fromDate = toThisDate.Date;
            DateTime toDate = fromDate.AddDays(1);

            return await _context.AssetAllocations
                .OfType<AssetExit>()
                .Where(x =>
                    x.WarehouseId == WarehouseId &&
                    x.AssetSourceType == AssetSourceType.WarehouseEntry &&
                    x.AssetTransaction.Type == AssetTransactionType.Sell &&
                    x.AssetTransaction.AssetTransactionCreateDate >= fromDate &&
                    x.AssetTransaction.AssetTransactionCreateDate < toDate)
                .Include(x => x.AssetAllocation)
                .Include(x => x.AssetTransaction)
                .OrderBy(x => x.AssetTransaction.AssetTransactionCreateDate)
                .ThenBy(x => x.AssetTransaction.Id)
                .ThenBy(x => x.CreateDate)
                .ThenBy(x => x.Id)
                .ToListAsync(cancellationToken);
        }


        public async Task<List<AssetEntry>> GetAvailableAssetAllocationAsync(long UniqueId, int WarehouseId, CancellationToken cancellationToken = default)
        {
            return await _context.AssetAllocations
            .OfType<AssetEntry>()
            .Include(x => x.AssetTransaction)
            .Where(a =>
                a.UniqueId == UniqueId &&
                a.WarehouseId == WarehouseId &&
                (a.AssetSourceType == AssetSourceType.MarketBuy || a.AssetSourceType == AssetSourceType.WarehouseEntry) && a.AssetTransaction.Status == AssetTransactionStatus.Committed &&
                a.RemainingQuantity > 0
            ).OrderBy(x => x.AssetTransaction.AssetTransactionCreateDate)
            .ThenBy(x => x.Id)
            .ToListAsync(cancellationToken);
        }

        public async Task<List<AssetExit>> GetYoungInvalidTransactionsAsync(long UniqueId, int WarehouseId, DateTime minAssetTransactionCreateDate)
        {
            return await _context.AssetAllocations
            .OfType<AssetExit>()
            .Include(x => x.AssetTransaction)
            .Where(a =>
                a.UniqueId == UniqueId &&
                a.WarehouseId == WarehouseId &&
                (a.AssetSourceType == AssetSourceType.MarketBuy || a.AssetSourceType == AssetSourceType.WarehouseEntry) && a.AssetTransaction.Status == AssetTransactionStatus.Committed &&
                a.AssetTransaction.AssetTransactionCreateDate >= minAssetTransactionCreateDate
            ).OrderBy(x => x.AssetTransaction.AssetTransactionCreateDate)
            .ThenBy(x => x.Id)
            .ToListAsync();
        }

        public async Task<AssetAllocation> GetLatestSnapshot(AssetAllocation assetAllocation)
        {
            try
            {
                return await _context.AssetAllocations.Where(x =>
                x.UniqueId == assetAllocation.UniqueId &&
                x.WarehouseId == assetAllocation.WarehouseId &&
                x.SymbolId == assetAllocation.SymbolId &&
                x.UniqueId == assetAllocation.UniqueId
                ).OrderByDescending(x => x.CreateDate).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                _log.LogIt(ex);

                return assetAllocation;
            }
        }




        public async Task UpdateLatestSnapshotToHasConflict(long UniqueId, int WarehouseId, int SymbolId)
        {
            await _context.AssetAllocations
        .Where(x =>
        x.UniqueId == UniqueId &&
        x.WarehouseId == WarehouseId &&
        x.SymbolId == SymbolId)
        .OrderByDescending(x => x.CreateDate)
        .Take(1)
        .ExecuteUpdateAsync(setters =>
        setters.SetProperty(x => x.HasConflict, true));
        }



        public async Task ResolveLatestSnapshotToHasConflict(long UniqueId, int WarehouseId, int SymbolId)
        {
            await _context.AssetAllocations
        .Where(x =>
        x.UniqueId == UniqueId &&
        x.WarehouseId == WarehouseId &&
        x.SymbolId == SymbolId)
        .OrderByDescending(x => x.CreateDate)
        .Take(1)
        .ExecuteUpdateAsync(setters =>
        setters.SetProperty(x => x.HasConflict, false));
        }

        public async Task<bool> Delete(Domain.Entities.AssetAllocation assetTransaction)
        {
            _context.AssetAllocations.Remove(assetTransaction);
            return true;
        }

        public async Task<bool> DeleteRange(IEnumerable<Domain.Entities.AssetAllocation> assetTransactions)
        {
            _context.AssetAllocations.RemoveRange(assetTransactions);
            return true;
        }


        public async Task<bool> CheckAbnormalAvailableQuantity(long referenceId)
        {
            AssetAllocation? data = await _context.AssetAllocations.FirstOrDefaultAsync(x => x.ReferenceId == referenceId);
            return data is null || data.Id == 0 || await _context.AssetAllocations.AnyAsync(x =>
                                                                 x.UniqueId == data.UniqueId &&
                                                                 x.WarehouseId == data.WarehouseId &&
                                                                 x.SymbolId == data.SymbolId &&
                                                                 x.UniqueId == data.UniqueId &&
                                                                 x.AvailableQuantity < 0
                                                                 );
        }

        public async Task<bool> CheckAbnormalAvailableQuantity2(long referenceId)
        {
            AssetTransaction? data = await _context.AssetTransactions.FirstOrDefaultAsync(x => x.ReferenceId == referenceId);
            decimal sum = 0;
            if (data is not null && data.ReferenceId == referenceId)
                sum = await _context.AssetTransactions
                   .Where(x =>
                       x.UniqueId == data.UniqueId &&
                       x.WarehouseId == data.WarehouseId &&
                       x.SymbolId == data.SymbolId)
                   .SumAsync(
                       x => x.Type == AssetTransactionType.Buy ||
                            x.Type == AssetTransactionType.Entry
                               ? x.Quantity
                               : -x.Quantity
                       );
            return sum < 0;
        }



        public async Task<bool> CheckAbnormalAvailableQuantity(int warehouseGroupId)
        {
            return await _context.AssetAllocations.AnyAsync(x =>
                                                                 x.WarehouseId == warehouseGroupId &&
                                                                 x.AvailableQuantity < 0
                                                                 );
        }


        public async Task<bool> CheckReferenceIdHasAllocationData(long referenceId)
        {
            AssetAllocation? data = await _context.AssetAllocations.FirstOrDefaultAsync(x => x.ReferenceId == referenceId);
            return data is null || data.Id == 0;
        }
        public async Task<bool> CheckReferenceIdHasTransactionData(long referenceId)
        {
            AssetTransaction? data = await _context.AssetTransactions.FirstOrDefaultAsync(x => x.ReferenceId == referenceId);
            return data is null || data.Id == 0;
        }

        public async Task<AssetTransaction?> GetTransactionByReferenceId(long referenceId)
        {
            AssetTransaction? data = await _context.AssetTransactions.FirstOrDefaultAsync(x => x.ReferenceId == referenceId);
            return data is not null || data.ReferenceId == referenceId ? data : null;
        }

        public async Task<List<AssetAllocation>> GetTrackedGroupAllocationsForRebuildAsync(
    long uniqueId,
    int warehouseId,
    int symbolId)
        {
            var entries = await _context.AssetAllocations
                .OfType<AssetEntry>()
                .AsTracking()
                .Include(x => x.AssetTransaction)
                .Where(x =>
                    x.UniqueId == uniqueId &&
                    x.WarehouseId == warehouseId &&
                    x.SymbolId == symbolId)
                .ToListAsync();

            var exits = await _context.AssetAllocations
                .OfType<AssetExit>()
                .AsTracking()
                .Include(x => x.AssetTransaction)
                .Include(x => x.AssetAllocation)
                .Where(x =>
                    x.UniqueId == uniqueId &&
                    x.WarehouseId == warehouseId &&
                    x.SymbolId == symbolId)
                .ToListAsync();

            return entries
                .Cast<AssetAllocation>()
                .Concat(exits)
                .ToList();
        }

        public void RemoveRangeInMemory(IEnumerable<AssetAllocation> allocations)
        {
            if (allocations is null) return;

            var list = allocations.Where(x => x != null).ToList();

            if (list.Count == 0) return;

            // اول Exitها / Childها
            var exits = list.OfType<AssetExit>().Cast<AssetAllocation>().ToList();

            if (exits.Count > 0)
            {
                _context.AssetAllocations.RemoveRange(exits);
            }

            // بعد Entryها / Parentها
            var entries = list.OfType<AssetEntry>().Cast<AssetAllocation>().ToList();

            if (entries.Count > 0) _context.AssetAllocations.RemoveRange(entries);

        }

        public async Task<AssetAllocation?> GetLatestSnapshotBeforeDateAsync(long uniqueId, int warehouseId, DateTime beforeDate, CancellationToken cancellationToken = default)
        {
            return await _context.AssetAllocations
                .AsNoTracking()
                .Where(x => x.UniqueId == uniqueId &&
                            x.WarehouseId == warehouseId &&
                            x.AssetTransaction.AssetTransactionCreateDate < beforeDate)
                .OrderByDescending(x => x.AssetTransaction.AssetTransactionCreateDate)
                .ThenByDescending(x => x.Id)
                .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<List<AssetEntry>> GetAssetEntriesByIdsAsync(
    IEnumerable<long> ids,
    CancellationToken cancellationToken = default)
        {
            var idList = ids
                .Distinct()
                .ToList();

            if (idList.Count == 0)
                return [];

            return await _context.AssetAllocations
                .OfType<AssetEntry>()
                .Where(x => idList.Contains(x.Id))
                .ToListAsync(cancellationToken);
        }

    }
}
