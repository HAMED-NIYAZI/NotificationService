﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.DbContext
{
    public class AssetFlowDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public AssetFlowDbContext(DbContextOptions<AssetFlowDbContext> options) : base(options)
        {
        }

        public DbSet<AssetTransaction> AssetTransactions => Set<AssetTransaction>();
        public DbSet<AssetAllocation> AssetAllocations => Set<AssetAllocation>();
        public DbSet<AssetProcessDetail> AssetProcessDetails => Set<AssetProcessDetail>();
        public DbSet<AssetProcess> AssetProcesses => Set<AssetProcess>();
        public DbSet<Symbol> Symbols => Set<Symbol>();
        public DbSet<AssetLog> AssetLogs => Set<AssetLog>();
        public DbSet<CustomerInvalidData> CustomerInvalidData => Set<CustomerInvalidData>();
        public DbSet<AllocationState> AllocationStates => Set<AllocationState>();
        public DbSet<MarketCustomerClearance> MarketCustomerClearances => Set<MarketCustomerClearance>();
        public DbSet<MarketCustomerEntrance> MarketCustomerEntrances => Set<MarketCustomerEntrance>();
        public DbSet<WarehouseCustomerEntrance> WarehouseCustomerEntrances => Set<WarehouseCustomerEntrance>();
        public DbSet<WarehouseCustomerClearance> WarehouseCustomerClearances => Set<WarehouseCustomerClearance>();
        public DbSet<Customer> Customers => Set<Customer>();


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
 
            modelBuilder.Entity<AssetAllocation>(entity =>
            {
                entity.HasKey(x => x.Id);

                entity.HasDiscriminator<string>("AssetDirection")
                      .HasValue<AssetEntry>("AssetEntry")
                      .HasValue<AssetExit>("AssetExit");
            });

            modelBuilder.Entity<AssetExit>(entity =>
            {
                entity.HasOne(x => x.AssetAllocation)
                      .WithMany()
                      .HasForeignKey(x => x.AssetAllocationId)
                      .IsRequired(false)
                      .OnDelete(DeleteBehavior.ClientCascade); // یا ClientSetNull
            });



            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AssetFlowDbContext).Assembly);
        }


    }

}
