﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.DbContext
{
    public class CdcDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public CdcDbContext(DbContextOptions<CdcDbContext> options) : base(options)
        {
        }
        public DbSet<CdcTrade> CDCTrades => Set<CdcTrade>();
        public DbSet<CancelledTradeCdc> CancelledTradeCdcs => Set<CancelledTradeCdc>();
        public DbSet<SettelmentPrice> SettlementPrices => Set<SettelmentPrice>();


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(CdcDbContext).Assembly);
        }

        public override int SaveChanges()
        {
            throw new InvalidOperationException("CDCDbContext is read-only.");
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            throw new InvalidOperationException("CDCDbContext is read-only.");
        }
    }

}
