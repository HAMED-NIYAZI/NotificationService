﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{

    public class WarehouseCustomerClearanceConfiguration : IEntityTypeConfiguration<WarehouseCustomerClearance>
    {
        public void Configure(EntityTypeBuilder<WarehouseCustomerClearance> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.executedQuantity)
                .HasPrecision(18, 6);
            builder.Property(x => x.receiveTime)
           .HasColumnType("datetime2(7)");
        }
    }

    public class MarketCustomerEntranceConfiguration : IEntityTypeConfiguration<MarketCustomerEntrance>
    {
        public void Configure(EntityTypeBuilder<MarketCustomerEntrance> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.assetQuantity)
                .HasPrecision(18, 6);
            builder.Property(x => x.receiveTime)
           .HasColumnType("datetime2(7)");

        }
    }

    public class SymbolConfiguration : IEntityTypeConfiguration<Symbol>
    {
        public void Configure(EntityTypeBuilder<Symbol> builder)
        {
            builder.HasKey(x => x.Id);

            builder.ToTable("Symbols");
            builder.HasKey(e => e.Id);
            builder.HasIndex(e => e.SymbolId).IsUnique();
            builder.HasIndex(e => e.WarehouseId).IsUnique();
            builder.Property(x => x.ConversionRate)
                .HasPrecision(18, 6);

        }
    }
}
