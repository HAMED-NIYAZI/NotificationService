﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations;

public class MarketCustomerClearanceConfiguration
: IEntityTypeConfiguration<MarketCustomerClearance>
{
    public void Configure(EntityTypeBuilder<MarketCustomerClearance> builder)
    {
        builder.ToTable("MarketCustomerClearances");
        builder.HasKey(x => x.MarketCustomerClearanceId);
        builder.Property(x => x.executedQuantity).HasPrecision(18, 6);
        builder.Property(x => x.clearanceType).HasColumnType("char(1)");

        builder.Property(x => x.receiveTime).HasColumnType("datetime2(7)");


    }
}
