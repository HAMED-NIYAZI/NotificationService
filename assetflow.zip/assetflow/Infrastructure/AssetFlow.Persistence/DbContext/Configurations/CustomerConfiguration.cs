﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations;


public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.ToTable("Customers");

        builder.HasKey(x => x.CustomerID);

        builder.Property(x => x.CustomerID)
            .ValueGeneratedNever();

        builder.Property(x => x.CustomerName)
            .HasMaxLength(200);

        builder.Property(x => x.Status)
            .HasColumnType("char(1)");

        builder.Property(x => x.RecTime)
            .HasColumnType("datetime2(7)");

        builder.Property(x => x.NationalID)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(x => x.CustomerID_IME)
            .HasMaxLength(50);

        builder.Property(x => x.UniqueID)
            .HasMaxLength(50);

        builder.Property(x => x.DisplayCode)
            .HasMaxLength(200);

        builder.Property(x => x.CustomerType)
            .HasMaxLength(50);
    }
}
