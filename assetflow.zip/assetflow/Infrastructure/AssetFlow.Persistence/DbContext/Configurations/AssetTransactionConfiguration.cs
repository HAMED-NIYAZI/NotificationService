﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Reflection.Emit;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class AssetTransactionConfiguration : IEntityTypeConfiguration<AssetTransaction>
    {
        public void Configure(EntityTypeBuilder<AssetTransaction> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.Quantity).HasPrecision(18, 6);

            builder.Property(x => x.Price).HasPrecision(18, 6);

            builder.HasIndex(x => new { x.UniqueId, x.TradeId })
                .IsUnique()
                .HasFilter("[TradeId] IS NOT NULL")
                .HasDatabaseName("UX_AssetTransactions_TradeId");

            builder.HasIndex(x => new
            {
                x.UniqueId,
                x.SymbolId,
                x.WarehouseId,
                x.AssetTransactionCreateDate,
                x.TradeId
            })
                .IsUnique()
                .HasDatabaseName("UX_AssetTransactions_Trade")
                .HasFilter($"""
                [TradeId] IS NOT NULL
                AND [Type] IN ({(int)AssetTransactionType.Buy}, {(int)AssetTransactionType.Sell})
                """);

            builder.HasIndex(x => new
            {
                x.UniqueId,
                x.SymbolId,
                x.WarehouseId,
                x.AssetTransactionCreateDate,
                x.EntranceId
            })
                .IsUnique()
                .HasDatabaseName("UX_AssetTransactions_Entry")
                .HasFilter($"""
                [EntranceId] IS NOT NULL
                AND [Type] = {(int)AssetTransactionType.Entry}
                """);

            builder.HasIndex(x => new
            {
                x.UniqueId,
                x.SymbolId,
                x.WarehouseId,
                x.AssetTransactionCreateDate,
                x.ClearanceId
            })
                .IsUnique()
                .HasDatabaseName("UX_AssetTransactions_Clearance")
                .HasFilter($"""
                [ClearanceId] IS NOT NULL
                AND [Type] = {(int)AssetTransactionType.Clearance}
                """);

        }
    }
}
