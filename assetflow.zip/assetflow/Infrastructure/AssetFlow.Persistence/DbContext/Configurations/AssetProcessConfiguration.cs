﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class AssetProcessConfiguration : IEntityTypeConfiguration<AssetProcess>
    {
        public void Configure(EntityTypeBuilder<AssetProcess> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Quantity).HasPrecision(18, 6);
            builder.Property(x => x.TotalPrice).HasPrecision(18, 6);
            builder.Property(x => x.AveragePrice).HasPrecision(18, 6);
        }
    }

}
