﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace AssetFlow.Persistence.DbContext.Configurations;


public class AllocationStateConfiguration
    : IEntityTypeConfiguration<AllocationState>
{
    public void Configure(EntityTypeBuilder<AllocationState> builder)
    {
        builder.HasKey(x => x.Id);

        builder.HasIndex(x => new
        {
            x.UniqueId,
            x.WarehouseId,
            x.SymbolId
        })
        .IsUnique();

        builder.Ignore(x => x.IsSync);

    }
}
