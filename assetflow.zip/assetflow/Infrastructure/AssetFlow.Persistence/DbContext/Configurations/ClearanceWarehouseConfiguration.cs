﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class ClearanceWarehouseConfiguration : IEntityTypeConfiguration<ClearanceWarehouse>
    {
        public void Configure(EntityTypeBuilder<ClearanceWarehouse> builder)
        {
            builder.ToTable("Clearance", "Warehouse", t => t.ExcludeFromMigrations());
            builder.HasKey(x => x.Id);
            builder.Property(x => x.ExecutedQuantity).HasPrecision(18, 6);
            //builder.Property(x => x.ClearanceType).HasColumnName("ClearanceType").HasColumnType("char(1)");



        }
    }
}
