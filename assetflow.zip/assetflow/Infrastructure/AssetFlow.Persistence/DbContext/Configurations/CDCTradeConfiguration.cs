﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class CDCTradeConfiguration : IEntityTypeConfiguration<CdcTrade>
    {
        public void Configure(EntityTypeBuilder<CdcTrade> builder)
        {
            builder.ToTable("Trade_CDC", "Trading", t => t.ExcludeFromMigrations());
            builder.HasKey(x => x.TradeID);
            builder.Property(x => x.Price).HasPrecision(18, 6);
            builder.Ignore(x => x.TradeType);
        }
    }
    public class CancelledTradeCdcConfiguration : IEntityTypeConfiguration<CancelledTradeCdc>
    {
        public void Configure(EntityTypeBuilder<CancelledTradeCdc> builder)
        {
            builder.ToTable("CancelledTrade_CDC", "Trading", t => t.ExcludeFromMigrations());
            builder.HasKey(x => x.TradeID);
            builder.Property(x => x.Price).HasPrecision(18, 6);
        }
    }
}
