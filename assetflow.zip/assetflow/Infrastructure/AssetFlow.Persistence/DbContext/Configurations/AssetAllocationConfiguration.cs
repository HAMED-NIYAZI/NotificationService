﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{

    public class AssetAllocationConfiguration : IEntityTypeConfiguration<AssetAllocation>
    {
        public void Configure(EntityTypeBuilder<AssetAllocation> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.AvailableQuantity).HasPrecision(18, 6);
        }
    }
}
