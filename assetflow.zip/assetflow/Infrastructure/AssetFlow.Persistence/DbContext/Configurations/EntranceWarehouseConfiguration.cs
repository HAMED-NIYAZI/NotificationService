﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class EntranceWarehouseConfiguration : IEntityTypeConfiguration<WarehouseCustomerEntrance>
    {
        public void Configure(EntityTypeBuilder<WarehouseCustomerEntrance> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.assetQuantity).HasPrecision(18, 6);

        }
    }
}
