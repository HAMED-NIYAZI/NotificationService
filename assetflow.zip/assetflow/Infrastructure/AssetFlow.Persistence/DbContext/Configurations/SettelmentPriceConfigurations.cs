﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{

    public class SettelmentPriceConfigurations : IEntityTypeConfiguration<SettelmentPrice>
    {
        public void Configure(EntityTypeBuilder<SettelmentPrice> builder)
        {
            builder.ToTable("SettlementPrice_CDC", "Contract", t => t.ExcludeFromMigrations());
            builder.Property(x => x.Price).HasPrecision(18, 6);
            builder.HasNoKey();
        }
    }

}
