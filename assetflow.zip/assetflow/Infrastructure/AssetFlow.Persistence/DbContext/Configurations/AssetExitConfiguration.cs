﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class AssetExitConfiguration : IEntityTypeConfiguration<AssetExit>
    {
        public void Configure(EntityTypeBuilder<AssetExit> builder)
        {
            builder.Property(x => x.Quantity).HasPrecision(18, 6);

            builder.Property(x => x.AllocatedQuantity).HasPrecision(18, 6);
        }
    }
}
