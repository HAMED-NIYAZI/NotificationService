﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class AssetEntryConfiguration : IEntityTypeConfiguration<AssetEntry>
    {
        public void Configure(EntityTypeBuilder<AssetEntry> builder)
        {
            builder.Property(x => x.OriginalQuantity)
                   .HasPrecision(18, 6);

            builder.Property(x => x.RemainingQuantity)
                   .HasPrecision(18, 6);
        }
    }
}
