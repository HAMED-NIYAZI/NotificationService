﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace AssetFlow.Persistence.DbContext.Configurations
{
    public class AssetProcessDetailConfiguration : IEntityTypeConfiguration<AssetProcessDetail>
    {
        public void Configure(EntityTypeBuilder<AssetProcessDetail> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Quantity).HasPrecision(18, 6);
            builder.Property(x => x.Price).HasPrecision(18, 6);
        }
    }

}
