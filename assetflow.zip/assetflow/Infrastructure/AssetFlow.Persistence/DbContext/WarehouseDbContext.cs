﻿using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.DbContext
{
    public class WarehouseDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public WarehouseDbContext(DbContextOptions<WarehouseDbContext> options) : base(options)
        {
        }
        public DbSet<ClearanceWarehouse> ClearanceWarehouses => Set<ClearanceWarehouse>();
        public DbSet<EntranceWarehouse> EntranceWarehouses => Set<EntranceWarehouse>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(WarehouseDbContext).Assembly);
        }

        public override int SaveChanges()
        {
            throw new InvalidOperationException("WarehouseDbContext is read-only.");
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            throw new InvalidOperationException("WarehouseDbContext is read-only.");
        }
    }

}
