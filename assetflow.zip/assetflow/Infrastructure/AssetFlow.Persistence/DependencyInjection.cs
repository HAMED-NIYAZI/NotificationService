﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Persistence.DbContext;
using AssetFlow.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace AssetFlow.Persistence;

public static class DependencyInjection
{
    public static IServiceCollection AddAllPersistenceServices(this IServiceCollection services)
    {
        services.AddScoped<ICdcTradeRepository, CdcTradeRepository>();
        services.AddScoped<IAssetTransactionRepository, AssetTransactionRepository>();
        services.AddScoped<IAssetAllocationRepository, AssetAllocationRepository>();
        services.AddScoped<IWarehouseRepository, WarehouseRepository>();
        services.AddScoped<ISymbolRepository, SymbolRepository>();
        services.AddScoped<IAssetLogRepository, AssetLogRepository>();
        services.AddScoped<IAssetProcessRepository, AssetProcessRepository>();
        services.AddScoped<IAssetProcessDetailRepository, AssetProcessDetailRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddSingleton<IAllocationStateStore, AllocationStateStore>();
        services.AddSingleton<IAllocationStateRepository, AllocationStateRepository>();
        services.AddScoped<IMarketRepository, MarketRepository>();
        services.AddScoped<ICustomerRepository, CustomerRepository>();
        return services;
    }

    public static IServiceCollection AddDbContext(this IServiceCollection services, IConfiguration configuration)
    {
        string? assetFlowConnectionString = configuration.GetConnectionString("AssetFlowConnection");

        services.AddDbContext<AssetFlowDbContext>(
            options => options.UseSqlServer(assetFlowConnectionString),
            optionsLifetime: ServiceLifetime.Singleton);

        services.AddDbContext<CdcDbContext>(options =>
        {
            options.UseSqlServer(configuration.GetConnectionString("CDCDbConnection"));
            options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
        });



        services.AddDbContextFactory<AssetFlowDbContext>(options =>
        {
            options.UseSqlServer(assetFlowConnectionString, x => x.CommandTimeout(600));
        });

        return services;
    }


}