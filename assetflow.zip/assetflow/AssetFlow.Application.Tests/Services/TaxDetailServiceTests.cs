﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Application.TaxDetail.Dtos;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Dtos;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using AssetFlow.Persistence.IntegrationTests.Fixtures;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Data;
namespace AssetFlow.Application.IntegrationTests.Services;

public class TaxDetailServiceTests : IAsyncLifetime
{
    private CustomWebApplicationFactory? factory;
    private AsyncServiceScope scope;

    public async Task InitializeAsync()
    {
        factory = new CustomWebApplicationFactory();
        scope = factory.Services.CreateAsyncScope();
    }

    public async Task DisposeAsync()
    {
        await scope.DisposeAsync();
        await factory.DisposeAsync();
    }

    [Fact]
    public async Task GetTaxSummariesByUniqueIdSaveTransactionAllocateCreateAssetProcessCreateAssetProcessDetail()
    {
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();

        int symbolId = 41;
        int warehouseId = 38;
        int uniqueId = 996666;
        long referenceId = DateTime.UtcNow.Ticks;
        DateTime assetTransactionCreateDate = DateTime.Now;

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction1 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 1,
            Price = 100,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(1),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction2 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 110,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(2),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };




        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction3 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 3,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(3),
            Status = AssetTransactionStatus.UnTouched,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction4 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 4,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction5 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 5,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(5),
            Status = AssetTransactionStatus.UnTouched,
        };



        await assetTransactionRepository.AddAsync(transaction1);
        await assetTransactionRepository.AddAsync(transaction2);
        await assetTransactionRepository.AddAsync(transaction3);
        await assetTransactionRepository.AddAsync(transaction4);
        await assetTransactionRepository.AddAsync(transaction5);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();



        //چک کردن موجودی
        AssetAllocation AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });


        //AvailableAssetAllocation.AvailableQuantity.Should().Be((transaction1.Quantity + transaction2.Quantity + transaction3.Quantity - transaction4.Quantity - transaction5.Quantity));

        AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity + transaction3.Quantity - transaction4.Quantity);

        //چک کردن حاصل  اعلامیه خروج
        ResponseModel<AssetProcessDto> data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeFalse();
        data.StatusCode.Should().Be(404);
        data.Data.Should().Be(null);

    }

    [Fact]
    public async Task GetClearanceTaxSummarySaveTransactionAllocateCreateAssetProcessCreateAssetProcessDetail()
    {
        // 1. تنظیم داده‌های اولیه
        int symbolId = 41;
        int warehouseId = 38;
        int uniqueId = 996666;
        long referenceId = DateTime.UtcNow.Ticks;

        DateTime assetTransactionCreateDate = DateTime.Now;


        // 2. ساخت Mock سرویس خارجی
        Mock<ICdcWarehouseManagementService> mockCdcService = new();
        CustomerBalanceDto expectedBalance = new()
        {
            AssetOwnerUniqueCode = uniqueId,
            Balance = 0.5   // چون نهایتاً موجودی 5 می‌شود و ContractRate=10 => 1.2*5=0.5
        };
        mockCdcService
            .Setup(x => x.GetCustomerBalanceAsync(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<DateTime>()))
            .ReturnsAsync(expectedBalance);

        // 3. ساختن WebApplicationFactory و جایگزینی سرویس خارجی با Mock
        WebApplicationFactory<Program> factory_ = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                // حذف سرویس واقعی
                ServiceDescriptor? descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(ICdcWarehouseManagementService));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // افزودن Mock
                services.AddScoped<ICdcWarehouseManagementService>(_ => mockCdcService.Object);
            });
        });

        // 4. دریافت سرویس‌های مورد نیاز از Factory
        using IServiceScope scope = factory_.Services.CreateScope();
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
        IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
        IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction1 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 5,
            Price = 100,
            AssetTransactionCreateDate = DateTime.Now.AddMilliseconds(111),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction11 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 10,
            Price = 110,
            AssetTransactionCreateDate = DateTime.Now.AddMilliseconds(222),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction2 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 15,
            Price = 120,
            AssetTransactionCreateDate = DateTime.Now.AddMilliseconds(333),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction3 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 3,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMilliseconds(444),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction4 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 22,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMilliseconds(555),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };



        await assetTransactionRepository.AddAsync(transaction1);
        await assetTransactionRepository.AddAsync(transaction11);
        await assetTransactionRepository.AddAsync(transaction2);
        await assetTransactionRepository.AddAsync(transaction3);
        await assetTransactionRepository.AddAsync(transaction4);
        await unitOfWork.SaveChangesAsync();
        //  await allocatorJob.ExecuteBatchAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();



        //چک کردن موجودی
        AssetAllocation AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });


        AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction11.Quantity + transaction2.Quantity - transaction3.Quantity - transaction4.Quantity);


        //چک کردن حاصل  اعلامیه خروج
        ResponseModel<AssetProcessDto?> data = await taxDetailService.GetClearanceTaxSummary(new GetClearanceTaxSummaryRequest { FromAmount = 1, ToAmount = 6, ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.ReferenceId.Should().Be(referenceId);
        data.Data.WarehouseId.Should().Be(warehouseId);
        data.Data.UniqueId.Should().Be(uniqueId);
        data.Data.AssetProcessDetails.Should().NotBeNull();
        data.Data.AssetProcessDetails.Should().NotBeEmpty();
        data.Data.AssetProcessDetails.Count.Should().BeGreaterThan(0);
        data.Data.AssetProcessDetails.Sum(x => x.Quantity).Should().Be(data.Data.Quantity);
        decimal totalQuantity = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity);
        decimal totalValue = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity * x.Price);
        decimal expectedAverage = totalQuantity != 0 ? (totalValue / totalQuantity) : 0;
        //data.Data.AveragePrice.Should().Be(expectedAverage);

        data.Data.WarehouseId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId);
        data.Data.SymbolId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.SymbolId).FirstOrDefault().SymbolId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.Type.Should().Be(AssetProcessDetailType.Clearance);

        await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();

    }

    [Fact]
    public async Task GetTaxSummaries()
    {
        IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();



        #region customerId1
        int symbolId1 = 41;
        int warehouseId1 = 38;
        int uniqueId1 = 220106665;
        long referenceId1 = DateTime.UtcNow.AddMilliseconds(uniqueId1).Ticks;

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction1_1 = new()
        {
            Id = 0,

            UniqueId = uniqueId1,
            SymbolId = symbolId1,
            WarehouseId = warehouseId1,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 100,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(111),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction1_2 = new()
        {
            Id = 0,

            UniqueId = uniqueId1,
            SymbolId = symbolId1,
            WarehouseId = warehouseId1,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 3,
            Price = 110,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(222),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction1_3 = new()
        {
            Id = 0,

            UniqueId = uniqueId1,
            SymbolId = symbolId1,
            WarehouseId = warehouseId1,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 5,
            Price = 120,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(333),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction1_4 = new()
        {
            Id = 0,

            UniqueId = uniqueId1,
            SymbolId = symbolId1,
            WarehouseId = warehouseId1,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 6,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(444),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction1_5 = new()
        {
            Id = 0,

            UniqueId = uniqueId1,
            SymbolId = symbolId1,
            WarehouseId = warehouseId1,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId1,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 4,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(555),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };



        await assetTransactionRepository.AddAsync(transaction1_1);
        await assetTransactionRepository.AddAsync(transaction1_2);
        await assetTransactionRepository.AddAsync(transaction1_3);
        await assetTransactionRepository.AddAsync(transaction1_4);
        await assetTransactionRepository.AddAsync(transaction1_5);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.ExecuteBatchAsync();
        #endregion customerId1




        #region customerId2
        int symbolId2 = 41;
        int warehouseId2 = 38;
        int uniqueId2 = 2011201165;
        long referenceId2 = DateTime.UtcNow.AddMilliseconds(uniqueId2).Ticks;

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction2_1 = new()
        {
            Id = 0,

            UniqueId = uniqueId2,
            SymbolId = symbolId2,
            WarehouseId = warehouseId2,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 5,
            Price = 100,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(111),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction2_2 = new()
        {
            Id = 0,

            UniqueId = uniqueId2,
            SymbolId = symbolId2,
            WarehouseId = warehouseId2,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 5,
            Price = 110,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(222),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction2_3 = new()
        {
            Id = 0,

            UniqueId = uniqueId2,
            SymbolId = symbolId2,
            WarehouseId = warehouseId2,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 25,
            Price = 120,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(333),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction2_4 = new()
        {
            Id = 0,

            UniqueId = uniqueId2,
            SymbolId = symbolId2,
            WarehouseId = warehouseId2,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 25,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(444),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction2_5 = new()
        {
            Id = 0,

            UniqueId = uniqueId2,
            SymbolId = symbolId2,
            WarehouseId = warehouseId2,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId2,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 5,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(555),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };



        await assetTransactionRepository.AddAsync(transaction2_1);
        await assetTransactionRepository.AddAsync(transaction2_2);
        await assetTransactionRepository.AddAsync(transaction2_3);
        await assetTransactionRepository.AddAsync(transaction2_4);
        await assetTransactionRepository.AddAsync(transaction2_5);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.ExecuteBatchAsync();
        #endregion customerId2





        #region customerId3

        int symbolId3 = 41;
        int warehouseId3 = 38;
        int uniqueId3 = 2012201265;
        long referenceId3 = DateTime.UtcNow.AddSeconds(uniqueId3).Ticks;

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction3_1 = new()
        {
            Id = 0,

            UniqueId = uniqueId3,
            SymbolId = symbolId3,
            WarehouseId = warehouseId3,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 100,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(111),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction3_2 = new()
        {
            Id = 0,

            UniqueId = uniqueId3,
            SymbolId = symbolId3,
            WarehouseId = warehouseId3,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 110,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(222),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction3_3 = new()
        {
            Id = 0,

            UniqueId = uniqueId3,
            SymbolId = symbolId3,
            WarehouseId = warehouseId3,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 11,
            Price = 120,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(333),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction3_4 = new()
        {
            Id = 0,

            UniqueId = uniqueId3,
            SymbolId = symbolId3,
            WarehouseId = warehouseId3,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 8,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(444),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction3_5 = new()
        {
            Id = 0,

            UniqueId = uniqueId3,
            SymbolId = symbolId3,
            WarehouseId = warehouseId3,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId3,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 6,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now.AddMicroseconds(555),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };



        await assetTransactionRepository.AddAsync(transaction3_1);
        await assetTransactionRepository.AddAsync(transaction3_2);
        await assetTransactionRepository.AddAsync(transaction3_3);
        await assetTransactionRepository.AddAsync(transaction3_4);
        await assetTransactionRepository.AddAsync(transaction3_5);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.ExecuteBatchAsync();
        #endregion customerId3




        //چک کردن موجودی
        AssetAllocation AvailableAssetAllocation1 = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
        AvailableAssetAllocation1.AvailableQuantity.Should().Be(transaction1_1.Quantity + transaction1_2.Quantity + transaction1_3.Quantity - transaction1_4.Quantity - transaction1_5.Quantity);


        AssetAllocation AvailableAssetAllocation2 = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
        AvailableAssetAllocation2.AvailableQuantity.Should().Be(transaction2_1.Quantity + transaction2_2.Quantity + transaction2_3.Quantity - transaction2_4.Quantity - transaction2_5.Quantity);


        AssetAllocation AvailableAssetAllocation3 = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry { WarehouseId = warehouseId3, SymbolId = symbolId3, UniqueId = uniqueId3 });
        AvailableAssetAllocation3.AvailableQuantity.Should().Be(transaction3_1.Quantity + transaction3_2.Quantity + transaction3_3.Quantity - transaction3_4.Quantity - transaction3_5.Quantity);




        //چک کردن حاصل  اعلامیه خروج
        ResponseModel<List<AssetProcessDto>?> data = await taxDetailService.GetTaxSummaries(new GetSellTaxSummariesRequest { WarehouseGroupId = 38, TaxDate = DateTime.Now.AddMicroseconds(555) });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId.Should().Be(warehouseId1);
        data.Data[0].AssetProcessDetails.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId.Should().Be(warehouseId2);
        data.Data.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId.Should().Be(warehouseId3);

        List<AssetProcessDetailDto> allProcessDetail = [];
        List<AssetProcessDto> allProcess = data.Data.ToList();


        foreach (AssetProcessDto? process in allProcess)
        {
            foreach (AssetProcessDetailDto detail in process.AssetProcessDetails)
            {
                allProcessDetail.Add(detail);
            }
        }

        allProcessDetail.Sum(x => x.Quantity).Should().Be(allProcess.Sum(x => x.Quantity));
        allProcessDetail.Sum(x => x.Price * x.Quantity).Should().Be(allProcess.Sum(x => x.TotalPrice));


        data.Data.Should().NotBeNull();
        data.Data.Should().NotBeEmpty();
        data.Data.Count.Should().BeGreaterThan(0);
        data.Data[0].Type.Should().Be(AssetProcessDetailType.Sell);
    }

    [Fact]
    public async Task GetTaxSummariesByCustomerImeSaveTransactionAllocateCreateAssetProcessCreateAssetProcessDetail()
    {
        // 1. تنظیم داده‌های اولیه


        int symbolId = 41;
        int warehouseId = 38;
        int uniqueId = 996666;
        long referenceId = DateTime.UtcNow.Ticks;
        DateTime assetTransactionCreateDate = DateTime.Now;

        // 2. ساخت Mock سرویس خارجی
        Mock<ICdcWarehouseManagementService> mockCdcService = new();
        CustomerBalanceDto expectedBalance = new()
        {
            AssetOwnerUniqueCode = uniqueId,
            Balance = .5   // چون نهایتاً موجودی 5 می‌شود و ContractRate=10 => 0.5*10=5
        };
        mockCdcService
            .Setup(x => x.GetCustomerBalanceAsync(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<DateTime>()))
            .ReturnsAsync(expectedBalance);

        // 3. ساختن WebApplicationFactory و جایگزینی سرویس خارجی با Mock
        WebApplicationFactory<Program> factory_ = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                // حذف سرویس واقعی
                ServiceDescriptor? descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(ICdcWarehouseManagementService));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // افزودن Mock
                services.AddScoped<ICdcWarehouseManagementService>(_ => mockCdcService.Object);
            });
        });

        // 4. دریافت سرویس‌های مورد نیاز از Factory
        using IServiceScope scope = factory_.Services.CreateScope();
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
        IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();



        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction1 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 5,
            Price = 100,
            AssetTransactionCreateDate = DateTime.Now,
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        // ایجاد یک تراکنش Buy
        Domain.Entities.AssetTransaction transaction11 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 10,
            Price = 110,
            AssetTransactionCreateDate = DateTime.Now,
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };




        // ایجاد یک تراکنش Entry
        Domain.Entities.AssetTransaction transaction2 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 10,
            Price = 120,
            AssetTransactionCreateDate = DateTime.Now,
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };


        // ایجاد یک تراکنش SELL
        Domain.Entities.AssetTransaction transaction3 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 10,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now,
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction4 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 10,
            Price = 125,
            AssetTransactionCreateDate = DateTime.Now,
            Status = AssetTransactionStatus.UnTouched,
            TradeType = 0,
        };



        await assetTransactionRepository.AddAsync(transaction1);
        await assetTransactionRepository.AddAsync(transaction11);
        await assetTransactionRepository.AddAsync(transaction2);
        await assetTransactionRepository.AddAsync(transaction3);
        await assetTransactionRepository.AddAsync(transaction4);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.ExecuteBatchAsync();



        //چک کردن موجودی
        AssetAllocation AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });


        AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction11.Quantity + transaction2.Quantity - transaction3.Quantity - transaction4.Quantity);


        //چک کردن حاصل  اعلامیه خروج
        ResponseModel<AssetProcessDto?> data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { UniqueId = uniqueId, ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.ReferenceId.Should().Be(referenceId);
        data.Data.WarehouseId.Should().Be(warehouseId);
        data.Data.UniqueId.Should().Be(uniqueId);
        data.Data.AssetProcessDetails.Should().NotBeNull();
        data.Data.AssetProcessDetails.Should().NotBeEmpty();
        data.Data.AssetProcessDetails.Count.Should().BeGreaterThan(0);
        data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity).Should().Be(data.Data.Quantity);
        decimal totalQuantity = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity);
        decimal totalValue = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity * x.Price);
        decimal expectedAverage = totalQuantity != 0 ? (totalValue / totalQuantity) : 0;
        //data.Data.AveragePrice.Should().Be(expectedAverage);

        data.Data.WarehouseId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId);
        data.Data.SymbolId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.SymbolId).FirstOrDefault().SymbolId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.Type.Should().Be(AssetProcessDetailType.Clearance);

        await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();

    }

    [Fact]
    public async Task GetTaxSummariesByUniqueId_SaveTransactionAllocateCreateAssetProcessCreateAssetProcessDetail_WithNewMethods()
    {

        #region init
        // 1. تنظیم داده‌های اولیه
        int symbolId = 41;
        int warehouseId = 38;
        int uniqueId = 996666;
        long referenceId = DateTime.UtcNow.Ticks;
        DateTime assetTransactionCreateDate = DateTime.Now;

        // 2. ساخت Mock سرویس خارجی
        Mock<ICdcWarehouseManagementService> mockCdcService = new();
        CustomerBalanceDto expectedBalance = new()
        {
            AssetOwnerUniqueCode = uniqueId,
            Balance = 1.2   // چون نهایتاً موجودی ۱۲ می‌شود و ContractRate=10 => 1.2*10=12
        };
        mockCdcService
            .Setup(x => x.GetCustomerBalanceAsync(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<DateTime>()))
            .ReturnsAsync(expectedBalance);

        // 3. ساختن WebApplicationFactory و جایگزینی سرویس خارجی با Mock
        WebApplicationFactory<Program> factory_ = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                // حذف سرویس واقعی
                ServiceDescriptor? descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(ICdcWarehouseManagementService));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // افزودن Mock
                services.AddScoped<ICdcWarehouseManagementService>(_ => mockCdcService.Object);
            });
        });

        // 4. دریافت سرویس‌های مورد نیاز از Factory
        using IServiceScope scope = factory_.Services.CreateScope();
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
        IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();

        #endregion init

        // ایجاد یک تراکنش Buy 1
        Domain.Entities.AssetTransaction transaction1 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 1,
            Price = 100,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(1),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        // ایجاد یک تراکنش Buy 2
        Domain.Entities.AssetTransaction transaction2 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 110,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(2),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        // ایجاد یک تراکنش Entry 3
        Domain.Entities.AssetTransaction transaction3 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 3,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(3),
            Status = AssetTransactionStatus.UnTouched,
        };

        // ایجاد یک تراکنش SELL -4
        Domain.Entities.AssetTransaction transaction4 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 4,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };


        // ایجاد یک تراکنش C -90
        Domain.Entities.AssetTransaction transaction5 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 90,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(5),
            Status = AssetTransactionStatus.UnTouched,
        };



        await assetTransactionRepository.AddAsync(transaction1);
        await assetTransactionRepository.AddAsync(transaction2);
        await assetTransactionRepository.AddAsync(transaction3);
        await assetTransactionRepository.AddAsync(transaction4);
        await assetTransactionRepository.AddAsync(transaction5);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();



        //چک کردن موجودی
        AssetAllocation AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });



        AvailableAssetAllocation.AvailableQuantity.Should().NotBe(1 + 2 + 3 - 4 - 90);
        AvailableAssetAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4);

        //چک کردن حاصل  اعلامیه خروج
        ResponseModel<AssetProcessDto> data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeFalse();
        data.StatusCode.Should().Be(404);
        data.Data.Should().Be(null);

        //Rebuild

        // ایجاد یک تراکنش E
        Domain.Entities.AssetTransaction transaction6 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 88312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 100,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4).AddSeconds(30),
            Status = AssetTransactionStatus.UnTouched,
        };
        await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();




        //چک کردن موجودی
        AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });


        List<Domain.Entities.AssetTransaction> li = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).ToList();
        AvailableAssetAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4 + 100 - 90);


        //چک کردن حاصل  اعلامیه خروج
        data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.Should().NotBe(null);



        data.Data.WarehouseId.Should().Be(warehouseId);
        data.Data.UniqueId.Should().Be(uniqueId);
        data.Data.AssetProcessDetails.Should().NotBeNull();
        data.Data.AssetProcessDetails.Should().NotBeEmpty();
        data.Data.AssetProcessDetails.Count.Should().BeGreaterThan(0);
        data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity).Should().Be(data.Data.Quantity);
        decimal totalQuantity = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity);
        decimal totalValue = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity * x.Price);
        decimal expectedAverage = totalQuantity != 0 ? (totalValue / totalQuantity) : 0;

        data.Data.WarehouseId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId);
        data.Data.SymbolId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.SymbolId).FirstOrDefault().SymbolId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.Type.Should().Be(AssetProcessDetailType.Clearance);
        data.Data.Status.Should().Be(AssetProcessDetailStatus.Committed);
        List<AssetProcessDetailDto> detailAssetProcessDetails = data.Data.AssetProcessDetails.ToList();
        foreach (AssetProcessDetailDto? item in detailAssetProcessDetails)
        {
            item.Status.Should().Be(AssetProcessDetailStatus.Committed);
        }

        #region Rebuild 2
        // ایجاد یک تراکنش C
        Domain.Entities.AssetTransaction transaction7 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 99312322,
            ClearanceId = 0,
            ReferenceId = referenceId + 1,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 1,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4).AddSeconds(25),
            Status = AssetTransactionStatus.UnTouched,
        };
        await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();




        //چک کردن موجودی
        AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });



        AvailableAssetAllocation.AvailableQuantity.Should().NotBe(1 + 2 + 3 - 4 - 1 + 100 - 90);
        AvailableAssetAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4 + 100 - 90);



        //چک کردن حاصل  اعلامیه خروج
        data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.Should().NotBe(null);



        data.Data.WarehouseId.Should().Be(warehouseId);
        data.Data.UniqueId.Should().Be(uniqueId);
        data.Data.AssetProcessDetails.Should().NotBeNull();
        data.Data.AssetProcessDetails.Should().NotBeEmpty();
        data.Data.AssetProcessDetails.Count.Should().BeGreaterThan(0);
        data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity).Should().Be(data.Data.Quantity);
        totalQuantity = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity);
        totalValue = data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity * x.Price);
        expectedAverage = totalQuantity != 0 ? (totalValue / totalQuantity) : 0;

        data.Data.WarehouseId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.WarehouseId).FirstOrDefault().WarehouseId);
        data.Data.SymbolId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.SymbolId).FirstOrDefault().SymbolId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.UniqueId.Should().Be(data.Data.AssetProcessDetails.DistinctBy(x => x.UniqueId).FirstOrDefault().UniqueId);
        data.Data.Type.Should().Be(AssetProcessDetailType.Clearance);


        #endregion Rebuild 2


        await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();


    }

    [Fact]
    public async Task GetTaxSummariesByUniqueId2()
    {
        // 1. تنظیم داده‌های اولیه
        int symbolId = 41;
        int warehouseId = 38;
        int uniqueId = 996666;
        long referenceId = DateTime.UtcNow.Ticks;
        DateTime assetTransactionCreateDate = DateTime.Now;

        // 2. ساخت Mock سرویس خارجی
        Mock<ICdcWarehouseManagementService> mockCdcService = new();
        CustomerBalanceDto expectedBalance = new()
        {
            AssetOwnerUniqueCode = uniqueId,
            Balance = 1.2   // چون نهایتاً موجودی ۱۲ می‌شود و ContractRate=10 => 1.2*10=12
        };
        mockCdcService
            .Setup(x => x.GetCustomerBalanceAsync(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<DateTime>()))
            .ReturnsAsync(expectedBalance);

        // 3. ساختن WebApplicationFactory و جایگزینی سرویس خارجی با Mock
        WebApplicationFactory<Program> factory_ = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                // حذف سرویس واقعی
                ServiceDescriptor? descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(ICdcWarehouseManagementService));
                if (descriptor != null)
                {
                    services.Remove(descriptor);
                }

                // افزودن Mock
                services.AddScoped<ICdcWarehouseManagementService>(_ => mockCdcService.Object);
            });
        });

        // 4. دریافت سرویس‌های مورد نیاز از Factory
        using IServiceScope scope = factory_.Services.CreateScope();
        AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
        IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
        IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
        IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
        ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
        IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();

        // (اگر نیاز به WarehouseGroupTaxRule دارید می‌توانید دریافت کنید)
        // var warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();

        // 5. ایجاد تراکنش‌ها   Buy 1
        Domain.Entities.AssetTransaction transaction1 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 332323233,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 1,
            Price = 100,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(1),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        //Buy 2
        Domain.Entities.AssetTransaction transaction2 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 32132132122,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Buy,
            Direction = AssetDirection.In,
            Quantity = 2,
            Price = 110,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(2),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        //Entry 3
        Domain.Entities.AssetTransaction transaction3 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 77312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 3,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(3),
            Status = AssetTransactionStatus.UnTouched,
        };

        //Sell -4
        Domain.Entities.AssetTransaction transaction4 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 8823121,
            EntranceId = 0,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Sell,
            Direction = AssetDirection.Out,
            Quantity = 4,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4),
            Status = AssetTransactionStatus.UnTouched,
            TradeType = TradeType.Trade,
        };

        //Clearance -90
        Domain.Entities.AssetTransaction transaction5 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = 0,
            EntranceId = 0,
            ClearanceId = 949,
            ReferenceId = referenceId,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 90,
            Price = 125,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(5),
            Status = AssetTransactionStatus.UnTouched,
        };

        // 6. ذخیره تراکنش‌ها و اجرای تخصیص
        await assetTransactionRepository.AddAsync(transaction1);
        await assetTransactionRepository.AddAsync(transaction2);
        await assetTransactionRepository.AddAsync(transaction3);
        await assetTransactionRepository.AddAsync(transaction4);
        await assetTransactionRepository.AddAsync(transaction5);
        await unitOfWork.SaveChangesAsync();

        await allocatorJob.GetAllTransactionsAndAllocateBySingle();

        // 7. بررسی موجودی اولیه
        AssetAllocation availableAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });

        availableAllocation.AvailableQuantity.Should().NotBe(1 + 2 + 3 - 4 - 90);
        availableAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4); // 2

        // 8. بررسی اعلامیه خروج (قبل از ری‌بیلد) – باید 404 باشد
        ResponseModel<AssetProcessDto> data = await taxDetailService.GetTaxSummariesByUniqueId(
            new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeFalse();
        data.StatusCode.Should().Be(404);
        data.Data.Should().BeNull();

        // 9. ری‌بیلد – اضافه کردن یک تراکنش Entry جدید     Entry 100
        Domain.Entities.AssetTransaction transaction6 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 88312322,
            ClearanceId = 0,
            ReferenceId = 0,
            Type = AssetTransactionType.Entry,
            Direction = AssetDirection.In,
            Quantity = 100,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4).AddSeconds(30),
            Status = AssetTransactionStatus.UnTouched,
        };
        await assetTransactionRepository.AddAsync(transaction6);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();

        // 10. بررسی موجودی پس از ری‌بیلد
        availableAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });
        availableAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4 + 100 - 90); // 12

        // 11. بررسی اعلامیه خروج (پس از ری‌بیلد) – باید موفق باشد
        data = await taxDetailService.GetTaxSummariesByUniqueId(
            new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        data.Data.Should().NotBeNull();

        // 12. اعتبارسنجی جزئیات اعلامیه
        data.Data.WarehouseId.Should().Be(warehouseId);
        data.Data.UniqueId.Should().Be(uniqueId);
        data.Data.AssetProcessDetails.Should().NotBeNull();
        data.Data.AssetProcessDetails.Should().NotBeEmpty();
        data.Data.AssetProcessDetails.Count.Should().BeGreaterThan(0);
        data.Data.AssetProcessDetails.Where(x => x.Included).Sum(x => x.Quantity).Should().Be(data.Data.Quantity);
        data.Data.Type.Should().Be(AssetProcessDetailType.Clearance);
        data.Data.Status.Should().Be(AssetProcessDetailStatus.Committed);
        data.Data.AssetProcessDetails.All(x => x.Status == AssetProcessDetailStatus.Committed).Should().BeTrue();

        // 13. ری‌بیلد دوم – اضافه کردن یک تراکنش Clearance دیگر    Clearance 1
        Domain.Entities.AssetTransaction transaction7 = new()
        {
            Id = 0,

            UniqueId = uniqueId,
            SymbolId = symbolId,
            WarehouseId = warehouseId,
            TradeId = null,
            EntranceId = 99312322,
            ClearanceId = 0,
            ReferenceId = referenceId + 1,
            Type = AssetTransactionType.Clearance,
            Direction = AssetDirection.Out,
            Quantity = 1,
            Price = 120,
            AssetTransactionCreateDate = assetTransactionCreateDate.AddMinutes(4).AddSeconds(25),
            Status = AssetTransactionStatus.UnTouched,
        };
        await assetTransactionRepository.AddAsync(transaction7);
        await unitOfWork.SaveChangesAsync();
        await allocatorJob.GetAllTransactionsAndAllocateBySingle();

        // 14. بررسی موجودی نهایی
        availableAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
        {

            WarehouseId = warehouseId,
            SymbolId = symbolId,
            UniqueId = uniqueId
        });
        availableAllocation.AvailableQuantity.Should().Be(1 + 2 + 3 - 4 + 100 - 90);//12

        // 15. بررسی اعلامیه خروج باز هم موفق
        data = await taxDetailService.GetTaxSummariesByUniqueId(
            new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
        data.IsSuccess.Should().BeTrue();
        data.StatusCode.Should().Be(200);
        //data.Data.Should().NotBeNull();
        //data.Data.UniqueId.Should().Be(uniqueId);
        await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();
    }
}
