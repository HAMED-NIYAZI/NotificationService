﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Application.TaxDetail.Dtos;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Dtos;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using AssetFlow.Persistence.IntegrationTests.Fixtures;
using Castle.Core.Resource;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.CodeAnalysis;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Polly;

namespace AssetFlow.Application.IntegrationTests.Services
{
    public class AssetTransactionProcessServiceTests : IAsyncLifetime
    {
        private CustomWebApplicationFactory? factory;
        private AsyncServiceScope scope;

        public async Task InitializeAsync()
        {
            factory = new CustomWebApplicationFactory();
            scope = factory.Services.CreateAsyncScope();
        }


        [Fact]
        public async Task SaveAssettransactionAllocateThenGetNullTaxSummaries()
        {

            // 1. تنظیم داده‌های اولیه
            int symbolId = 43;
            int warehouseId = 40;
            int uniqueId = 201420141;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime assetTransactionCreateDate = DateTime.Now;


            // 2. ساخت Mock سرویس خارجی
            Mock<ICdcWarehouseManagementService> mockCdcService = new();
            CustomerBalanceDto expectedBalance = new()
            {
                AssetOwnerUniqueCode = uniqueId,
                Balance = 0.5   // چون نهایتاً موجودی 5 می‌شود و ContractRate=10 => 1.2*5=0.5
            };
            mockCdcService
                .Setup(x => x.GetCustomerBalanceAsync(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<DateTime>()))
                .ReturnsAsync(expectedBalance);

            // 3. ساختن WebApplicationFactory و جایگزینی سرویس خارجی با Mock
            WebApplicationFactory<Program> factory_ = factory.WithWebHostBuilder(builder =>
            {
                builder.ConfigureTestServices(services =>
                {
                    // حذف سرویس واقعی
                    ServiceDescriptor? descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(ICdcWarehouseManagementService));
                    if (descriptor != null) services.Remove(descriptor);

                    // افزودن Mock
                    services.AddScoped<ICdcWarehouseManagementService>(_ => mockCdcService.Object);
                });
            });

            // 4. دریافت سرویس‌های مورد نیاز از Factory
            using IServiceScope scope = factory_.Services.CreateScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();






            //var context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();

            // await ClearAllTablesAsync(context);



            // ایجاد یک تراکنش Buy
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 5,
                Price = 100,
                AssetTransactionCreateDate = DateTime.Now,
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };

            // ایجاد یک تراکنش Buy
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262222,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 110,
                AssetTransactionCreateDate = DateTime.Now,
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };




            // ایجاد یک تراکنش Entry
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = DateTime.Now,
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            // ایجاد یک تراکنش SELL
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 10,
                Price = 125,
                AssetTransactionCreateDate = DateTime.Now,
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };


            // ایجاد یک تراکنش C
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 10,
                Price = 125,
                AssetTransactionCreateDate = DateTime.Now,
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };



            await assetTransactionRepository.AddAsync(transaction1);
            await assetTransactionRepository.AddAsync(transaction2);
            await assetTransactionRepository.AddAsync(transaction3);
            await assetTransactionRepository.AddAsync(transaction4);
            await assetTransactionRepository.AddAsync(transaction5);
            await unitOfWork.SaveChangesAsync();
            // await allocatorJob.ExecuteBatchAsync();


            #region processtransaction1
            bool processtransaction = await assetTransactionProcessService.ProcessAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();

            //چک کردن موجودی
            AssetAllocation AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
            {
                WarehouseId = warehouseId,
                SymbolId = symbolId,
                UniqueId = uniqueId
            });
            AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity);
            #endregion processtransaction1


            #region processtransaction2
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();

            //چک کردن موجودی
            AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
            {
                WarehouseId = warehouseId,
                SymbolId = symbolId,
                UniqueId = uniqueId
            });
            AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity);



            //چک کردن حاصل  اعلامیه خروج ref نامعتبر است
            ResponseModel<AssetProcessDto> data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
            data.IsSuccess.Should().BeFalse();
            data.StatusCode.Should().Be(404);
            data.Data.Should().BeNull();

            #endregion processtransaction2


            #region processtransaction3
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();

            //چک کردن موجودی
            AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
            {
                WarehouseId = warehouseId,
                SymbolId = symbolId,
                UniqueId = uniqueId
            });
            AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity + transaction3.Quantity);
            //چک کردن حاصل  اعلامیه خروج ref نامعتبر است
            data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
            data.IsSuccess.Should().BeFalse();
            data.StatusCode.Should().Be(404);
            data.Data.Should().BeNull();

            #endregion processtransaction3


            #region processtransaction4
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();

            //چک کردن موجودی
            AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
            {
                WarehouseId = warehouseId,
                SymbolId = symbolId,
                UniqueId = uniqueId
            });
            AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity + transaction3.Quantity - transaction4.Quantity);
            //چک کردن حاصل  اعلامیه خروج ref نامعتبر است
            data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
            data.IsSuccess.Should().BeFalse();
            data.StatusCode.Should().Be(404);
            data.Data.Should().BeNull();

            #endregion processtransaction4

            #region processtransaction5
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction5);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();

            //چک کردن موجودی
            AvailableAssetAllocation = await assetAllocationRepository.GetLatestSnapshot(new AssetEntry
            {
                WarehouseId = warehouseId,
                SymbolId = symbolId,
                UniqueId = uniqueId
            });
            AvailableAssetAllocation.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity + transaction3.Quantity - transaction4.Quantity - transaction4.Quantity);
            //چک کردن حاصل  اعلامیه خروج ref نامعتبر است
            data = await taxDetailService.GetTaxSummariesByUniqueId(new GetTaxSummariesByUniqueIdRequest { ReferenceId = referenceId });
            data.IsSuccess.Should().BeTrue();
            data.StatusCode.Should().Be(200);
            data.Data.Should().NotBeNull();
            data.Data.ReferenceId.Should().Be(referenceId);

            #endregion processtransaction5

            await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();
        }

        [Fact]
        public async Task AllocationForMinusData()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 43;
            int warehouseId = 40;
            int uniqueId = 201420141;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion


            // ایجاد یک تراکنش Buy 5
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 5,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };


            // ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262222,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 110,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };


            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            // ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };


            // ایجاد یک تراکنش C 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 10,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };



            await assetTransactionRepository.AddAsync(transaction1);
            await assetTransactionRepository.AddAsync(transaction2);
            await assetTransactionRepository.AddAsync(transaction3);
            await assetTransactionRepository.AddAsync(transaction4);
            await assetTransactionRepository.AddAsync(transaction5);
            await unitOfWork.SaveChangesAsync();



            #region processtransaction1
            bool processtransaction = await assetTransactionProcessService.ProcessAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();


            #endregion processtransaction1


            #region processtransaction2
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();


            #endregion processtransaction2


            #region processtransaction3
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeTrue();



            #endregion processtransaction3


            #region processtransaction4
            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeFalse();





            #endregion processtransaction4

            #region processtransaction5

            processtransaction = await assetTransactionProcessService.ProcessAsync(transaction5);
            await unitOfWork.SaveChangesAsync();
            processtransaction.Should().BeFalse();


            #endregion processtransaction5


            List<AssetAllocation> allocationtransaction1 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction1.Id).ToList();
            List<AssetAllocation> allocationtransaction2 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction2.Id).ToList();
            List<AssetAllocation> allocationtransaction3 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction3.Id).ToList();
            List<AssetAllocation> allocationtransaction4 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction4.Id).ToList();
            List<AssetAllocation> allocationtransaction5 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction5.Id).ToList();
            allocationtransaction4.Count.Should().Be(0);
            allocationtransaction5.Count.Should().Be(0);




            #region processtransaction1_5

            // ایجاد یک تراکنش sell و ریبیلد
            Domain.Entities.AssetTransaction transaction1_5 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262222 + 4,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 4,
                Price = 110,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1).AddMinutes(15),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };



            await assetTransactionRepository.AddAsync(transaction1_5);
            await unitOfWork.SaveChangesAsync();

            await allocatorJob.ReBuildAndAllocate(transaction1_5);
            await unitOfWork.SaveChangesAsync();


            allocationtransaction1 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction1.Id).ToList();
            allocationtransaction2 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction2.Id).ToList();
            allocationtransaction3 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction3.Id).ToList();
            allocationtransaction4 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction4.Id).ToList();
            allocationtransaction5 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction5.Id).ToList();
            List<AssetAllocation> allocationtransaction1_5 = context.AssetAllocations.Where(x => x.AssetTransactionId == transaction1_5.Id).ToList();

            allocationtransaction1_5.Count.Should().Be(0);

            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(
                new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction1.Quantity);
            #endregion processtransaction1_5
        }

        public async Task DisposeAsync()
        {
            await scope.DisposeAsync();
            await factory.DisposeAsync();
        }




        [Fact]
        public async Task Allocation()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion


            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            #endregion


            #region allocatorJob1
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();


            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(20);
            #endregion allocatorJob1




            #region transaction 2  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            #endregion


            #region processtransaction2
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            #endregion


            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction[0].TradeId.Should().Be(transaction2.TradeId);
            allocationtransaction[1].TradeId.Should().Be(transaction1.TradeId);



            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            // ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };


            // ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };




            await assetTransactionRepository.AddAsync(transaction3);
            await assetTransactionRepository.AddAsync(transaction4);
            await assetTransactionRepository.AddAsync(transaction5);
            await unitOfWork.SaveChangesAsync();


            #region GetAllTransactionsAndAllocateBySingle
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            #endregion

            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);



            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction5.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction1.Quantity + transaction2.Quantity + transaction3.Quantity - transaction4.Quantity);


        }





        [Fact]
        public async Task Allocation2()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion

            #region transaction 0  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction0 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction0);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(1);
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction0.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity);
            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(transaction0.Quantity);
            #endregion



            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(2);
            allocationtransaction[1].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(3);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion



            #region   transaction 3 ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(4);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);

            #endregion



            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(5);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);




















        }



        [Fact]
        public async Task Allocation3()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion

            #region transaction 0  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction0 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction0);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(1);
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction0.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity);
            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(transaction0.Quantity);
            #endregion



            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(2);
            allocationtransaction[1].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(3);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion



            #region   transaction 3 ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(4);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);

            #endregion



            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(5);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);









            // ایجاد یک تراکنش Entry 50
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36996,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 50,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2).AddMinutes(20),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2_2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();



            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(6);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction4.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(8);
            //allocationtransaction[7].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);










        }




        [Fact]
        public async Task Allocation4()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion




            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId + 1,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 6936232352,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 32334442,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 6599010,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 6666010,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 7376996,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 8376996,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 9974220,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 83769968376,
                ReferenceId = referenceId + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion



            //await assetTransactionRepository.AddAsync(transaction10);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction6);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction1);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction2);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();


            //await assetTransactionRepository.AddAsync(transaction5);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction7);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction9);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction3);
            //await assetTransactionRepository.AddAsync(transaction4);
            //await assetTransactionRepository.AddAsync(transaction8);
            // await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();


            await assetTransactionRepository.AddAsync(transaction10); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(13);
            var xxxxxs = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetAllTransactionsAndAllocateBySingle();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            var AssetAllocations = context.AssetAllocations.ToList();
            var AssetTransactions = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(10);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });

            latestSnapshot.AvailableQuantity.Should().Be(10);
            var allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().BeGreaterThan(assetTransactions.Count);










        }




        [Fact]
        public async Task AllocationByGroup1()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion

            #region transaction 0  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction0 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction0);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(1);
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction0.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity);
            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(transaction0.Quantity);
            #endregion



            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(2);
            allocationtransaction[1].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(3);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion



            #region   transaction 3 ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(4);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);

            #endregion



            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(5);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);









            // ایجاد یک تراکنش Entry 50
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36996,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 50,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2).AddMinutes(20),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2_2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();



            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(6);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction4.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(8);
            allocationtransaction[5].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);










        }



        [Fact]
        public async Task AllocationByGroup2()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion

            #region transaction 0  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction0 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction0);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(1);
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction0.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity);
            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(transaction0.Quantity);
            #endregion



            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(2);
            allocationtransaction[1].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(3);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion



            #region   transaction 3 ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(4);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);

            #endregion



            // ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(5);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);




















        }

        [Fact]
        public async Task AllocationByGroup3()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion

            #region transaction 0  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction0 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262 + 2,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(0),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction0);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(1);
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction0.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity);
            List<AssetAllocation> allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(1);
            allocationtransaction.Sum(x => x.AvailableQuantity).Should().Be(transaction0.Quantity);
            #endregion



            #region   transaction 1  ایجاد یک تراکنش Buy 20
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 20,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction1.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(2);
            allocationtransaction[1].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity);
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C 20
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,

                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 0,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(3);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion



            #region   transaction 3 ایجاد یک تراکنش SELL 30
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262852,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 30,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            await assetTransactionRepository.AddAsync(transaction3);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(4);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);

            #endregion



            #region   transaction 4 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36262963,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction4);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(5);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(2);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction2.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(4);
            allocationtransaction[3].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity);
            #endregion








            #region   transaction 2_2 ایجاد یک تراکنش Entry 50
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 36996,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 50,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2).AddMinutes(20),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            await assetTransactionRepository.AddAsync(transaction2_2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();



            assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(6);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AssetTransactionId.Should().Be(transaction4.Id);
            latestSnapshot.AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);
            allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().Be(8);
            allocationtransaction[5].AvailableQuantity.Should().Be(transaction0.Quantity + transaction1.Quantity - transaction2.Quantity + transaction2_2.Quantity - transaction3.Quantity + transaction4.Quantity);

            #endregion








        }




        [Fact]
        public async Task AllocationByGroup4()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();


            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();


            int symbolId = 41;
            int warehouseId = 38;
            long uniqueId = 201420141;
            long customerId = 6142014110;
            long referenceId = DateTime.UtcNow.Ticks + 2014201411;
            DateTime AssetTransactionCreateDate = DateTime.Now;
            #endregion




            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 36262741,
                ReferenceId = referenceId + 1,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 6936232352,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 32334442,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 6599010,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = 6666010,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 7376996,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 8376996,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = 9974220,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10 = new()
            {
                Id = 0,
                UniqueId = uniqueId,
                CustomerId = customerId,
                SymbolId = symbolId,
                WarehouseId = warehouseId,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 83769968376,
                ReferenceId = referenceId + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion



            //await assetTransactionRepository.AddAsync(transaction10);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction6);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction1);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction2);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();


            //await assetTransactionRepository.AddAsync(transaction5);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction7);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction9);
            //await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();

            //await assetTransactionRepository.AddAsync(transaction3);
            //await assetTransactionRepository.AddAsync(transaction4);
            //await assetTransactionRepository.AddAsync(transaction8);
            // await unitOfWork.SaveChangesAsync();
            //await allocatorJob.GetAllTransactionsAndAllocateBySingle();


            await assetTransactionRepository.AddAsync(transaction10); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });
            latestSnapshot.AvailableQuantity.Should().Be(13);
            var xxxxxs = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });

            var x = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ToList();
            latestSnapshot.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var AssetAllocations = context.AssetAllocations.ToList();
            var AssetTransactions = context.AssetTransactions.OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions = context.AssetTransactions.ToList();
            assetTransactions.Count.Should().Be(10);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId, SymbolId = symbolId, UniqueId = uniqueId });

            latestSnapshot.AvailableQuantity.Should().Be(10);
            var allocationtransaction = context.AssetAllocations.ToList();
            allocationtransaction.Count.Should().BeGreaterThan(assetTransactions.Count);










        }




        [Fact]
        public async Task AllocationByGroup4_1_Doual()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
            int symbolId1 = 42;
            int warehouseId1 = 39;
            long uniqueId1 = 2016;
            long customerId1 = 2016;
            long referenceId1 = DateTime.UtcNow.Ticks + 2016;
            DateTime AssetTransactionCreateDate1 = DateTime.Now;

            int symbolId2 = 41;
            int warehouseId2 = 38;
            long uniqueId2 = 2013;
            long customerId2 = 2013;
            long referenceId2 = DateTime.UtcNow.Ticks + 2013;
            DateTime AssetTransactionCreateDate2 = DateTime.Now;

            #endregion




            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 11122016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 12262016,
                ReferenceId = referenceId1 + 1,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 13362016,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1432016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1502016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 11062016,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 12702016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 13802016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 169002016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 1201021202016,
                ReferenceId = referenceId1 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion



            await assetTransactionRepository.AddAsync(transaction10);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction6);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();


            await assetTransactionRepository.AddAsync(transaction5);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction7);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction9);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction3);
            await assetTransactionRepository.AddAsync(transaction4);
            await assetTransactionRepository.AddAsync(transaction8);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(10);

            /*
            await assetTransactionRepository.AddAsync(transaction10); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(13);
            var xxxxxs = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });

            var x = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            latestSnapshot.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var AssetAllocations = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            var AssetTransactions = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            assetTransactions.Count.Should().Be(10);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });

            latestSnapshot.AvailableQuantity.Should().Be(10);
            var allocationtransaction = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            allocationtransaction.Count.Should().BeGreaterThan(assetTransactions.Count);

            */


            ////////*************************************************************************************************************************************************/////////
            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 2233222,
                ReferenceId = referenceId2 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 227345666,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 229845,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2229020,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 2211020,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 223496,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 333616,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2294320,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 2210206,
                ReferenceId = referenceId2 + 1212,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion



            await assetTransactionRepository.AddAsync(transaction10_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(13);
            var xxxxxs2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8_2); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });

            var x2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            latestSnapshot2.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var AssetAllocations2 = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            var AssetTransactions2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            assetTransactions2.Count.Should().Be(10);
            assetTransactions2.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });

            latestSnapshot2.AvailableQuantity.Should().Be(10);
            var allocationtransaction2 = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            allocationtransaction2.Count.Should().BeGreaterThan(assetTransactions2.Count);




        }


        [Fact]
        public async Task AllocationByGroup4_2_Doual()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
            int symbolId1 = 41;
            int warehouseId1 = 38;
            long uniqueId1 = 2016;
            long customerId1 = 2016;
            long referenceId1 = DateTime.UtcNow.Ticks + 2016;
            DateTime AssetTransactionCreateDate1 = DateTime.Now;

            int symbolId2 = 41;
            int warehouseId2 = 38;
            long uniqueId2 = 2013;
            long customerId2 = 2013;
            long referenceId2 = DateTime.UtcNow.Ticks + 2013;
            DateTime AssetTransactionCreateDate2 = DateTime.Now;

            #endregion




            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 11122016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 12262016,
                ReferenceId = referenceId1 + 1,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 13362016,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1432016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1502016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 11062016,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 12702016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 13802016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 169002016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 1201021202016,
                ReferenceId = referenceId1 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion






            await assetTransactionRepository.AddAsync(transaction5);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction7);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();


            await assetTransactionRepository.AddAsync(transaction1);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction10);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();

            await assetTransactionRepository.AddAsync(transaction6);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();



            await assetTransactionRepository.AddAsync(transaction3);
            await assetTransactionRepository.AddAsync(transaction4);
            await assetTransactionRepository.AddAsync(transaction8);
            await unitOfWork.SaveChangesAsync();
            await assetTransactionRepository.AddAsync(transaction2);
            await unitOfWork.SaveChangesAsync();

            await assetTransactionRepository.AddAsync(transaction9);
            await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();


            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(10);
            var sumRemainingQuantity = await context.AssetAllocations.OfType<AssetEntry>().Where(x => x.WarehouseId == warehouseId1 && x.UniqueId == uniqueId1).SumAsync(x => x.RemainingQuantity);
            var Lastallo = await context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.UniqueId == uniqueId1)
                .OrderByDescending(x => x.CreateDate).Take(1).FirstOrDefaultAsync();
            Lastallo.AvailableQuantity.Should().Be(latestSnapshot.AvailableQuantity);
            sumRemainingQuantity.Should().Be(Lastallo.AvailableQuantity);




            /*
            await assetTransactionRepository.AddAsync(transaction10); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });
            latestSnapshot.AvailableQuantity.Should().Be(13);
            var xxxxxs = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });

            var x = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            latestSnapshot.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var AssetAllocations = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            var AssetTransactions = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            assetTransactions.Count.Should().Be(10);
            assetTransactions.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });

            latestSnapshot.AvailableQuantity.Should().Be(10);
            var allocationtransaction = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.SymbolId == symbolId1 && x.UniqueId == uniqueId1).ToList();
            allocationtransaction.Count.Should().BeGreaterThan(assetTransactions.Count);

            */


            ////////*************************************************************************************************************************************************/////////
            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 2233222,
                ReferenceId = referenceId2 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 227345666,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 229845,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2229020,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 2211020,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 223496,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 333616,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2294320,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 2210206,
                ReferenceId = referenceId2 + 1212,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion



            await assetTransactionRepository.AddAsync(transaction10_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            var latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction4_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(1);

            await assetTransactionRepository.AddAsync(transaction3_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(1 + 1);

            await assetTransactionRepository.AddAsync(transaction2_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction5_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction9_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction6_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction7_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.Should().BeNull();

            await assetTransactionRepository.AddAsync(transaction1_2); await unitOfWork.SaveChangesAsync();
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });
            latestSnapshot2.AvailableQuantity.Should().Be(13);
            var xxxxxs2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            await assetTransactionRepository.AddAsync(transaction8_2); await unitOfWork.SaveChangesAsync();
            //اینجا دیتا خراب میشود و  منشا از باقیمانده مقدار است
            await allocatorJob.GetTransactionsAndAllocateByGroup();
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });

            var x2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();
            latestSnapshot2.AvailableQuantity.Should().Be(10);

            await allocatorJob.GetTransactionsAndAllocateByGroup();

            var AssetAllocations2 = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            var AssetTransactions2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).OrderBy(x => x.AssetTransactionCreateDate).ToList();


            var assetTransactions2 = context.AssetTransactions.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            assetTransactions2.Count.Should().Be(10);
            assetTransactions2.Where(x => x.Status == AssetTransactionStatus.UnTouched).Count().Should().Be(0);
            latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });

            latestSnapshot2.AvailableQuantity.Should().Be(10);
            var allocationtransaction2 = context.AssetAllocations.Where(x => x.WarehouseId == warehouseId2 && x.SymbolId == symbolId2 && x.UniqueId == uniqueId2).ToList();
            allocationtransaction2.Count.Should().BeGreaterThan(assetTransactions2.Count);




        }


        [Fact]
        public async Task AllocationByGroup4_3_Doual()
        {
            #region init
            await using AsyncServiceScope scope = factory.Services.CreateAsyncScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
         int symbolId1 = 41;
            int warehouseId1 = 38;
            long uniqueId1 = 2016;
            long customerId1 = 2016;
            long referenceId1 = DateTime.UtcNow.Ticks + 2016;
            DateTime AssetTransactionCreateDate1 = DateTime.Now;
      
            int symbolId2 = 43;
            int warehouseId2 = 40;
            long uniqueId2 = 2013;
            long customerId2 = 2013;
            long referenceId2 = DateTime.UtcNow.Ticks + 2013;
            DateTime AssetTransactionCreateDate2 = DateTime.Now;

            #endregion

 


            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 11122016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 12262016,
                ReferenceId = referenceId1 + 1,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 13362016,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1432016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 125,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 1502016,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = 11062016,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 12702016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 13802016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = 169002016,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10 = new()
            {
                Id = 0,
                UniqueId = uniqueId1,
                CustomerId = customerId1,
                SymbolId = symbolId1,
                WarehouseId = warehouseId1,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 1201021202016,
                ReferenceId = referenceId1 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 120,
                AssetTransactionCreateDate = AssetTransactionCreateDate1.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion
            await assetTransactionRepository.AddAsync(transaction10); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction9); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction8); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction7); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction6); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction5); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction4); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction3); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction1); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();

            var latestSnapshot = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId1, SymbolId = symbolId1, UniqueId = uniqueId1 });

            //اینجا کوئری کال میشه
            var AssetBalanceNetDtos = await context.Database
                .SqlQuery<AssetBalanceNetDto>($@"
        WITH C AS
        (
            SELECT 
                t.Id, t.CustomerId, t.SymbolId, t.WarehouseId, t.TradeId, t.EntranceId, t.ClearanceId, t.ReferenceId,
                t.Type, t.Direction, t.Quantity, t.Price, t.AssetTransactionCreateDate,
                CASE WHEN (t.Type = 1 OR t.Type = 2) THEN t.Quantity ELSE -t.Quantity END AS Quantity2,
                SUM(CASE WHEN (t.Type = 1 OR t.Type = 2) THEN t.Quantity ELSE -t.Quantity END) OVER (
                    ORDER BY t.AssetTransactionCreateDate, t.Id
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                ) AS Net
            FROM AssetTransactions t
            WHERE t.CustomerId = {customerId1} AND t.SymbolId = {symbolId1}
        )
        SELECT * FROM C")
                .ToListAsync();
            var latestNet = AssetBalanceNetDtos.LastOrDefault()?.Net ?? 0;
            latestSnapshot.AvailableQuantity.Should().Be(latestNet);


            var Lastallo = await context.AssetAllocations.Where(x => x.WarehouseId == warehouseId1 && x.UniqueId == uniqueId1).OrderByDescending(x => x.CreateDate).Take(1).FirstOrDefaultAsync();
            Lastallo.AvailableQuantity.Should().Be(latestSnapshot.AvailableQuantity);
            var sumRemainingQuantity = await context.AssetAllocations.OfType<AssetEntry>().Where(x => x.WarehouseId == warehouseId1 && x.UniqueId == uniqueId1).SumAsync(x => x.RemainingQuantity);
            sumRemainingQuantity.Should().Be(Lastallo.AvailableQuantity);

             

            ////////*************************************************************************************************************************************************/////////
            #region   transaction 1  ایجاد یک تراکنش Buy 10
            Domain.Entities.AssetTransaction transaction1_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 36262,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 100,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(1),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion




            #region   transaction 2 ایجاد یک تراکنش C -3
            Domain.Entities.AssetTransaction transaction2_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 0,
                ClearanceId = 2233222,
                ReferenceId = referenceId2 + 2,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(2),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion



            #region   transaction 3 ایجاد یک تراکنش Entry 1
            Domain.Entities.AssetTransaction transaction3_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 227345666,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(3),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion



            #region   transaction 4 ایجاد یک تراکنش buy 1
            Domain.Entities.AssetTransaction transaction4_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 229845,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 1,
                Price = 225,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(4),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = TradeType.Trade,
            };
            #endregion

            #region   transaction 5 ایجاد یک تراکنش buy 10
            Domain.Entities.AssetTransaction transaction5_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2229020,
                EntranceId = 0,
                ClearanceId = 0,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(5),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 6 ایجاد یک تراکنش Entry 10
            Domain.Entities.AssetTransaction transaction6_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = 2211020,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Entry,
                Direction = AssetDirection.In,
                Quantity = 10,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(6),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion


            #region   transaction 7  ایجاد یک تراکنش Sell -2
            Domain.Entities.AssetTransaction transaction7_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 223496,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 2,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(7),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };
            #endregion

            #region   transaction  8  ایجاد یک تراکنش Sell -3
            Domain.Entities.AssetTransaction transaction8_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 333616,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Sell,
                Direction = AssetDirection.Out,
                Quantity = 3,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(8),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };

            #endregion

            #region   transaction 9 ایجاد یک تراکنش Buy 6
            Domain.Entities.AssetTransaction transaction9_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = 2294320,
                EntranceId = null,
                ClearanceId = null,
                ReferenceId = 0,
                Type = AssetTransactionType.Buy,
                Direction = AssetDirection.In,
                Quantity = 6,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(9),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            #region   transaction   10  ایجاد یک تراکنش C -20
            Domain.Entities.AssetTransaction transaction10_2 = new()
            {
                Id = 0,
                UniqueId = uniqueId2,
                CustomerId = customerId2,
                SymbolId = symbolId2,
                WarehouseId = warehouseId2,
                TradeId = null,
                EntranceId = null,
                ClearanceId = 2210206,
                ReferenceId = referenceId2 + 1212,
                Type = AssetTransactionType.Clearance,
                Direction = AssetDirection.Out,
                Quantity = 20,
                Price = 220,
                AssetTransactionCreateDate = AssetTransactionCreateDate2.AddHours(10),
                Status = AssetTransactionStatus.UnTouched,
                TradeType = 0,
            };


            #endregion

            await assetTransactionRepository.AddAsync(transaction10_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction9_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction8_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction7_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction6_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction5_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction4_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction3_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction2_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();
            await assetTransactionRepository.AddAsync(transaction1_2); await unitOfWork.SaveChangesAsync(); await allocatorJob.GetTransactionsAndAllocateByGroup();

            var latestSnapshot2 = await assetAllocationRepository.GetLatestSnapshot(new AssetExit { WarehouseId = warehouseId2, SymbolId = symbolId2, UniqueId = uniqueId2 });

            //اینجا کوئری کال میشه
            var AssetBalanceNetDtos2 = await context.Database
                .SqlQuery<AssetBalanceNetDto>($@"
        WITH C AS
        (
            SELECT 
                t.Id, t.CustomerId, t.SymbolId, t.WarehouseId, t.TradeId, t.EntranceId, t.ClearanceId, t.ReferenceId,
                t.Type, t.Direction, t.Quantity, t.Price, t.AssetTransactionCreateDate,
                CASE WHEN (t.Type = 1 OR t.Type = 2) THEN t.Quantity ELSE -t.Quantity END AS Quantity2,
                SUM(CASE WHEN (t.Type = 1 OR t.Type = 2) THEN t.Quantity ELSE -t.Quantity END) OVER (
                    ORDER BY t.AssetTransactionCreateDate, t.Id
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                ) AS Net
            FROM AssetTransactions t
            WHERE t.CustomerId = {customerId2} AND t.SymbolId = {symbolId2}
        )
        SELECT * FROM C")
                .ToListAsync();
            var latestNet2 = AssetBalanceNetDtos2.LastOrDefault()?.Net ?? 0;
            latestSnapshot2.AvailableQuantity.Should().Be(latestNet2);


            var Lastallo2 = await context.AssetAllocations.Where(x => x.WarehouseId == warehouseId2 && x.UniqueId == uniqueId2).OrderByDescending(x => x.CreateDate).Take(1).FirstOrDefaultAsync();
            Lastallo2.AvailableQuantity.Should().Be(latestSnapshot2.AvailableQuantity);
            var sumRemainingQuantity2 = await context.AssetAllocations.OfType<AssetEntry>().Where(x => x.WarehouseId == warehouseId2 && x.UniqueId == uniqueId2).SumAsync(x => x.RemainingQuantity);
            sumRemainingQuantity2.Should().Be(Lastallo2.AvailableQuantity);




        }



    }
}
