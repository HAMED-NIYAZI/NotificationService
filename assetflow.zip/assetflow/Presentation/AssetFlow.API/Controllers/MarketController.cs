﻿using AssetFlow.Application.Common.Services.ExternalServices;
using Microsoft.AspNetCore.Mvc;

namespace AssetFlow.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MarketController : ControllerBase
    {

        private readonly IMarketService marketService;

        public MarketController(IMarketService marketService)
        {
            this.marketService = marketService;
        }


        [HttpGet("[action]")]
        public async Task<IActionResult> GetCustomerBalance([FromQuery] long referenceId, string dateFrom, string dateTo)
        {
            DateTime dateTimeFrom;

            if (string.IsNullOrEmpty(dateFrom))
            {
                // dateTimeFrom = DateTime.FromDateTime(DateTime.Now);
                dateTimeFrom = DateTime.Now;

            }
            else if (!DateTime.TryParse(dateFrom, out dateTimeFrom))
            {
                return BadRequest("Invalid date format. Use yyyy-MM-dd.");
            }


            DateTime dateTimeTo;

            if (string.IsNullOrEmpty(dateTo))
            {
                //dateTimeTo = DateTime.FromDateTime(DateTime.Now);
                dateTimeTo = DateTime.Now;

            }
            else if (!DateTime.TryParse(dateTo, out dateTimeTo))
            {
                return BadRequest("Invalid date format. Use yyyy-MM-dd.");
            }



            var clearances = await marketService.GetCustomersClearances(dateTimeFrom, dateTimeTo);

            return Ok(clearances);
        }




    }
}
