﻿using AssetFlow.API.Extensions;
using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Application.TaxDetail.Commands.GetClearanceTaxSummary;
using AssetFlow.Application.TaxDetail.Commands.GetTaxSummaries;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using Hangfire;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace AssetFlow.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaxController : ControllerBase
    {
        private readonly AssetFlowDbContext context;

        private readonly ISender sender;
        private readonly IAllocatorJob allocatorJob;
        private readonly ICdcWarehouseManagementService cdcWarehouseManagementService;
        private readonly ISyncDataAndAllocateCustomerJob syncDataAndAllocateCustomerJob;
        private readonly ISyncAllDataJob syncAllDataJob;
        private readonly IAllocationStateStore allocationStateStore;
        private readonly IAssetTransactionRepository assetTransactionRepository;
        private readonly ICdcTradeRepository cdcTradeRepository;
        private readonly IAssetLogRepository _log;



        public TaxController(IAssetLogRepository log, ICdcTradeRepository cdcTradeRepository, IAssetTransactionRepository assetTransactionRepository, IAllocationStateStore allocationStateStore, AssetFlowDbContext context, ICdcWarehouseManagementService cdcWarehouseManagementService, IAllocatorJob allocatorJob, ISyncDataAndAllocateCustomerJob syncCustomerAllDataJob, ISyncAllDataJob syncAllDataJob, ISender sender)
        {
            this.cdcWarehouseManagementService = cdcWarehouseManagementService;
            this.allocatorJob = allocatorJob;
            this.syncDataAndAllocateCustomerJob = syncCustomerAllDataJob;
            this.syncAllDataJob = syncAllDataJob;
            this.sender = sender;
            this.context = context;
            this.allocationStateStore = allocationStateStore;
            this.assetTransactionRepository = assetTransactionRepository;
            this.cdcTradeRepository = cdcTradeRepository;
            this._log = log;
        }





        [HttpGet("Health1")]
        public async Task<IActionResult> Health1()
        {

            try
            {
                //  var GetMaxClearanceIdAsync = await assetTransactionRepository.GetMaxClearanceIdAsync();
                //  //var cdcTrade = await cdcTradeRepository.GetAfterIdAsync(10, 1);
                ////  string str = $@"GetMaxClearanceIdAsync ={GetMaxClearanceIdAsync} \n cdcTrade[0].TradeID ={cdcTrade[0].TradeID} \n";
                //  string str = $@"GetMaxClearanceIdAsync ={GetMaxClearanceIdAsync} ";

                var response = ResponseModel<string>.SuccessResponse("str");
                return response.ToActionResult();
            }
            catch (Exception ex)
            {
                string str = $@"ex.Message={ex.Message} {Environment.NewLine} ex={JsonConvert.SerializeObject(ex)}";
                var response = ResponseModel<string>.Failed(str);
                return response.ToActionResult();
            }

        }



        [HttpGet("Health2")]
        public async Task<IActionResult> Health2()
        {

            try
            {
                var GetMaxClearanceIdAsync = await assetTransactionRepository.GetMaxClearanceIdAsync();
                //var cdcTrade = await cdcTradeRepository.GetAfterIdAsync(10, 1);
                //  string str = $@"GetMaxClearanceIdAsync ={GetMaxClearanceIdAsync} \n cdcTrade[0].TradeID ={cdcTrade[0].TradeID} \n";
                string str = $@"GetMaxClearanceIdAsync ={GetMaxClearanceIdAsync} ";

                var response = ResponseModel<string>.SuccessResponse(str);
                return response.ToActionResult();
            }
            catch (Exception ex)
            {
                string str = $@"ex.Message={ex.Message} {Environment.NewLine} ex={JsonConvert.SerializeObject(ex)}";
                var response = ResponseModel<string>.Failed(str);
                return response.ToActionResult();
            }

        }

        //[HttpGet("GetTaxSummariesByUniqueIdIme")]
        //public async Task<IActionResult> GetTaxSummariesByUniqueIdIme([FromQuery] long customerIdIme, long referenceId)
        //{
        //    var response = await sender.Send(new GetTaxSummariesByCustomerImeCommand { CustomerIme = customerIdIme, ReferenceId = referenceId });
        //    return response.ToActionResult();
        //}

        [HttpGet("GetClearanceTaxSummary")]
        public async Task<IActionResult> GetClearanceTaxSummary([FromQuery] long referenceId, decimal fromAmount, decimal toAmount)
        {
            var response = await sender.Send(new GetClearanceTaxSummaryCommand { ReferenceId = referenceId, FromAmount = fromAmount, ToAmount = toAmount });
            return response.ToActionResult();
        }


        //[HttpGet("GetTaxSummariesByUniqueId")]
        //public async Task<IActionResult> GetTaxSummariesByUniqueId([FromQuery] long customerId, long referenceId)
        //{
        //    var result = await sender.Send(new GetTaxSummariesByUniqueIdCommand {  ReferenceId = referenceId });
        //    return Ok(result);
        //}


        //[HttpGet("GetTaxSummariesByUniqueId")]
        //public async Task<IActionResult> GetTaxSummariesByUniqueId(long uniqueId, long referenceId)
        //{
        //    var result = await sender.Send(new GetTaxSummariesByUniqueIdCommand { UniqueId = uniqueId, ReferenceId = referenceId });
        //    return Ok(result);
        //}



        [HttpGet("GetTaxSummaries")]
        public async Task<IActionResult> GetTaxSummaries([FromQuery] int warehouseGroupId, DateTime date)
        {
            var result = await sender.Send(new GetTaxSummariesCommand { WarehouseGroupId = warehouseGroupId, Date = date });
            return Ok(result);
        }


        [HttpPost("SyncDataAndAllocateByCustomerJob")]
        public async Task<IActionResult> SyncDataAndAllocateByCustomerJob([FromQuery] long uniqueId, int warehouseId, int symbolId)
        {
            await syncDataAndAllocateCustomerJob.ExecuteAsync(uniqueId, warehouseId, symbolId);
            return StatusCode(200, new { });
        }

        //[HttpPost("SyncAllDataAndAllocateByBatch")]
        //public async Task<IActionResult> SyncAllDataAndAllocateByBatch()
        //{
        //    await syncAllDataJob.SyncAllDataAndAllocateByBatch();
        //    return StatusCode(200, new { });
        //}


        [HttpPost("RebuildCustomer")]
        public async Task<IActionResult> RebuildCustomer([FromQuery] long uniqueId, int warehouseId, int symbolId)
        {

            await using var transaction = await context.Database.BeginTransactionAsync();

            try
            {
                await context.AssetAllocations
                    .Where(x => x.UniqueId == uniqueId && x.WarehouseId == warehouseId && x.SymbolId == symbolId)
                    .ExecuteDeleteAsync();

                await context.AssetTransactions.Where(x => x.UniqueId == uniqueId && x.WarehouseId == warehouseId && x.SymbolId == symbolId)
                    .ExecuteUpdateAsync(setters =>
                    {
                        setters.SetProperty(x => x.Status, AssetTransactionStatus.UnTouched);
                    });



                var assetAllocationsCount = await context.AssetAllocations.CountAsync(x => x.UniqueId == uniqueId && x.WarehouseId == warehouseId && x.SymbolId == symbolId);

                if (assetAllocationsCount == 0)
                    await transaction.CommitAsync();
                else
                    throw new Exception("assetAllocationsCount > 0");

            }
            catch (Exception ex)
            {
                _log.LogIt(ex);
                await transaction.RollbackAsync();
                throw;
            }
            var allocationBlockKey = new AllocationStateKey(uniqueId, warehouseId);

            allocationStateStore.Unblock(allocationBlockKey);

            BackgroundJob.Enqueue<IAllocatorJob>(job => job.GetAllCustomerTransactionsAndAllocateBySingle(uniqueId, warehouseId, symbolId));
            return StatusCode(200, new { });
        }



        [HttpGet("[action]/{uniqueId}/{warehouseId}/{dateString}")]
        public async Task<IActionResult> GetCustomerBalance(long uniqueId, int warehouseId, string? dateString)
        {
            DateTime dateTime;

            if (string.IsNullOrEmpty(dateString))
            {
                dateTime = DateTime.Now;
            }
            else if (!DateTime.TryParse(dateString, out dateTime))
            {
                return BadRequest("Invalid date format. Use yyyy-MM-dd.");
            }
            var GetCustomerBalances = await cdcWarehouseManagementService.GetAllCustomerBalancesAsync(warehouseId, dateTime.AddDays(1));
            var GetCustomerBalance = GetCustomerBalances.FirstOrDefault(x => x.AssetOwnerUniqueCode == uniqueId);

            if (GetCustomerBalance is null) return StatusCode(404, new { });
            return Ok(
              new
              {
                  data = GetCustomerBalance.Balance * 10,
                  GetCustomerBalance = GetCustomerBalance
              });
        }



    }
}
