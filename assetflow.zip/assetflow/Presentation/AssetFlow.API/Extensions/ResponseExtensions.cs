﻿using AssetFlow.Application.AssetTransaction.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace AssetFlow.API.Extensions;

public static class ResponseExtensions
{
    public static IActionResult ToActionResult<T>(this ResponseModel<T> response)
    {
        return new ObjectResult(response)
        {
            StatusCode = response.StatusCode
        };
    }
}
