using AssetFlow.Api.ExceptionHandlers;
using AssetFlow.Application;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Persistence;
using Hangfire;
using Hangfire.MemoryStorage;
using Newtonsoft.Json;
using static AssetFlow.Persistence.Repositories.CustomerRepository;



public partial class Program
{
    private static void Main(string[] args)
    {


        WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

        builder.Services.AddControllers();
        builder.Services.AddSwaggerGen();
        builder.Services.AddOpenApi();
        builder.Services.AddDbContext(builder.Configuration);
        builder.Services.AddAllPersistenceServices();
        builder.Services.AddApplicationServices(builder.Configuration);
        builder.Configuration.GetSection(nameof(UniqueCodeApiSettings)).Bind(AppConfig.UniqueCodeApiSettings);



        builder.Services.AddControllers()
        .AddNewtonsoftJson(options =>
        {
            options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        });
        JsonConvert.DefaultSettings = () => new JsonSerializerSettings
        {
            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
        };



        builder.Services.AddHangfire(configuration =>
        {
            configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseMemoryStorage();
        });

        builder.Services.AddHangfireServer(options =>
        {
            options.WorkerCount = 4;
        });




        builder.Services.AddExceptionHandler<ValidationExceptionHandler>();
        builder.Services.AddProblemDetails();

        WebApplication app = builder.Build();
        app.UseExceptionHandler();


        app.UseSwagger();
        app.UseSwaggerUI();
        app.MapOpenApi();


        app.UseHttpsRedirection();

        app.UseAuthentication();
        app.UseAuthorization();
        app.UseHangfireDashboard("/hangfire");
        app.MapControllers();






        // Schedule recurring jobs
        using (IServiceScope scope = app.Services.CreateScope())
        {
            IRecurringJobScheduler scheduler = scope.ServiceProvider.GetRequiredService<IRecurringJobScheduler>();
            scheduler.EnqueueJob();
            //scheduler.ScheduleJob();
        }






        app.Run();


    }
}