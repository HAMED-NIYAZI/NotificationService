﻿using AssetFlow.Persistence.IntegrationTests.Fixtures;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Persistence.IntegrationTests.Repositories;

public class AssetTransactionRepositoryTests
{
    [Fact]
    public async Task GetAfterIdAsync_ShouldReturnItems()
    {
        DbContextOptions<TestDbContext> options = SqliteTestDbFactory.CreateOptions<TestDbContext>();

        await using TestDbContext context = new(options);
        await context.Database.EnsureCreatedAsync();

        context.AssetTransactions.AddRange(
            new AssetTransaction { Id = 1, TradeId = 100 },
            new AssetTransaction { Id = 2, TradeId = 100 }
        );
        await context.SaveChangesAsync();

        List<AssetTransaction> result = await context.AssetTransactions
            .Where(x => x.Id > 0)
            .ToListAsync();

        result.Should().HaveCount(2);
    }
    //CheckAbnormalTransactionsAsync
    //CheckAbnormalTransactionsByReferenceIdAsync
    //GetSignedQuantity
    //GetYoungerDataAsync
    private class TestDbContext(DbContextOptions<TestDbContext> options) : Microsoft.EntityFrameworkCore.DbContext(options)
    {
        public DbSet<AssetTransaction> AssetTransactions => Set<AssetTransaction>();
    }

    private class AssetTransaction
    {
        public long Id { get; set; }
        public long TradeId { get; set; }
    }
}
