﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.IntegrationTests.Fixtures;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;

namespace AssetFlow.Persistence.IntegrationTests.Repositories;

public class AssetAllocationRepositoryTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly CustomWebApplicationFactory _factory;

    public AssetAllocationRepositoryTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task SaveWithValidAssetAllocationShouldPersistEntity()
    {

        // Arrange
        long uniqueReferenceId = DateTime.UtcNow.Ticks;
        int expectedQuantity = -100;


        // Act
        // استفاده از await using به جای using معمولی برای سازگاری با IAsyncDisposable
        await using (AsyncServiceScope scope = _factory.Services.CreateAsyncScope())
        {
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();




            await assetTransactionRepository.AddAsync(new AssetTransaction { TradeId = 100, EntranceId = 100, ReferenceId = 100 });
            int saveAssetTransaction = await unitOfWork.SaveChangesAsync();
            IReadOnlyList<AssetTransaction> AssetTransactions = await assetTransactionRepository.GetAllAsync(x => x.TradeId == 100 && x.EntranceId == 100 && x.ReferenceId == 100);
            AssetTransaction? AssetTransaction = AssetTransactions.FirstOrDefault(x => x.TradeId == 100 && x.EntranceId == 100 && x.ReferenceId == 100);



            var assetAllocation = new AssetExit
            {
                AssetTransactionId = AssetTransaction.Id,
                ReferenceId = uniqueReferenceId,
                UniqueId = 1001,
                WarehouseId = 1,
                SymbolId = 1,
                Quantity = expectedQuantity,
            };


            await assetAllocationRepository.Save(assetAllocation);
            int saveResult = await unitOfWork.SaveChangesAsync();

            saveResult.Should().BeGreaterThan(0);

        }

        // Assert
        // در اینجا هم از CreateAsyncScope و await using استفاده می‌کنیم
        await using (AsyncServiceScope verifyScope = _factory.Services.CreateAsyncScope())
        {
            IAssetAllocationRepository repository = verifyScope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();

            AssetAllocation savedEntity = await repository.Get(x => x.ReferenceId == uniqueReferenceId);

            savedEntity.Should().NotBeNull();
            savedEntity.ReferenceId.Should().Be(uniqueReferenceId);
        }
    }

}
