﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using AssetFlow.Persistence.DbContext;
using AssetFlow.Persistence.IntegrationTests.Fixtures;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace AssetFlow.Persistence.IntegrationTests.Repositories
{




    public class AllocationStateStoreTest : IAsyncLifetime
    {
        private CustomWebApplicationFactory? factory;
        private AsyncServiceScope scope;

        public async Task InitializeAsync()
        {
            factory = new CustomWebApplicationFactory();
            scope = factory.Services.CreateAsyncScope();


        }
        public async Task DisposeAsync()
        {
            await scope.DisposeAsync();
            await factory.DisposeAsync();
        }


        //bool IsBlock(AllocationStateKey key);
        //void Block(AllocationStateKey key);
        //void Unblock(AllocationStateKey key);
        //void CreateOrUpdateSnapshot(AllocationStateKey key, double balance, DateOnly date);
        //void CreateOrUpdateBalance(AllocationStateKey key, double balance, DateOnly date);
        //bool IsSyncBalance(AllocationStateKey key);
        //bool TryGet(AllocationStateKey key, out AllocationState? state);
        //void Clear();



        [Fact]
        public async Task IsBlock()
        {
            using IServiceScope scope = factory.Services.CreateScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
            IAllocationStateStore store = scope.ServiceProvider.GetRequiredService<IAllocationStateStore>();
            // پاک‌سازی جدول قبل از هر تست
            // await ClearAllTablesAsync(context);



            // 1. Arrange: تعریف کلید تراکنش
            AllocationStateKey key = new(20102010, 38);
            AllocationState? AllocationState = new();
            // 2. Act & Assert - فاز اول: قبل از هر کاری نباید بلاک باشد
            bool initialIsBlocked = await store.IsBlock(key);
            initialIsBlocked.Should().BeFalse();

            //IsBlock in db should be false 
            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeFalse();








            // 3. Act & Assert - فاز دوم: بلاک کردن
            await store.BlockAsync(key);

            // بررسی مستقیم در لایه Store
            bool isBlockedAfterBlock = await store.IsBlock(key);
            isBlockedAfterBlock.Should().BeTrue();

            // بررسی فیزیکی در دیتابیس (اطمینان از Commit شدن در دیتابیس مستقل از Store)
            AllocationState = await context.AllocationStates
             .AsNoTracking()
             .FirstOrDefaultAsync(x =>
                 x.UniqueId == key.UniqueId &&
                 x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeTrue();


            // 4. Act & Assert - فاز سوم: آنبلاک کردن
            await store.Unblock(key);

            bool isBlockedAfterUnblock = await store.IsBlock(key);
            isBlockedAfterUnblock.Should().BeFalse();


            // بررسی مجدد دیتابیس فیزیکی بعد از Unblock
            AllocationState = await context.AllocationStates
                              .AsNoTracking()
                              .FirstOrDefaultAsync(x =>
                                  x.UniqueId == key.UniqueId &&
                                  x.WarehouseId == key.WarehouseId);
            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeFalse();

            await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();


        }



        [Fact]
        public async Task CreateOrUpdateSnapshot()
        {
            using IServiceScope scope = factory.Services.CreateScope();
            AssetFlowDbContext context = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            IAssetTransactionRepository assetTransactionRepository = scope.ServiceProvider.GetRequiredService<IAssetTransactionRepository>();
            IUnitOfWork unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            IAllocatorJob allocatorJob = scope.ServiceProvider.GetRequiredService<IAllocatorJob>();
            ITaxDetailService taxDetailService = scope.ServiceProvider.GetRequiredService<ITaxDetailService>();
            IAssetAllocationRepository assetAllocationRepository = scope.ServiceProvider.GetRequiredService<IAssetAllocationRepository>();
            IWarehouseGroupTaxRule warehouseGroupTaxRule = scope.ServiceProvider.GetRequiredService<IWarehouseGroupTaxRule>();
            IAssetTransactionProcessService assetTransactionProcessService = scope.ServiceProvider.GetRequiredService<IAssetTransactionProcessService>();
            IAllocationStateStore store = scope.ServiceProvider.GetRequiredService<IAllocationStateStore>();
            // پاک‌سازی جدول قبل از هر تست
            //  await ClearAllTablesAsync(context);



            // 1. Arrange: تعریف کلید تراکنش
            AllocationStateKey key = new(20102010, 38);
            AllocationState? AllocationState = new();
            // 2. Act & Assert - فاز اول: قبل از هر کاری نباید بلاک باشد
            bool initialIsBlocked = await store.IsBlock(key);
            initialIsBlocked.Should().BeFalse();


            double balance = 1000;
            DateOnly date = new(2026, 08, 08);
            await store.CreateOrUpdateSnapshot(key, balance, date);


            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.UniqueId.Should().Be(20102010);
            AllocationState.WarehouseId.Should().Be(38);
            AllocationState.SymbolId.Should().Be(41);
            AllocationState.IsSync.Should().BeFalse();
            AllocationState.IsBlocked.Should().BeFalse();




            await store.CreateOrUpdateBalance(key, balance, new DateOnly(2026, 08, 08));




            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsSync.Should().BeTrue();
            AllocationState.IsBlocked.Should().BeFalse();


            await store.BlockAsync(key);



            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeTrue();



            // بررسی مستقیم در لایه Store
            bool isBlockedAfterBlock = await store.IsBlock(key);
            isBlockedAfterBlock.Should().BeTrue();

            // بررسی فیزیکی در دیتابیس (اطمینان از Commit شدن در دیتابیس مستقل از Store)
            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeTrue();


            // 4. Act & Assert - فاز سوم: آنبلاک کردن
            await store.Unblock(key);

            AllocationState = await context.AllocationStates
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
            x.UniqueId == key.UniqueId &&
            x.WarehouseId == key.WarehouseId);

            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeFalse();



            bool isBlockedAfterUnblock = await store.IsBlock(key);
            isBlockedAfterUnblock.Should().BeFalse();



            await store.BlockAsync(key);

            AllocationState = await context.AllocationStates.AsNoTracking().FirstOrDefaultAsync(x => x.UniqueId == key.UniqueId && x.WarehouseId == key.WarehouseId );
            AllocationState.Should().NotBeNull();
            AllocationState.IsBlocked.Should().BeTrue();



            isBlockedAfterUnblock = await store.IsBlock(key);
            isBlockedAfterUnblock.Should().BeTrue();




            bool IsSyncBalance = await store.IsSyncBalance(key);
            AllocationState.IsSync.Should().BeTrue();


            await ((IAsyncDisposable)scope.ServiceProvider).DisposeAsync();
        }
    }
}
