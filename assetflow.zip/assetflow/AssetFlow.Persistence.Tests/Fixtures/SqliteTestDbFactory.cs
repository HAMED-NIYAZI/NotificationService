﻿using AssetFlow.Persistence.DbContext;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace AssetFlow.Persistence.IntegrationTests.Fixtures;

public static class SqliteTestDbFactory
{
    public static DbContextOptions<TContext> CreateOptions<TContext>()
        where TContext : Microsoft.EntityFrameworkCore.DbContext
    {
        SqliteConnection connection = new("DataSource=:memory:");
        connection.Open();

        return new DbContextOptionsBuilder<TContext>()
            .UseSqlite(connection)
            .Options;
    }
}


public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
    // ایجاد یک شناسه منحصربه‌فرد برای هر دیتابیس در رم
    private readonly string _dbName = Guid.NewGuid().ToString();
    private SqliteConnection? _connection;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureServices(services =>
        {
            // ۱. پاکسازی تنظیمات قبلی
            List<ServiceDescriptor> descriptors = services.Where(d =>
                d.ServiceType.FullName != null &&
                d.ServiceType.FullName.Contains("DbContext")).ToList();

            foreach (ServiceDescriptor descriptor in descriptors)
                services.Remove(descriptor);

            // ۲. ایجاد کانکشن اختصاصی با نام رندوم
            _connection = new SqliteConnection($"DataSource={_dbName};Mode=Memory;Cache=Shared");
            _connection.Open();

            // ۳. ثبت دیتابیس
            services.AddDbContextFactory<AssetFlowDbContext>(options =>
            {
                options.UseSqlite(_connection);
            });

            services.AddScoped<AssetFlowDbContext>(p =>
                p.GetRequiredService<IDbContextFactory<AssetFlowDbContext>>().CreateDbContext());

            // ۴. ساخت جداول
            ServiceProvider sp = services.BuildServiceProvider();
            using IServiceScope scope = sp.CreateScope();
            AssetFlowDbContext db = scope.ServiceProvider.GetRequiredService<AssetFlowDbContext>();
            db.Database.EnsureCreated();
        });

    }

    // متدی برای بستن کانکشن و پاکسازی کامل رم بعد از اتمام هر تست
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _connection?.Close();
            _connection?.Dispose();
        }
        base.Dispose(disposing);
    }
}



