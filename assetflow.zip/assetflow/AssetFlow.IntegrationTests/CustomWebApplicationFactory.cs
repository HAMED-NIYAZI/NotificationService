﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace AssetFlow.IntegrationTests;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
}
