﻿using System.Net;
using FluentAssertions;

namespace AssetFlow.IntegrationTests.Api;

public class AppStartupTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;

    public AppStartupTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task Get_Swagger_Should_Return_Ok()
    {
        var response = await _client.GetAsync("/swagger/index.html");

        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}
