﻿using AssetFlow.Persistence.IntegrationTests.Fixtures;

namespace AssetFlow.Api.IntegrationTests.Controllers;

public class TaxControllerTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;

    public TaxControllerTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }





    [Fact]
    public async Task GetTaxSummaries_WithInvalidWharehouseId_ShouldReturnBadRequest()
    {
        //// Arrange
        //var warehouseGroupId = 0;
        //DateTime date = Convert.ToDateTime("2023-01-01");

        //var url =
        //    $"/api/Tax/GetTaxSummaries" +
        //    $"?warehouseGroupId={warehouseGroupId}" +
        //    $"&date={date}";

        //// Act
        //var response = await _client.GetAsync(url);

        //// Assert
        //response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        //response.StatusCode.Should().NotBe(HttpStatusCode.OK);
    }

    [Fact]
    public async Task SyncDataAndAllocateByCustomerJob_ShouldReturnOk()
    {
        // Arrange
        //var customerId = 1L;
        //var warehouseId = 2;
        //var symbolId = 3;

        //var url = $"/api/Tax/SyncDataAndAllocateByCustomerJob" +
        //          $"?customerId={customerId}&warehouseId={warehouseId}&symbolId={symbolId}";

        //// Act
        //var response = await _client.PostAsync(url, null);

        //// Assert
        //response.StatusCode.Should().Be(HttpStatusCode.OK);
    }



}
