﻿using AssetFlow.Persistence.IntegrationTests.Fixtures;

namespace AssetFlow.Api.IntegrationTests.Controllers;

public class HealthTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;

    public HealthTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetHealth_ShouldReturnSuccess()
    {
        //var response = await _client.GetAsync("/api/Tax/Health");

        //// Assert
        //response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);

        //var content = await response.Content.ReadAsStringAsync();

        //content.Should().NotBeNullOrWhiteSpace();
    }
}