﻿namespace AssetFlow.Domain.Entities
{

    public class AssetExit : AssetAllocation
    {
        public decimal Quantity { get; set; }
        public decimal AllocatedQuantity { get; set; }
        public int SequenceNo { get; set; }
        public long? AssetAllocationId { get; set; }
        public AssetAllocation? AssetAllocation { get; set; }
        public long? ClearanceId { get; set; }
        public AssetExit() { }
        public AssetExit(long assetTransactionId, decimal allocatedQuantity, int sequenceNo)
        {
            if (allocatedQuantity <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(allocatedQuantity));
            }

            AssetTransactionId = assetTransactionId;
            AllocatedQuantity = allocatedQuantity;
            SequenceNo = sequenceNo;
        }
    }
}
