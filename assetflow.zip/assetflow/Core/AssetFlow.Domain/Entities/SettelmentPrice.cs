﻿namespace AssetFlow.Domain.Entities
{
    public class SettelmentPrice
    {
        public int ContractID { get; set; }
        public DateTime Date { get; set; }
        public decimal Price { get; set; }
        public int SymbolId { get { return ContractID; } }
    }
}
