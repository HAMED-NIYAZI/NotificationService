﻿namespace AssetFlow.Domain.Entities
{
    public class AssetEntry : AssetAllocation
    {
        public decimal OriginalQuantity { get; set; }
        public decimal RemainingQuantity { get; set; }
        public long? EntranceId { get; set; }
        public AssetEntry()
        {
        }
        public bool IsOpen()
        {
            return RemainingQuantity > 0;
        }
    }
}
