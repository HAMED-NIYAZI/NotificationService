﻿namespace AssetFlow.Domain.Entities;

public readonly record struct AllocationStateKey(
    long UniqueId,
    int WarehouseId);
public class AllocationState
{
    public long Id { get; set; }
    public long? UniqueId { get; set; }
    public int WarehouseId { get; set; }
    public int SymbolId { get; set; }

    public bool IsBlocked { get; set; }
    public long AssetTransactionId { get; set; }

    public double? LastSnapshotBalance { get; set; } = null;

    public DateOnly? LastSnapshotDate { get; set; } = null;

    public double? WarehouseBalance { get; set; } = null;

    public DateOnly? WarehouseDate { get; set; } = null;

    public double? MarketBalance { get; set; } = null;

    public DateOnly? MarketDate { get; set; } = null;


    public bool IsSync
    {
        get
        {
            if (LastSnapshotBalance == WarehouseBalance && LastSnapshotDate == WarehouseDate)
                return true;
            return false;
        }
    }
}