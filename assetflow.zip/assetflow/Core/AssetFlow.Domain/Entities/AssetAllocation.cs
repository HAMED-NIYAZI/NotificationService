﻿namespace AssetFlow.Domain.Entities;

public abstract class AssetAllocation : BaseEntity
{
    public long AssetTransactionId { get; set; }
    public AssetTransaction AssetTransaction { get; set; } = null!;
    public AssetProcessDetail AssetProcessDetail { get; set; } = null!;
    public long? UniqueId { get; set; }
    public int SymbolId { get; set; }
    public int WarehouseId { get; set; }
    public long? TradeId { get; set; }
    public long ReferenceId { get; set; }
    public string? Description { get; set; }
    public bool HasConflict { get; set; } = false;
    public AssetSourceType AssetSourceType { get; set; }
    public AssetAllocationStatus Status { get; set; }
    public TradeType TradeType { get; set; } = TradeType.Trade;
    public decimal AvailableQuantity { get; set; }

    protected AssetAllocation()
    {
    }

}
