﻿namespace AssetFlow.Domain.Entities
{
    public class CustomerInvalidData : BaseEntity
    {
        public long AssetTransactionId { get; set; }
        public AssetTransaction AssetTransaction { get; set; } = null!;
        public long? UniqueId { get; set; }
        public int SymbolId { get; set; }
        public int WarehouseId { get; set; }
        public string? Description { get; set; }

        public long? TradeId { get; set; }
        public long? EntranceId { get; set; }
        public long? ClearanceId { get; set; }
        public long ReferenceId { get; set; }

    }
}
