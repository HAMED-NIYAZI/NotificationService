﻿namespace AssetFlow.Domain.Entities
{
    public class CdcTrade
    {
        public int TradeID { get; set; }
        public int ContractID { get; set; }
        public int? SellerExchangeID { get; set; }
        public int? SellerBrokerID { get; set; }
        public int? SellerCustomerID { get; set; }
        public int? BuyerExchangeID { get; set; }
        public int? BuyerBrokerID { get; set; }
        public int? BuyerCustomerID { get; set; }
        public int Count { get; set; }
        public decimal Price { get; set; }
        public short RecVersion { get; set; }
        public DateTime RecCreateTime { get; set; }
        public DateTime? RecModifyTime { get; set; }
        public required string RecStatus { get; set; }
        public int RecUserID { get; set; }
        public long? BuyerOrderID { get; set; }
        public long? SellerOrderID { get; set; }
        public string? C1 { get; set; }
        public DateTime? C2 { get; set; }
        public TradeType TradeType { get; set; } = TradeType.Trade;

    }


    public class CancelledTradeCdc
    {
        public int TradeID { get; set; }

        public int ContractID { get; set; }

        public int? SellerExchangeID { get; set; }

        public int? SellerBrokerID { get; set; }

        public int? SellerCustomerID { get; set; }

        public int? BuyerExchangeID { get; set; }

        public int? BuyerBrokerID { get; set; }

        public int? BuyerCustomerID { get; set; }

        public int Count { get; set; }

        public decimal Price { get; set; }

        public short RecVersion { get; set; }

        public DateTime RecCreateTime { get; set; }

        public DateTime? RecModifyTime { get; set; }

        public string RecStatus { get; set; } = null!;

        public int RecUserID { get; set; }

        public long? BuyerOrderID { get; set; }

        public long? SellerOrderID { get; set; }

        public DateTime CancelTime { get; set; }
    }
}

