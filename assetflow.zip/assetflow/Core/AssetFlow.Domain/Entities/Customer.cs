﻿namespace AssetFlow.Domain.Entities;

public class Customer
{
    public long CustomerID { get; set; }

    public string? CustomerName { get; set; }

    public char Status { get; set; }

    public DateTime? RecTime { get; set; }

    public string NationalID { get; set; } = null!;

    public long? CustomerID_IME { get; set; }

    public long? UniqueID { get; set; }

    public string? DisplayCode { get; set; }

    public short? CustomerType { get; set; }
}
