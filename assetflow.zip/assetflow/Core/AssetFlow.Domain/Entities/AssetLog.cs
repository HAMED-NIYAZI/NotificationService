﻿namespace AssetFlow.Domain.Entities
{
    public class AssetLog
    {

        public long Id { get; set; }
        public long? CallerUserId { get; set; }
        public long? UniqueId { get; set; }
        public string? Description { get; set; }
        public string? Request { get; set; }
        public string? Response { get; set; }
        public DateTime? CreateDate { get; set; } = DateTime.Now;
        public string? Exception { get; set; }
        public string? Function { get; set; }

    }
}
