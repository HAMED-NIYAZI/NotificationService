﻿namespace AssetFlow.Domain.Entities
{

    public enum AssetTransactionType
    {
        Buy = 1,     // B
        Entry = 2,  // E
        Sell = 3,         // S
        Clearance = 4,    // C
    }

    public enum AssetDirection
    {
        In = 1, //Entry
        Out = 2 //Exit
    }

    public enum AssetSourceType
    {
        MarketBuy = 1,        // B
        WarehouseEntry = 2    // E
    }


    public enum TradeType
    {
        None = 0,
        Trade = 1,         //N
        DeliveryORExercise = 2,   // D or E
    }

    public enum AssetTransactionStatus
    {
        UnTouched = 0,
        Draft = 1,
        Committed = 2, //Commited
        Reversed = 3,
        Cancelled = 4,
        Abnormal = 5, //Balance is negetive
    }

    public enum AssetProcessDetailStatus
    {
        UnTouched = 0,
        Draft = 1,
        Committed = 2, //Commited
        Reversed = 3,
        Cancelled = 4
    }



    public enum AssetProcessDetailType
    {
        Sell = 3,//Sell      // S
        Clearance = 4,//Exit // C
    }



    public enum AssetAllocationStatus
    {
        UnTouched = 0,
        Draft = 1,
        Committed = 2,
        Reversed = 3,
        Cancelled = 4
    }
}
