﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetFlow.Domain.Entities;

public class AssetBalanceNetDto
{
    public long Id { get; set; }
    public long CustomerId { get; set; }
    public int SymbolId { get; set; }
    public int WarehouseId { get; set; }
    public long? TradeId { get; set; }
    public long? EntranceId { get; set; }
    public long? ClearanceId { get; set; }
    public string? ReferenceId { get; set; }
    public int Type { get; set; }
    public int Direction { get; set; }
    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public DateTime AssetTransactionCreateDate { get; set; }
    public decimal Quantity2 { get; set; }
    public decimal Net { get; set; }
}
