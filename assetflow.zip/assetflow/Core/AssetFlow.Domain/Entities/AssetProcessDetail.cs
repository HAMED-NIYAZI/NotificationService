﻿using System.Text.Json.Serialization;

namespace AssetFlow.Domain.Entities
{
    public class AssetProcessDetail : BaseEntity
    {
        public long AssetAllocationId { get; set; }
        public AssetAllocation AssetAllocation { get; set; }

        public long AssetProcessId { get; set; }
        [JsonIgnore]
        public AssetProcess AssetProcess { get; set; }

        public decimal Quantity { get; set; }//SumCount
        public decimal Price { get; set; }//PriceAvg
        public string RuleCode { get; set; }
        public bool Included { get; set; }
        public AssetProcessDetailStatus Status { get; set; }
        public AssetProcessDetailType Type { get; set; }
        public string? Description { get; set; }

        public long ReferenceId { get; set; }
        public int SymbolId { get; set; }
        public int WarehouseId { get; set; }
        public long? UniqueId { get; set; }
        public long AssetProcessDetailUniqueId { get; } = DateTime.Now.Ticks;
    }
}
