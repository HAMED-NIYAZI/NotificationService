﻿namespace AssetFlow.Domain.Entities
{
    public class WarehouseCustomerEntrance
    {
        public long Id { get; set; }
        public long WarehouseCustomerEntranceId { get; set; }
        public decimal assetQuantity { get; set; }
        public DateTime receiveTime { get; set; }
        public long warehouseGroupID { get; set; }
        public long referenceId
        {
            get
            {
                return Convert.ToInt64(receiveTime.ToString("yyyyMMddHHmmssfff"));
            }
            set;
        }
        public long uniqueID { get; set; }
    }
    public class WarehouseCustomerClearance
    {
        public long Id { get; set; }
        public long referenceId { get; set; }
        public decimal executedQuantity { get; set; }
        public DateTime receiveTime { get; set; }
        public long warehouseGroupID { get; set; }
        public long? uniqueID { get; set; }
        public char clearanceType { get; set; }
        public long WarehouseCustomerClearanceId { get; set; }
        public long DrvCustomerID { get; set; }
    }
}
