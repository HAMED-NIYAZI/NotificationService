﻿namespace AssetFlow.Domain.Entities;


public class AssetTransaction : BaseEntity
{
    public long? CustomerId { get; set; }
    public long? UniqueId { get; set; }
    public int SymbolId { get; set; }
    public int WarehouseId { get; set; }
    public long? TradeId { get; set; }
    public long? EntranceId { get; set; }
    public long? ClearanceId { get; set; }
    public long ReferenceId { get; set; }
    public AssetTransactionType Type { get; set; }
    public TradeType TradeType { get; set; }
    public AssetDirection Direction { get; set; }
    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public DateTime AssetTransactionCreateDate { get; set; }
    public AssetTransactionStatus Status { get; set; }
    public ICollection<AssetAllocation> Allocations { get; set; } = [];
    public AssetTransaction() { }
}
