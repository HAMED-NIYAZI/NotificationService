﻿namespace AssetFlow.Domain.Entities
{
    public class Symbol
    {
        public int Id { get; set; }
        public int SymbolId { get; set; }
        public int WarehouseId { get; set; }
        public string? AssetName { get; set; }
        public decimal? ConversionRate { get; set; }
    }
}
