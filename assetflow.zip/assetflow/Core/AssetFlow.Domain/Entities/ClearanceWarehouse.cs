﻿using System.Text.Json.Serialization;

namespace AssetFlow.Domain.Entities;

public class ClearanceWarehouse
{
    public long Id { get; set; }
    public int ResultCode { get; set; }
    public decimal ExecutedQuantity { get; set; }
    public DateTime ReceiveTime { get; set; }
    public long Warehouse_ResponseID { get; set; }
    //public long Request_IMECustomerID { get; set; }
    public long? UniqueID { get; set; }
    //public int Request_DrvCustomerID { get; set; }
    public bool IsExecuted { get; set; }
    public long? ReferenceId { get; set; }


}


public class MarketCustomerClearanceResponse
{

    [JsonPropertyName("isSuccess")]
    public bool IsSuccess { get; set; }


    [JsonPropertyName("count")]
    public int Count { get; set; }


    [JsonPropertyName("message")]
    public string? Message { get; set; }


    [JsonPropertyName("data")]
    public IReadOnlyList<MarketCustomerClearance> Data { get; set; } = [];


    [JsonPropertyName("statusCode")]
    public int StatusCode { get; set; }
}

public class MarketCustomerClearance
{

    [JsonPropertyName("referenceId")]
    public long referenceId { get; set; }

    [JsonPropertyName("executedQuantity")]
    public decimal executedQuantity { get; set; }

    [JsonPropertyName("receiveTime")]
    public DateTime receiveTime { get; set; }

    [JsonPropertyName("warehouseGroupID")]
    public long warehouseGroupID { get; set; }

    //[JsonPropertyName("customerID_IME")]
    //public long customerID_IME { get; set; }

    [JsonPropertyName("uniqueID")]
    public long? uniqueID { get; set; }

    [JsonPropertyName("clearanceType")]
    public char clearanceType { get; set; }


    public long Id { get; set; }
    public long MarketCustomerClearanceId
    {
        get
        {
            return referenceId;
        }
        set;
    }
    public long? DrvCustomerID { get; set; }

}



public class MarketCustomerEntrance
{


    [JsonPropertyName("referenceId")]
    public long referenceId { get; set; }

    [JsonPropertyName("assetQuantity")]
    public decimal assetQuantity { get; set; }

    [JsonPropertyName("receiveTime")]
    public DateTime receiveTime { get; set; }

    [JsonPropertyName("warehouseGroupID")]
    public long warehouseGroupID { get; set; }

    //[JsonPropertyName("customerID_IME")]
    //public long customerID_IME { get; set; }

    [JsonPropertyName("uniqueID")]
    public long? uniqueID { get; set; }


    public long Id { get; set; }
    public long? WarehouseCustomerEntranceId { get; set; }
    public long? DrvCustomerID { get; set; }

}