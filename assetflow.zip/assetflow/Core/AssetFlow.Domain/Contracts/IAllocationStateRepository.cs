﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts;


public interface IAllocationStateRepository
{
    Task<AllocationState?> GetByKeysAsync(long uniqueId, int warehouseId, int symbolId);

    Task UpsertAsync(AllocationState entity);

}
