﻿using AssetFlow.Domain.Entities;
using System.Linq.Expressions;

namespace AssetFlow.Domain.Contracts;

public interface IAssetTransactionRepository
{
    Task<AssetTransaction?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    Task<List<AssetTransaction>?> GetYoungerDataAsync(long uniqueId, int warehouseId, DateTime assetTransactionCreateDate, CancellationToken cancellationToken = default);
    Task<List<AssetTransaction>?> GetYoungerDataAsync2(long uniqueId, int warehouseId, int symbolId, DateTime assetTransactionCreateDate, CancellationToken cancellationToken = default);
    Task RemoveFalseAllocatedData(List<AssetTransaction>? latestAssetTransactions);
    Task RemoveFalseAllocatedDataInMemory(List<AssetTransaction> transactions);
    Task<AssetTransaction?> GetByIdWithDetailsAsync(long id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<AssetTransaction>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<List<AssetTransaction>> GetAll(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<AssetTransaction>> GetAllAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default);
    Task<long> GetMaxTradeIdAsync(CancellationToken cancellationToken = default);
    Task<long> GetMaxTradeIdAsync(long uniqueId, long warehouseId, long symbolId);
    Task<long> GetMaxEntranceIdAsync(CancellationToken cancellationToken = default);
    Task<long> GetMaxEntranceIdAsync(long uniqueId, long warehouseId, long symbolId);
    Task<long> GetMaxClearanceIdAsync();
    Task<long> GetMaxClearanceIdAsync(long uniqueId, long warehouseId);
    Task<List<AssetTransaction>> GetAllUnTouchedAsync();
    Task<List<AssetTransaction>> GetAllUnTouchedWithTrackingAsync();
     Task<List<AssetTransaction>> GetAllUnTouchedAsync(int take = 1000000, CancellationToken cancellationToken = default);
    Task<List<AssetTransaction>> GetAllUnTouchedAsync(long uniqueId, long warehouseId, long symbolId, int take = 1000000, CancellationToken cancellationToken = default);
    Task<bool> CheckAbnormalTransactionsAsync(long uniqueId, int warehouseId, int symbolId = 0, long? referenceId = null, CancellationToken cancellationToken = default);
    Task<bool> CheckAbnormalTransactionsByReferenceIdAsync(long uniqueId, long? referenceId = null, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<AssetTransaction>> FindAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default);



    Task<AssetTransaction?> FirstOrDefaultAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default);

    Task<bool> ExistsAsync(long id, CancellationToken cancellationToken = default);

    Task<bool> AnyAsync(Expression<Func<AssetTransaction, bool>> predicate, CancellationToken cancellationToken = default);

    Task<int> CountAsync(Expression<Func<AssetTransaction, bool>>? predicate = null, CancellationToken cancellationToken = default);

    Task<bool> AddAsync(AssetTransaction assetTransaction, CancellationToken cancellationToken = default);

    Task<bool> AddRangeAsync(IEnumerable<AssetTransaction> assetTransactions, CancellationToken cancellationToken = default);

    Task<bool> Update(AssetTransaction assetTransaction);
    Task<bool> UpdateStatusAsync(AssetTransaction assetTransaction);
    Task<bool> UpdateRange(IEnumerable<AssetTransaction> assetTransactions);

    Task<bool> Delete(AssetTransaction assetTransaction);

    Task<bool> DeleteRange(IEnumerable<AssetTransaction> assetTransactions);

    Task BulkInsertAsync(List<AssetTransaction> transactions);
    Task<CustomerInvalidData> GetCustomerInvalidDataAsync(long uniqueId, int warehouseId);
    Task<List<AssetTransaction>>    GetTrackedGroupTransactionsForRebuildAsync(        long uniqueId,        int warehouseId,        int symbolId);

    IQueryable<AssetTransaction>  Query();
 
}
