﻿namespace AssetFlow.Domain.Contracts;

public interface ICustomerRepository
{
    Task ReloadCustomerMappingsAsync();

    long? GetUniqueID(long? customerId);

    long? GetCustomerId(long? uniqueId);
    Task<long> GetUniqeIdFromApi(long customerId);

    long? CustomerID_IMEByUniqueID(long? uniqueId);

    long? CustomerID_IMEByCustomerId(long? customerId);
}
