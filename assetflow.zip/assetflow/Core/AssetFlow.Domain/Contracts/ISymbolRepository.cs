﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts;

public interface ISymbolRepository
{
    Task<IReadOnlyList<Symbol>> GetAll();
    int GetWarehouseId(int symbolId);
    int GetSymbolId(int warehouseId);
    decimal? GetConversionRate(int warehouseId);
    void ReloadSymbolMappingsAsync();
}
