﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts;

public interface IWarehouseRepository
{

    Task<IReadOnlyList<WarehouseCustomerClearance>> GetClearanceAfterIdAsync(long lastId);
    Task<IReadOnlyList<WarehouseCustomerClearance>> GetClearanceAfterIdAsync(long lastId, long uniqueId, long warehouseId);
    Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId);
    Task<IReadOnlyList<WarehouseCustomerEntrance>> GetEntranceAfterIdAsync(long lastId, long uniqueId, long warehouseId);





    Task BulkUpsertWarehouseCustomerClearanceAsync(IReadOnlyCollection<WarehouseCustomerClearance> entities);
    Task BulkUpsertWarehouseCustomerEntranceAsync(IReadOnlyCollection<WarehouseCustomerEntrance> entities);
}
