﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts;

public interface IMarketRepository
{
    Task BulkUpsertAsync(IReadOnlyCollection<MarketCustomerClearance> entities);



}

