﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts
{
    public interface ICdcTradeRepository
    {
        Task<IReadOnlyList<CdcTrade>> GetAfterIdAsync(int lasttradeId, int take, CancellationToken cancellationToken = default);
        Task<IReadOnlyList<CdcTrade>> GetAfterIdAsync(long lasttradeId, long uniqueId, long warehouseId, long symbolId);
        Task<decimal> GetSettelmentPriceWithSymbolId(int symbolId, DateTime dateTime);
        Task ReloadSettelmentPriceAsync();
    }
}
