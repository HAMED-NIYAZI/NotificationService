﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Contracts;


public interface IAllocationStateStore
{
    Task<bool> IsBlock(AllocationStateKey key);
    Task BlockAsync(AllocationStateKey key);
    Task Unblock(AllocationStateKey key);
    Task CreateOrUpdateSnapshot(AllocationStateKey key, double balance, DateOnly date);
    Task CreateOrUpdateBalance(AllocationStateKey key, double balance, DateOnly date);
    Task<bool> IsSyncBalance(AllocationStateKey key);
    Task<AllocationState> TryGet(AllocationStateKey key);
}

