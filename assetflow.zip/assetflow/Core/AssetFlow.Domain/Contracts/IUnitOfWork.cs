﻿namespace AssetFlow.Domain.Contracts
{
    public interface IUnitOfWork
    {
        Task CommitAsync(CancellationToken cancellationToken = default);
        Task RollbackAsync(CancellationToken cancellationToken = default);
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
        Task BeginTransactionAsync(CancellationToken cancellationToken = default);
        void Detach<TEntity>(TEntity entity) where TEntity : class;
        void ClearTracking();

    }
}
