﻿using AssetFlow.Domain.Entities;
using System.Linq.Expressions;

namespace AssetFlow.Domain.Contracts;

public interface IAssetProcessDetailRepository
{
    Task<bool> AddAsync(AssetProcessDetail assetProcessDetail, CancellationToken cancellationToken = default);
    Task<bool> AddRangeAsync(List<AssetProcessDetail> assetProcess, CancellationToken cancellationToken = default);
    Task<AssetProcessDetail?> Get(Expression<Func<AssetProcessDetail, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetProcessDetail>?> GetAll(Expression<Func<AssetProcessDetail, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetProcessDetail>?> GetAll(long UniqueId, int SymbolId, int WarehouseId, CancellationToken cancellationToken = default);

}
