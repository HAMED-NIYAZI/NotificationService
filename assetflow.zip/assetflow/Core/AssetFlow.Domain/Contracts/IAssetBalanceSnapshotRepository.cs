﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.RepositoryInterfaces
{
    public interface IAssetBalanceSnapshotRepository
    {
        Task<bool> Save(AssetBalanceSnapshot assetBalanceSnapshot);
        Task<AssetBalanceSnapshot> GetLatest(AssetBalanceSnapshot assetBalanceSnapshot);
    }
}
