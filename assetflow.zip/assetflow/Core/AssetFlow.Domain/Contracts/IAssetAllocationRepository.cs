﻿using AssetFlow.Domain.Entities;
using System.Linq.Expressions;

namespace AssetFlow.Domain.Contracts;

public interface IAssetAllocationRepository
{
    Task<bool> Save(AssetAllocation assetEntry, CancellationToken cancellationToken = default);
    Task<AssetAllocation> Get(Expression<Func<AssetAllocation, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetAllocation>> GetAll(Expression<Func<AssetAllocation, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetExit>> GetAllAssetAllocation(Expression<Func<AssetExit, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetExit>> GetAllAssetAllocationForTaxSummaries(int WarehouseId, DateTime toThisDate, CancellationToken cancellationToken = default);
    Task<List<AssetEntry>> GetAvailableAssetAllocationAsync(long UniqueId, int SymbolId, CancellationToken cancellationToken = default);
    Task<List<AssetExit>> GetYoungInvalidTransactionsAsync(long UniqueId, int WarehouseId, DateTime minAssetTransactionCreateDate);
    Task<AssetAllocation> GetLatestSnapshot(AssetAllocation assetAllocation);
    Task UpdateLatestSnapshotToHasConflict(long UniqueId, int WarehouseId, int SymbolId);
    Task ResolveLatestSnapshotToHasConflict(long UniqueId, int WarehouseId, int SymbolId);
    Task<bool> Delete(AssetAllocation assetTransaction);
    Task<bool> DeleteRange(IEnumerable<AssetAllocation> assetTransactions);
    Task<bool> CheckAbnormalAvailableQuantity(long referenceId);
    Task<bool> CheckAbnormalAvailableQuantity2(long referenceId);
    Task<bool> CheckAbnormalAvailableQuantity(int warehouseGroupId);

    Task<bool> CheckReferenceIdHasAllocationData(long referenceId);
    Task<bool> CheckReferenceIdHasTransactionData(long referenceId);
    Task<AssetTransaction?> GetTransactionByReferenceId(long referenceId);
    Task<List<AssetAllocation>> GetTrackedGroupAllocationsForRebuildAsync(long uniqueId, int warehouseId, int symbolId);
    void RemoveRangeInMemory(IEnumerable<AssetAllocation> allocations);
    Task<AssetAllocation?> GetLatestSnapshotBeforeDateAsync(long uniqueId, int warehouseId, DateTime beforeDate, CancellationToken cancellationToken = default);
    Task<List<AssetEntry>> GetAssetEntriesByIdsAsync(
        IEnumerable<long> ids,
        CancellationToken cancellationToken = default);
}
