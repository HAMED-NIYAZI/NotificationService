﻿using AssetFlow.Domain.Entities;
using System.Runtime.CompilerServices;

namespace AssetFlow.Domain.Contracts
{
    public interface IAssetLogRepository
    {
        Task LogIt(Exception? exception, string? error = null, AssetTransaction? transaction = null, [CallerMemberName] string memberName = "", [CallerFilePath] string file = "", [CallerLineNumber] int line = 0);
        Task LogIt(AssetLog assetLog);
    }
}
