﻿using AssetFlow.Domain.Dtos;
using AssetFlow.Domain.Entities;
using System.Linq.Expressions;

namespace AssetFlow.Domain.Contracts;

public interface IAssetProcessRepository
{
    Task<bool> AddAsync(AssetProcess assetProcess, CancellationToken cancellationToken = default);
    Task<bool> AddRangeAsync(List<AssetProcess> assetProcesses, CancellationToken cancellationToken = default);
    Task<AssetProcessDto?> Get(Expression<Func<AssetProcess, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetProcessDto>?> GetTaxSummaries(int WarehouseId, DateTime inThisDate, CancellationToken cancellationToken = default);
    Task<List<AssetProcess>?> GetAll(Expression<Func<AssetProcess, bool>> predicate, CancellationToken cancellationToken = default);
    Task<List<AssetProcess>?> GetAll(int UniqueId, int SymbolId, int WarehouseId, CancellationToken cancellationToken = default);
}
