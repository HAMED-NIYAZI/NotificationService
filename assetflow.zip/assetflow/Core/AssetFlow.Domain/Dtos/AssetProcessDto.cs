﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Domain.Dtos
{
    public class AssetProcessDto : BaseEntity
    {
        public ICollection<AssetProcessDetailDto> AssetProcessDetails { get; set; } = [];
        public decimal Quantity { get; set; }//SumCount
        public decimal AveragePrice { get; set; }//PriceAvg
        public decimal TotalPrice { get; set; }//SumValue
        public string RuleCode { get; set; } = null!;
        public AssetProcessDetailStatus Status { get; set; }
        public AssetProcessDetailType Type { get; set; }
        public string? Description { get; set; }
        public long ReferenceId { get; set; }
        public int SymbolId { get; set; }
        public int WarehouseId { get; set; }
        public long UniqueId { get; set; }
        public long AssetProcessUniqueId { get; } = DateTime.Now.Ticks;
    }
}
