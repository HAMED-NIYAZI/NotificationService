﻿using AssetFlow.Application.Common.Services.ExternalServices;
using AssetFlow.Domain.Entities;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;

namespace AssetFlow.Application.Common.Services;

public class MarketService : IMarketService
{
    private readonly HttpClient _httpClient;
    private readonly MarketApiOptions _options;
    private readonly SemaphoreSlim _tokenLock = new(1, 1);
    private string? _token;

    public MarketService(HttpClient httpClient, IOptions<MarketApiOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;
    }

    /*
     
     نحوه استفاده
var clearances = await _marketService.GetClearances(
    referenceId: 123333333,
    dateFrom: new DateOnly(2023, 1, 1),
    dateTo: new DateOnly(2023, 6, 30),
    cancellationToken);

درخواست نهایی به این شکل ارسال می‌شود:

GET
Warehouse/GetCustomerClearanceQuantity
    ?ReferenceID=123333333
    &DateFrom=2023-01-01
    &DateTo=2023-06-30

Authorization:
Bearer {token}
     
     
     */
    public async Task<IReadOnlyList<MarketCustomerClearance>?> GetCustomersClearances(DateTime dateFrom, DateTime dateTo)
    {
        var token = await GetTokenAsync();
        string url = $"{_options.GetCustomerClearanceQuantityUrl}" + $"?DateFrom={dateFrom.ToString("yyyy-MM-ddTHH:mm:ss")}" + $"&DateTo={dateTo.ToString("yyyy-MM-ddTHH:mm:ss")}";
        using HttpRequestMessage request = new(HttpMethod.Get, url);
        request.Headers.Accept.Clear();
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/plain"));
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await _httpClient.SendAsync(request);

        if (response.StatusCode == HttpStatusCode.Unauthorized)
        {
            _token = null; token = await GetTokenAsync();

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            using var retryResponse = await _httpClient.SendAsync(request);
            retryResponse.EnsureSuccessStatusCode();
            var retryContent = await retryResponse.Content.ReadAsStringAsync();
            return DeserializeClearances(retryContent);
        }
        else if (response.StatusCode == HttpStatusCode.OK)
        {
            var content = await response.Content.ReadAsStringAsync();
            return DeserializeClearances(content);
        }
        else if (response.StatusCode == HttpStatusCode.TooManyRequests)
        {
            return null;
        }
        else
        {
            return null;
        }
    }

    private async Task<string> GetTokenAsync()
    {

        if (!string.IsNullOrWhiteSpace(_token))
        {
            return _token;
        }

        await _tokenLock.WaitAsync();

        try
        {
            if (!string.IsNullOrWhiteSpace(_token))
            {
                return _token;
            }

            var loginRequest = new { userName = _options.UserName, password = _options.Password };
            using StringContent content = new(Newtonsoft.Json.JsonConvert.SerializeObject(loginRequest), Encoding.UTF8, "application/json");
            using HttpResponseMessage response = await _httpClient.PostAsync(_options.LoginUrl, content);
            response.EnsureSuccessStatusCode();
            string responseContent = await response.Content.ReadAsStringAsync();
            _token = ExtractToken(responseContent);
            return string.IsNullOrWhiteSpace(_token)
                ? throw new InvalidOperationException("Market API login succeeded but token was not returned.")
                : _token;
        }
        finally
        {
            _tokenLock.Release();
        }
    }

    private static string ExtractToken(string responseContent)
    {

        Newtonsoft.Json.Linq.JObject json = Newtonsoft.Json.Linq.JObject.Parse(responseContent);
        string? token = json["token"]?.Value<string>() ?? json["accessToken"]?.Value<string>() ?? json["access_token"]?.Value<string>();


        if (string.IsNullOrWhiteSpace(token))
        {
            token = json.Value<string>();
        }
        return token ?? string.Empty;
    }
    private static IReadOnlyList<MarketCustomerClearance>? DeserializeClearances(string content)
    {
        if (string.IsNullOrWhiteSpace(content))
        {
            return null;
        }
        var result = Newtonsoft.Json.JsonConvert.DeserializeObject<MarketCustomerClearanceResponse>(content);
        return result.Data;
    }
}



public class MarketApiOptions
{
    public string BaseUrl { get; set; } = string.Empty;
    public string LoginUrl { get; set; } = string.Empty;
    public string GetCustomerClearanceQuantityUrl { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
