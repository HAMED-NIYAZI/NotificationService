﻿using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using Hangfire;

namespace AssetFlow.Application.Common.Services.BackgroundJobs;

public class SyncSettelmentPriceJob : ISyncSettelmentPriceJob
{
    private readonly ICdcTradeRepository _cdcTradeRepository;
    private static readonly TimeSpan TimeSpanBatch = TimeSpan.FromHours(1);

    public SyncSettelmentPriceJob(ICdcTradeRepository cdcTradeRepository)
    {
        _cdcTradeRepository = cdcTradeRepository;
    }

    [DisableConcurrentExecution(timeoutInSeconds: 0)]
    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _cdcTradeRepository.ReloadSettelmentPriceAsync();

        }
        catch (Exception)
        {
        }
        finally
        {
            BackgroundJob.Schedule(() => ExecuteAsync(), TimeSpanBatch);
        }
    }
}
