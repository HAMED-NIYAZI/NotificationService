﻿using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using Hangfire;

namespace AssetFlow.Application.Common.Services.BackgroundJobs
{

    public class HangfireRecurringJobScheduler : IRecurringJobScheduler
    {
        public void ScheduleJob()
        {
            //بروزرسانی قیمت های پایانی 
            //RecurringJob.AddOrUpdate<ISyncSettelmentPriceJob>(
            //    recurringJobId: "ISyncSettelmentPriceJob sync data every day at 8:00  10:00  11:00  15:00 17:00 18:00",
            //    methodCall: job => job.ExecuteAsync(CancellationToken.None),
            //    cronExpression: "0 8,10,11,15,17,18 * * *");

            //RecurringJob.AddOrUpdate<ISyncAllDataJob>(
            //recurringJobId: "allocate-every-6-minutes",
            //methodCall: job => job.SyncAllDataAndAllocateByBatch(),
            //cronExpression: Cron.MinuteInterval(6));
        }

        public void EnqueueJob()
        {
            //بروزرسانی قیمت های پایانی 
            BackgroundJob.Enqueue<ISyncSettelmentPriceJob>(job => job.ExecuteAsync(CancellationToken.None));

            //دریافت ترخیص و ورودی ها از سرویس انبار 
            //  BackgroundJob.Enqueue<ISyncClearanceAndEntranceFromWarehouse>(job => job.SyncDailyClearancesFromWarehouse());//داخل خودش هربار که تموم شد 5 دقیقه بعد اجرا میشه خودش //اجرای جاب برای دریافت  ترخیص ها از انبار 
            //  BackgroundJob.Enqueue<ISyncClearanceAndEntranceFromWarehouse>(job => job.SyncDailyEntrancesFromWarehouse()); //داخل خودش هربار که تموم شد 5 دقیقه بعد اجرا میشه خودش //اجرای جاب برای دریافت  ورودی ها از انبار 

            //دریافت ترخیص و ورودی ها از سرویس مارکت 
            // BackgroundJob.Enqueue<ISyncClearanceAndEntranceFromMarket>(job => job.SyncDailyClearancesFromMarket());//داخل خودش هربار که تموم شد 5 دقیقه بعد اجرا میشه خودش //اجرای جاب برای دریافت  ترخیص ها از مارکت 


            //دریافت ترید ها و ورودی های و ترخیص ها و سیو کردنشان و الوکیت کردن
            // BackgroundJob.Enqueue<ISyncAllDataJob>(job => job.SyncAllDataAndAllocateBySingle());
            BackgroundJob.Enqueue<ISyncAllDataJob>(job => job.SyncAllDataAndAllocateByGroup());


        }
    }

}
