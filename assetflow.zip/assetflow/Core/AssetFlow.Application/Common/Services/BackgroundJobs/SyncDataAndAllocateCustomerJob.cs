﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Hangfire;
using MapsterMapper;

namespace AssetFlow.Application.Common.Services.BackgroundJobs;

public class SyncDataAndAllocateCustomerJob : ISyncDataAndAllocateCustomerJob
{
    private readonly IWarehouseRepository _warehouseRepository;
    private readonly IAssetTransactionRepository _assetTransactionRepository;
    private readonly IAssetTransactionService _assetTransactionService;
    private readonly IMapper _mapper;
    private readonly ISymbolRepository _symbolRepository;
    private readonly IAssetLogRepository _log;
    private readonly ICdcTradeRepository _cdcTradeRepository;


    public SyncDataAndAllocateCustomerJob(ICdcTradeRepository cdcTradeRepository, IWarehouseRepository warehouseRepository, IAssetTransactionRepository assetTransactionRepository, IAssetTransactionService assetTransactionService, IMapper mapper, IUnitOfWork unitOfWork, ISymbolRepository symbolRepository, IAssetLogRepository logRepository, IAllocatorJob allocatorJob)
    {
        _warehouseRepository = warehouseRepository;
        _assetTransactionRepository = assetTransactionRepository;
        _assetTransactionService = assetTransactionService;
        _mapper = mapper;
        _symbolRepository = symbolRepository;
        _log = logRepository;
        _cdcTradeRepository = cdcTradeRepository;
    }

    [DisableConcurrentExecution(timeoutInSeconds: 0)]

    public async Task ExecuteAsync(long uniqueId, int warehouseId, int symbolId)
    {

        List<AssetTransactionSaveDtoBase>? clearances = [];
        List<AssetTransactionSaveDtoBase>? cdcTrades = [];
        List<AssetTransactionSaveDtoBase>? entrances = [];
        List<AssetTransactionSaveDtoBase>? baseDtos = [];

        do
        {

            clearances = [];
            cdcTrades = [];
            entrances = [];
            baseDtos = [];

            clearances = await GetClearance(uniqueId, warehouseId);
            cdcTrades = await GetTrades(uniqueId, warehouseId, symbolId);
            entrances = await GetEntrance(uniqueId, warehouseId);

            if (clearances?.Count > 0)
            {
                baseDtos.AddRange(clearances);
            }

            if (entrances?.Count > 0)
            {
                baseDtos.AddRange(entrances);
            }

            if (cdcTrades?.Count > 0)
            {
                baseDtos.AddRange(cdcTrades);
            }

            if (baseDtos != null && baseDtos?.Count > 0)
            {
                try
                {
                    baseDtos = baseDtos.OrderBy(x => x.AssetTransactionCreateDate).ToList();
                    await _assetTransactionService.SaveAndAllocateTransactionSingle(_mapper.Map<List<Domain.Entities.AssetTransaction>>(baseDtos));
                }
                catch (Exception ex)
                {
                    await _log.LogIt(ex, $"{nameof(SyncAllDataJob)} in {nameof(ExecuteAsync)}");
                    clearances = [];
                    cdcTrades = [];
                    entrances = [];
                    baseDtos = [];
                }
            }

        } while (baseDtos != null && baseDtos?.Count > 0);
    }

    private async Task<List<AssetTransactionSaveDtoBase>?> GetTrades(long uniqueId, long warehouseId, long symbolId)
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];


        try
        {


            long lastId = await _assetTransactionRepository.GetMaxTradeIdAsync();

            IReadOnlyList<CdcTrade> data = await _cdcTradeRepository.GetAfterIdAsync(lastId, uniqueId, warehouseId, symbolId);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            foreach (CdcTrade item in data)
            {
                if ((item.BuyerCustomerID is null || item.SellerCustomerID is null) && item.Price == 0)
                {
                    item.TradeType = TradeType.DeliveryORExercise;
                    item.Price = await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(item.ContractID, item.RecCreateTime);
                }
            }

            baseDtos.AddRange(_mapper.Map<List<EntryAssetTransactionSaveDto>>(data));
            baseDtos.AddRange(_mapper.Map<List<ExitAssetTransactionSaveDto>>(data));
            foreach (AssetTransactionSaveDtoBase dto in baseDtos)
            {
                dto.WarehouseId = _symbolRepository.GetWarehouseId(dto.SymbolId);
            }

            baseDtos = baseDtos.Where(x => x.UniqueId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.TradeId).ThenBy(x => x.Type).ToList();

            return baseDtos;
        }
        catch (Exception ex)
        {
            await _log.LogIt(ex);
            throw;
        }
    }

    private async Task<List<AssetTransactionSaveDtoBase>?> GetClearance(long uniqueId, int warehouseId)
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];
        List<ExitAssetTransactionSaveDto> clearanceAssetTransactionDtoList = [];

        try
        {
            long lastId = await _assetTransactionRepository.GetMaxClearanceIdAsync(uniqueId, warehouseId);


            IReadOnlyList<WarehouseCustomerClearance> data = await _warehouseRepository.GetClearanceAfterIdAsync(lastId, uniqueId, warehouseId);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            if (data != null && data?.Count > 0)
            {
                clearanceAssetTransactionDtoList = _mapper.Map<List<ExitAssetTransactionSaveDto>>(data);
                clearanceAssetTransactionDtoList.ForEach(x => x.SymbolId = _symbolRepository.GetSymbolId(x.WarehouseId));
                clearanceAssetTransactionDtoList.ForEach(async x =>
                x.Price = x.Price == 0 ? await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(x.SymbolId, x.AssetTransactionCreateDate) : x.Price
                );
            }

            baseDtos.AddRange(clearanceAssetTransactionDtoList);
            baseDtos = baseDtos.Where(x => x.UniqueId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.TradeId).ThenBy(x => x.Type).ToList();

            return baseDtos;
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
            throw;
        }
    }

    private async Task<List<AssetTransactionSaveDtoBase>?> GetEntrance(long uniqueId, long warehouseId)
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];
        List<EntryAssetTransactionSaveDto> entranceAssetTransactionDtoList = [];
        try
        {
            long lastId = await _assetTransactionRepository.GetMaxEntranceIdAsync();

            IReadOnlyList<WarehouseCustomerEntrance> data = await _warehouseRepository.GetEntranceAfterIdAsync(lastId, uniqueId, warehouseId);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            if (data != null && data?.Count > 0)
            {
                entranceAssetTransactionDtoList = _mapper.Map<List<EntryAssetTransactionSaveDto>>(data);
                entranceAssetTransactionDtoList.ForEach(x => x.SymbolId = _symbolRepository.GetSymbolId(x.WarehouseId));
                entranceAssetTransactionDtoList.ForEach(async x => x.Price = x.Price == 0 ? await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(x.SymbolId, x.AssetTransactionCreateDate) : x.Price);
            }

            baseDtos.AddRange(entranceAssetTransactionDtoList);
            baseDtos = baseDtos.Where(x => x.UniqueId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.TradeId).ThenBy(x => x.Type).ToList();

            return baseDtos;
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
            throw;
        }
    }

}
