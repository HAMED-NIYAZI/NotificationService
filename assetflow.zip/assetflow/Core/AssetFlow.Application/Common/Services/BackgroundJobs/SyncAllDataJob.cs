﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Hangfire;
using MapsterMapper;
using Newtonsoft.Json;
#pragma warning disable
namespace AssetFlow.Application.Common.Services.BackgroundJobs;

public class SyncAllDataJob : ISyncAllDataJob
{
    private readonly IWarehouseRepository _warehouseRepository;
    private readonly IAssetTransactionRepository _assetTransactionRepository;
    private readonly IAssetTransactionService _assetTransactionService;
    private readonly IMapper _mapper;
    private readonly ICustomerRepository _customerRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ISymbolRepository _symbolRepository;
    private readonly IAssetLogRepository _log;
    private readonly IAllocatorJob _allocatorJob;
    private readonly ICdcTradeRepository _cdcTradeRepository;
    private readonly ISyncClearanceAndEntranceFromWarehouse _syncClearanceAndEntranceFromWarehouse;
    private const int batchSize = 6000000;
    private static TimeSpan TimeSpanBatch = TimeSpan.FromMinutes(0) + TimeSpan.FromSeconds(5);


    public SyncAllDataJob(ISyncClearanceAndEntranceFromWarehouse syncClearanceAndEntranceFromWarehouse, ICustomerRepository customerRepository, ICdcTradeRepository cdcTradeRepository, IWarehouseRepository warehouseRepository, IAssetTransactionRepository assetTransactionRepository, IAssetTransactionService assetTransactionService, IMapper mapper, IUnitOfWork unitOfWork, ISymbolRepository symbolRepository, IAssetLogRepository logRepository, IAllocatorJob allocatorJob)
    {
        _warehouseRepository = warehouseRepository;
        _assetTransactionRepository = assetTransactionRepository;
        _assetTransactionService = assetTransactionService;
        _mapper = mapper;
        _unitOfWork = unitOfWork;
        _symbolRepository = symbolRepository;
        _log = logRepository;
        _allocatorJob = allocatorJob;
        _cdcTradeRepository = cdcTradeRepository;
        _customerRepository = customerRepository;
        _syncClearanceAndEntranceFromWarehouse = syncClearanceAndEntranceFromWarehouse;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {

        List<AssetTransactionSaveDtoBase>? clearances = [];
        List<AssetTransactionSaveDtoBase>? cdcTrades = [];
        List<AssetTransactionSaveDtoBase>? entrances = [];
        List<AssetTransactionSaveDtoBase>? baseDtos = [];



        clearances = [];
        cdcTrades = [];
        entrances = [];
        baseDtos = [];

        clearances = await GetClearance();
        cdcTrades = await GetTrades();
        entrances = await GetEntrance();

        if (clearances?.Count > 0)
        {
            baseDtos.AddRange(clearances);
        }

        if (entrances?.Count > 0)
        {
            baseDtos.AddRange(entrances);
        }

        if (cdcTrades?.Count > 0)
        {
            baseDtos.AddRange(cdcTrades);
        }

        if (baseDtos != null && baseDtos?.Count > 0)
        {
            try
            {
                baseDtos = baseDtos.OrderBy(x => x.AssetTransactionCreateDate).ToList();
                await _allocatorJob.SaveAndAllocateTransactionGroup(_mapper.Map<List<Domain.Entities.AssetTransaction>>(baseDtos));
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, $"{nameof(SyncAllDataJob)} in {nameof(ExecuteAsync)}");
                clearances = [];
                cdcTrades = [];
                entrances = [];
                baseDtos = [];
            }
        }

    }


    private async Task<List<AssetTransactionSaveDtoBase>?> GetTrades()
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];


        try
        {



            long lastId = await _assetTransactionRepository.GetMaxTradeIdAsync();

            IReadOnlyList<CdcTrade> data = await _cdcTradeRepository.GetAfterIdAsync((int)lastId, batchSize);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            foreach (CdcTrade item in data)
            {
                if ((item.BuyerCustomerID is null || item.SellerCustomerID is null) && item.Price == 0)
                {
                    item.TradeType = TradeType.DeliveryORExercise;
                    item.Price = await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(item.ContractID, item.RecCreateTime);
                }
                if (item.Price == 0) item.Price = await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(item.ContractID, item.RecCreateTime);
            }

            baseDtos.AddRange(_mapper.Map<List<EntryAssetTransactionSaveDto>>(data));
            baseDtos.AddRange(_mapper.Map<List<ExitAssetTransactionSaveDto>>(data));


            foreach (AssetTransactionSaveDtoBase item in baseDtos)
            {
                if (item.CustomerId is null || item.CustomerId == 0) continue;
                item.WarehouseId = _symbolRepository.GetWarehouseId(item.SymbolId);
                item.UniqueId = _customerRepository.GetUniqueID(item.CustomerId);
                if (item.UniqueId is null || item.UniqueId == 0)
                {
                    var UniqueId = await _customerRepository.GetUniqeIdFromApi((long)item.CustomerId);
                    item.UniqueId = UniqueId;
                    if (item.UniqueId is null || item.UniqueId == 0)
                        await _log.LogIt(null, "line 142: GetTrades  = > item.UniqueId is null || item.UniqueId == 0  => " + JsonConvert.SerializeObject(item));
                }

            }


            baseDtos = baseDtos.Where(x => x.CustomerId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.TradeId).ThenBy(x => x.CreateDate).ToList();
            return baseDtos;
        }
        catch (Exception ex)
        {
            await _log.LogIt(ex);
            throw;
        }
    }
    private async Task<List<AssetTransactionSaveDtoBase>?> GetClearance()
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];
        List<ExitAssetTransactionSaveDto> clearanceAssetTransactionDtoList = [];


        try
        {
            long lastId = await _assetTransactionRepository.GetMaxClearanceIdAsync();


            IReadOnlyList<WarehouseCustomerClearance> data = await _warehouseRepository.GetClearanceAfterIdAsync(lastId);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            if (data != null && data?.Count > 0)
            {
                clearanceAssetTransactionDtoList = _mapper.Map<List<ExitAssetTransactionSaveDto>>(data);

                foreach (var item in clearanceAssetTransactionDtoList)
                {
                    item.SymbolId = _symbolRepository.GetSymbolId(item.WarehouseId);
                    item.Quantity = -item.Quantity * (decimal)(_symbolRepository.GetConversionRate(item.WarehouseId));
                    if (item.Price == 0) item.Price = await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(item.SymbolId, item.AssetTransactionCreateDate);
                    if (item.CustomerId == 0 || item.CustomerId is null) item.CustomerId = (long)_customerRepository.GetCustomerId(item.UniqueId);
                }
            }

            baseDtos.AddRange(clearanceAssetTransactionDtoList);
            baseDtos = baseDtos.Where(x => x.UniqueId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.ClearanceId).ThenBy(x => x.CreateDate).ToList();
            return baseDtos;
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
            throw;

        }
    }

    private async Task<List<AssetTransactionSaveDtoBase>?> GetEntrance()
    {
        List<AssetTransactionSaveDtoBase> baseDtos = [];
        List<EntryAssetTransactionSaveDto> entranceAssetTransactionDtoList = [];
        try
        {
            long lastId = await _assetTransactionRepository.GetMaxEntranceIdAsync();


            IReadOnlyList<WarehouseCustomerEntrance> data = await _warehouseRepository.GetEntranceAfterIdAsync(lastId);

            if (data == null || data.Count == 0)
            {
                return null;
            }

            if (data != null && data?.Count > 0)
            {
                entranceAssetTransactionDtoList = _mapper.Map<List<EntryAssetTransactionSaveDto>>(data);
                foreach (var item in entranceAssetTransactionDtoList)
                {
                    item.SymbolId = _symbolRepository.GetSymbolId(item.WarehouseId);
                    item.Quantity = item.Quantity * (decimal)(_symbolRepository.GetConversionRate(item.WarehouseId));
                    if (item.Price == 0) item.Price = await _cdcTradeRepository.GetSettelmentPriceWithSymbolId(item.SymbolId, item.AssetTransactionCreateDate);

                    if (item.CustomerId == 0 || item.CustomerId is null)
                    {
                        try
                        {
                            long? uid = _customerRepository.GetCustomerId(item.UniqueId);
                            if (uid != null && uid > 0) item.CustomerId = uid;
                        }
                        catch (Exception ex)
                        {

                        }

                    }

                }
            }

            baseDtos.AddRange(entranceAssetTransactionDtoList);
            baseDtos = baseDtos.Where(x => x.UniqueId > 0).OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.EntranceId).ThenBy(x => x.CreateDate).ToList();

            return baseDtos;

        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
            throw;
        }
    }


    [DisableConcurrentExecution(timeoutInSeconds: 0)]
    public async Task SyncAllDataAndAllocateByGroup()
    {
        try
        {
            await SaveTransactionsBulk();
            await _allocatorJob.GetTransactionsAndAllocateByGroup();
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
        }
        finally
        {
            BackgroundJob.Schedule(() => SyncAllDataAndAllocateByGroup(), TimeSpanBatch);
        }
    }

    [DisableConcurrentExecution(timeoutInSeconds: 0)] // 0 یعنی اگر جاب قبلی در حال اجراست، اجرای جدید بلافاصله رد/اسکیپ شود
    public async Task SyncAllDataAndAllocateBySingle()
    {
        try
        {
            await SaveTransactionsBulk();
            await _allocatorJob.GetAllTransactionsAndAllocateBySingle();
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
        }
        finally
        {
            BackgroundJob.Schedule(() => SyncAllDataAndAllocateBySingle(), TimeSpanBatch);
        }
    }

    private async Task SaveTransactionsBulk()
    {
        try
        {


            List<AssetTransactionSaveDtoBase>? clearances = [];
            List<AssetTransactionSaveDtoBase>? cdcTrades = [];
            List<AssetTransactionSaveDtoBase>? entrances = [];
            List<AssetTransactionSaveDtoBase>? baseDtos = [];

            do
            {


            //    await _syncClearanceAndEntranceFromWarehouse.SyncDailyClearancesFromWarehouse();//داخل خودش هربار که تموم شد 5 دقیقه بعد اجرا میشه خودش //اجرای جاب برای دریافت  ترخیص ها از انبار 
             //   await _syncClearanceAndEntranceFromWarehouse.SyncDailyEntrancesFromWarehouse(); //داخل خودش هربار که تموم شد 5 دقیقه بعد اجرا میشه خودش //اجرای جاب برای دریافت  ورودی ها از انبار 




                clearances = [];
                cdcTrades = [];
                entrances = [];
                baseDtos = [];

                clearances = await GetClearance();
                cdcTrades = await GetTrades();
                entrances = await GetEntrance();

                if (clearances?.Count > 0)
                {
                    baseDtos.AddRange(clearances);
                }

                if (entrances?.Count > 0)
                {
                    baseDtos.AddRange(entrances);
                }

                if (cdcTrades?.Count > 0)
                {
                    baseDtos.AddRange(cdcTrades);
                }

                if (baseDtos != null && baseDtos?.Count > 0)
                {
                    try
                    {
                        baseDtos = baseDtos.OrderBy(x => x.AssetTransactionCreateDate).ToList();

                        foreach (AssetTransactionSaveDtoBase[] batch in baseDtos.Chunk(50_000))
                        {
                            List<Domain.Entities.AssetTransaction> transactions = _mapper.Map<List<Domain.Entities.AssetTransaction>>(batch);
                            await _assetTransactionRepository.BulkInsertAsync(transactions);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }
                    catch (Exception ex)
                    {
                        await _log.LogIt(ex, $"{nameof(SyncAllDataJob)} in {nameof(SaveTransactionsBulk)}");
                        clearances = [];
                        cdcTrades = [];
                        entrances = [];
                        baseDtos = [];
                    }
                }

            } while (baseDtos != null && baseDtos?.Count > 0);
        }
        catch (Exception ex)
        {
            _log.LogIt(ex);
        }
    }
}
