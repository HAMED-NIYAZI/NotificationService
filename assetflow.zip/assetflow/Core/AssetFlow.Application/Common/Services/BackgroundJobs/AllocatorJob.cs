﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;

namespace AssetFlow.Application.Common.Services.BackgroundJobs;

public class AllocatorJob : IAllocatorJob
{
    private readonly IAssetTransactionRepository _assetTransactionRepository;
    private readonly IAssetLogRepository _log;
    private readonly IAssetTransactionProcessService _assetTransactionProcessService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IAllocationStateStore _allocationStateStore;
    private readonly IGroupJobRegistry _registry;
    private readonly IAssetAllocationRepository _assetAllocationRepository;


    public AllocatorJob(IAssetAllocationRepository assetAllocationRepository, IGroupJobRegistry registry, IAllocationStateStore allocationStateStore, IAssetTransactionProcessService assetTransactionProcessService, IAssetTransactionRepository assetTransactionRepository, IAssetLogRepository assetLogRepository, IUnitOfWork unitOfWork)
    {
        _assetTransactionProcessService = assetTransactionProcessService;
        _assetTransactionRepository = assetTransactionRepository;
        _log = assetLogRepository;
        _unitOfWork = unitOfWork;
        _allocationStateStore = allocationStateStore;
        _registry = registry;
        _assetAllocationRepository = assetAllocationRepository;
    }


    //allocate for a all AllUnTouched AssetTransaction
    public async Task ExecuteBatchAsync(CancellationToken cancellationToken = default)
    {

        #region proccess AssetTransaction
        List<Domain.Entities.AssetTransaction> unTouchedAssetTransaction = await _assetTransactionRepository.GetAllUnTouchedAsync();
        if (unTouchedAssetTransaction == null || unTouchedAssetTransaction.Count == 0)
        {
            return;
        }
        foreach (Domain.Entities.AssetTransaction assetTransaction in unTouchedAssetTransaction)
        {

            bool resProcess = await _assetTransactionProcessService.ProcessAsync(assetTransaction, cancellationToken);
            if (resProcess)
            {
                await _unitOfWork.SaveChangesAsync(cancellationToken);
            }
            else
            {
                await _log.LogIt(null, "Error in Allocation", assetTransaction);
            }
        }
        #endregion

    }


    //allocate per customer 
    public async Task AllocateSingleAsync(long uniqueId, long warehouseId, long symbolId, CancellationToken cancellationToken = default)
    {

        List<Domain.Entities.AssetTransaction> unTouchedAssetTransaction = await _assetTransactionRepository.GetAllUnTouchedAsync(uniqueId, warehouseId, symbolId, 10000, cancellationToken);
        if (unTouchedAssetTransaction == null || unTouchedAssetTransaction.Count == 0)
        {
            return;
        }

        foreach (Domain.Entities.AssetTransaction assetTransaction in unTouchedAssetTransaction)
        {

            bool resProcess = await _assetTransactionProcessService.ProcessAsync(assetTransaction, cancellationToken);
            if (resProcess)
            {
                await _unitOfWork.SaveChangesAsync(cancellationToken);
            }
            else
            {
                await _log.LogIt(null, "Error in Allocation", assetTransaction);
            }
        }
    }


    public async Task GetTransactionsAndAllocateByGroup(CancellationToken cancellationToken = default)
    {
        List<Domain.Entities.AssetTransaction> unTouchedAssetTransaction = await _assetTransactionRepository.GetAllUnTouchedWithTrackingAsync();

        await SaveAndAllocateTransactionGroup(unTouchedAssetTransaction);
    }

    public async Task GetAllTransactionsAndAllocateBySingle(CancellationToken cancellationToken = default)
    {
        List<Domain.Entities.AssetTransaction> unTouchedAssetTransactions = await _assetTransactionRepository.GetAllUnTouchedAsync();

        Domain.Entities.AssetTransaction unTouchedAssetTransaction = new();
        try
        {
            int c = 0;
            foreach (Domain.Entities.AssetTransaction transaction in unTouchedAssetTransactions)
            {
                unTouchedAssetTransaction = transaction;
                bool hasYoungerUntouchedAssetTransactions = await _assetTransactionRepository.AnyAsync(x =>
                                                    x.UniqueId == transaction.UniqueId &&
                                                    x.WarehouseId == transaction.WarehouseId &&
                                                    x.AssetTransactionCreateDate < transaction.AssetTransactionCreateDate &&
                                                    x.Status == AssetTransactionStatus.UnTouched);
                if (hasYoungerUntouchedAssetTransactions) continue;
                c++;
                bool resultRebuild = await ReBuildAndAllocate(transaction);

            }

        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(GetAllTransactionsAndAllocateBySingle), unTouchedAssetTransaction);
        }
    }

    public async Task GetAllCustomerTransactionsAndAllocateBySingle(long uniqueId, long warehouseId, long symbolId)
    {
        List<Domain.Entities.AssetTransaction> unTouchedAssetTransactions = await _assetTransactionRepository.GetAllUnTouchedAsync(uniqueId, warehouseId, symbolId);
        Domain.Entities.AssetTransaction unTouchedAssetTransaction = new();
        try
        {
            foreach (Domain.Entities.AssetTransaction transaction in unTouchedAssetTransactions)
            {
                if (await _allocationStateStore.IsBlock(new AllocationStateKey(Convert.ToInt64(transaction.UniqueId), transaction.WarehouseId)))
                {
                    continue;
                }
                unTouchedAssetTransaction = transaction;
                await ReBuildAndAllocate(transaction);
                //if (previousJobId is null)
                //{
                //    previousJobId = BackgroundJob.Enqueue(() => ReBuildAndAllocate(transaction));
                //}
                //else
                //{
                //    previousJobId = BackgroundJob.ContinueJobWith(previousJobId, () => ReBuildAndAllocate(transaction));
                //}
            }

        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(GetAllTransactionsAndAllocateBySingle), unTouchedAssetTransaction);
        }
    }

    public async Task SaveAndAllocateTransactionGroup(List<Domain.Entities.AssetTransaction> transactions)
    {
        var groups = transactions.GroupBy(x => new { x.UniqueId, x.WarehouseId }).ToList().OrderBy(x => x.LongCount());

        foreach (var group in groups)
        {
            var items = group.ToList();
            var key = new GroupKey(items[0].UniqueId, items[0].WarehouseId);
            if (!_registry.TryRegister(key)) continue;
            //await ProcessGroupInMemory(items, key.UniqueId, key.WarehouseId);
            await ProcessGroup_(items, key.UniqueId, key.WarehouseId);

        }

    }
    public async Task ProcessGroup(List<Domain.Entities.AssetTransaction> transactions, long? uniqueId = null, int? warehouseId = null)
    {
        var key = new GroupKey(uniqueId, warehouseId);

        try
        {
            Domain.Entities.AssetTransaction first = transactions[0];
            if (transactions == null || transactions.Count == 0) return;

            Domain.Entities.AssetTransaction? oldestTransaction = transactions.MinBy(x => x.AssetTransactionCreateDate);
            List<Domain.Entities.AssetTransaction>? latestAssetTransactions = await _assetTransactionRepository.GetYoungerDataAsync(Convert.ToInt64(oldestTransaction.UniqueId), oldestTransaction.WarehouseId, oldestTransaction.AssetTransactionCreateDate);
            if (latestAssetTransactions != null && latestAssetTransactions?.Count > 0)
            {
                //TODO اگر صادر شده بود ریبیلد نکن
                var allocations = latestAssetTransactions.SelectMany(x => x.Allocations).ToList();
                if (allocations.Count > 0 && allocations.Any(x => x.Status == AssetAllocationStatus.Committed))
                {
                    //log امکان الوکیت کردن وجود ندارد چون کامیت شده دارد
                    return;
                }

                // ۱. بررسی عدم وجود تخصیص کامیت‌شده
                //اگر صادر شده بود ریبیلد نکن
                bool hasCommittedAllocation = latestAssetTransactions
                    .Where(x => x.Allocations != null)
                    .SelectMany(x => x.Allocations)
                    .Any(x => x.Status == AssetAllocationStatus.Committed);

                if (hasCommittedAllocation)
                {
                    //  log. "امکان تخصیص مجدد وجود ندارد؛ رکوردهایی با وضعیت Committed یافت شد.");
                    return;
                }
                // ۲. حذف الوکیت های ‌ نامعتبر قبلی
                await _assetTransactionRepository.RemoveFalseAllocatedData(latestAssetTransactions);
                foreach (Domain.Entities.AssetTransaction tx in latestAssetTransactions)
                {
                    tx.Status = AssetTransactionStatus.UnTouched;
                }
                transactions.AddRange(latestAssetTransactions);
                //مرتب کن دیتا را
                transactions = transactions
                .DistinctBy(x => x.Id)
                .OrderBy(x => x.AssetTransactionCreateDate)
                .ToList();

                await _allocationStateStore.Unblock(new AllocationStateKey(Convert.ToInt64(first.UniqueId), first.WarehouseId));
            }


            //var allTransactions = await _assetTransactionRepository.GetAllAsync(x =>
            //                                                                    x.UniqueId == first.UniqueId &&
            //                                                                    x.WarehouseId == first.WarehouseId &&
            //                                                                    x.SymbolId == first.SymbolId);


            //var existingKeys = allTransactions.Select(x => (
            //                                     x.UniqueId,
            //                                     x.TradeId,
            //                                     x.ReferenceId,
            //                                     x.ClearanceId,
            //                                     x.EntranceId,
            //                                     x.Quantity,
            //                                     x.Type))
            //                                 .ToHashSet();

            //transactions.RemoveAll(x => existingKeys.Contains((
            //                        x.UniqueId,
            //                        x.TradeId,
            //                        x.ReferenceId,
            //                        x.ClearanceId,
            //                        x.EntranceId,
            //                        x.Quantity,
            //                        x.Type)));

            // await AllocateSingleAsync(Convert.ToInt64(first.UniqueId), first.WarehouseId, first.SymbolId);



            foreach (Domain.Entities.AssetTransaction item in transactions)
            {
                if (await _allocationStateStore.IsBlock(new AllocationStateKey(Convert.ToInt64(item.UniqueId), item.WarehouseId)))
                {
                    //continue;
                    break;
                }

                bool resProcess = await _assetTransactionProcessService.ProcessAsync(item);
                if (resProcess)
                {
                    await _unitOfWork.SaveChangesAsync();
                }
                else
                {
                    //log
                }
            }



        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(this.GetType));
        }
        finally
        {
            _registry.Unregister(key);
        }
    }


    public async Task ProcessGroupInMemory(List<Domain.Entities.AssetTransaction> transactions, long? uniqueId = null, int? warehouseId = null)
    {
        if (transactions == null || transactions.Count == 0) return;

        var key = new GroupKey(uniqueId, warehouseId);

        // Sort فقط یک بار - با List.Sort درجا یا ساخت لیست جدید (بدون تغییر روی ورودی)
        var sorted = transactions.OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).ToList();

        Domain.Entities.AssetTransaction first = sorted[0];
        long targetUniqueId = Convert.ToInt64(first.UniqueId);
        int targetWarehouseId = first.WarehouseId;

        try
        {
            // Trackers 
            var workingById = new Dictionary<long, Domain.Entities.AssetTransaction>(sorted.Count * 2);

            var falseAllocationIds = new HashSet<long>();
            var falseAllocationSeenIds = new HashSet<long>();
            var falseAllocations = new List<AssetAllocation>();

            var resetTransactionIds = new HashSet<long>();

            // local helpers - فقط capture، بدون allocation اضافه
            void Track(Domain.Entities.AssetTransaction tx)
            {
                if (tx is null) return;
                workingById[tx.Id] = tx;
            }

            //  تراکنش‌های ورودی
            foreach (Domain.Entities.AssetTransaction? tx in sorted) Track(tx);

            // get younger transactions from  db
            List<Domain.Entities.AssetTransaction>? youngerTransactions = await _assetTransactionRepository.GetYoungerDataAsync(targetUniqueId, targetWarehouseId, first.AssetTransactionCreateDate);

            if (youngerTransactions != null && youngerTransactions.Count > 0)
            {
                foreach (Domain.Entities.AssetTransaction tx in youngerTransactions)
                {
                    ICollection<AssetAllocation> allocs = tx.Allocations;
                    if (allocs != null)
                    {
                        foreach (AssetAllocation alloc in allocs)
                        {
                            if (alloc.Status == AssetAllocationStatus.Committed) return;

                            if (falseAllocationIds.Add(alloc.Id))
                            {
                                falseAllocations.Add(alloc);
                                falseAllocationSeenIds.Add(alloc.Id);
                            }
                        }
                    }

                    resetTransactionIds.Add(tx.Id);
                    Track(tx);
                }
            }

            //   قدیمی‌ترین تاریخ برای rebuild
            // (چون لیست sort شده، همان first است)
            DateTime earliestDate = first.AssetTransactionCreateDate;

            //  Available allocations
            List<AssetEntry>? availableAllocations = await _assetAllocationRepository.GetAvailableAssetAllocationAsync(targetUniqueId, targetWarehouseId, CancellationToken.None) ?? new List<AssetEntry>();

            if (availableAllocations.Count > 0)
            {
                availableAllocations.RemoveAll(x => falseAllocationIds.Contains(x.Id) || resetTransactionIds.Contains(x.AssetTransactionId));
            }

            //  Invalid allocations
            List<AssetExit> invalidAllos = await _assetAllocationRepository.GetYoungInvalidTransactionsAsync(targetUniqueId, targetWarehouseId, earliestDate);

            if (invalidAllos != null && invalidAllos.Count > 0)
            {
                foreach (AssetExit? invalid in invalidAllos)
                {
                    if (invalid is null) continue;

                    if (falseAllocationSeenIds.Add(invalid.Id))
                    {
                        falseAllocations.Add(invalid);
                    }

                    AssetAllocation? parent = invalid.AssetAllocation;
                    if (parent != null && falseAllocationSeenIds.Add(parent.Id))
                    {
                        falseAllocations.Add(parent);
                    }
                }
            }

            //  اگر falseAllocation وجود دارد، تراکنش‌های مربوطه را وارد کن
            if (falseAllocations.Count > 0)
            {
                DateTime minAlloDate = DateTime.MaxValue;
                foreach (AssetAllocation fa in falseAllocations)
                {
                    DateTime d = fa.AssetTransaction.AssetTransactionCreateDate;
                    if (d < minAlloDate) minAlloDate = d;
                }

                List<Domain.Entities.AssetTransaction> relatedTransactions = await _assetTransactionRepository.Query().Include(x => x.Allocations).Where(x => x.AssetTransactionCreateDate >= minAlloDate && x.UniqueId == targetUniqueId && x.WarehouseId == targetWarehouseId).ToListAsync();

                if (relatedTransactions.Count > 0)
                {
                    foreach (Domain.Entities.AssetTransaction? tx in relatedTransactions) Track(tx);
                }
            }

            var orderedTransactions = workingById.Values.OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).ToList();

            var orderedTransactionIds = new HashSet<long>(orderedTransactions.Count);
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions) orderedTransactionIds.Add(tx.Id);

            // جمع‌آوری همه Allocationهای حذف‌شدنی
            var allocationIdsToDelete = new HashSet<long>();
            var allAllocationsToDelete = new List<AssetAllocation>(falseAllocations.Count);

            // حذف false allocationها
            foreach (AssetAllocation? alloc in falseAllocations)
            {
                if (alloc is null) continue;
                if (allocationIdsToDelete.Add(alloc.Id)) allAllocationsToDelete.Add(alloc);
            }

            // سپس Allocationهای تراکنش‌ها
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions)
            {
                ICollection<AssetAllocation>? allocs = tx.Allocations;
                if (allocs is null) continue;

                foreach (AssetAllocation? alloc in allocs)
                {
                    if (alloc is null) continue;
                    if (allocationIdsToDelete.Add(alloc.Id)) allAllocationsToDelete.Add(alloc);
                }
            }

            if (allAllocationsToDelete.Count > 0)
            {
                // قطع فارنکی برای Exitها
                foreach (AssetAllocation alloc in allAllocationsToDelete)
                {
                    if (alloc is AssetExit exit)
                    {
                        exit.AssetAllocationId = null;
                        exit.AssetAllocation = null;
                    }
                }

                // مرتب‌سازی  Exitها قبل از Entryها
                allAllocationsToDelete.Sort((a, b) =>
                {
                    int ak = a is AssetExit ? 0 : 1;
                    int bk = b is AssetExit ? 0 : 1;
                    return ak.CompareTo(bk);
                });

                await _assetAllocationRepository.DeleteRange(allAllocationsToDelete);
            }

            //  Reset تراکنش‌ها
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions)
            {
                tx.Allocations?.Clear();
                tx.Status = AssetTransactionStatus.UnTouched;
            }

            // رفع Block
            var stateKey = new AllocationStateKey(targetUniqueId, targetWarehouseId);
            if (await _allocationStateStore.IsBlock(stateKey)) await _allocationStateStore.Unblock(stateKey);

            //   آخرین Snapshot معتبر قبل از rebuild
            AssetAllocation? lastValidSnapshot = await _assetAllocationRepository.GetLatestSnapshotBeforeDateAsync(targetUniqueId, targetWarehouseId, earliestDate);

            if (lastValidSnapshot is not null && orderedTransactionIds.Contains(lastValidSnapshot.AssetTransactionId))
            {
                lastValidSnapshot = null;
            }

            //  اگر Allocation موجود جزو تراکنش‌های rebuild بود، لیست را null کن
            if (availableAllocations != null && availableAllocations.Count > 0)
            {
                bool conflict = false;
                foreach (AssetEntry a in availableAllocations)
                {
                    if (orderedTransactionIds.Contains(a.AssetTransactionId))
                    {
                        conflict = true;
                        break;
                    }
                }
                if (conflict) availableAllocations = null;
            }

            //  ساخت Context
            var context = new AllocationWorkContext(orderedTransactions, availableAllocations, lastValidSnapshot);

            //  پردازش In-Memory
            bool processSucceeded = true;
            const int commitBatch = 5_000;
            int processed = 0;

            foreach (Domain.Entities.AssetTransaction? item in orderedTransactions)
            {
                if (await _allocationStateStore.IsBlock(stateKey))
                {
                    processSucceeded = false;
                    break;
                }

                bool result = await _assetTransactionProcessService.ProcessAsyncInMemory(item, context);

                if (!result)
                {
                    await _unitOfWork.SaveChangesAsync();
                    processSucceeded = false;
                    break;
                }

                //اگر به بچ رسید سیوش کن
                if (++processed % commitBatch == 0) await _unitOfWork.SaveChangesAsync();

            }

            //   Save نهایی
            if (processSucceeded && orderedTransactions.All(x => x.Status == AssetTransactionStatus.Committed)) await _unitOfWork.SaveChangesAsync();

        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(ProcessGroupInMemory));
        }
        finally
        {
            _registry.Unregister(key);
        }
    }


    public async Task ProcessGroup_(List<Domain.Entities.AssetTransaction> transactions, long? targetUniqueId = null, int? targetWarehouseId = null)
    {
        try
        {
            foreach (Domain.Entities.AssetTransaction? item in transactions)
            {
                bool result = await _assetTransactionProcessService.ProcessAsync(item);

                if (result)
                {
                    await _unitOfWork.SaveChangesAsync();
                }
                else
                {
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(ProcessGroupInMemory));
        }
    }


    public async Task ProcessGroupWituOutRebuildInMemory(List<Domain.Entities.AssetTransaction> transactions, long? uniqueId = null, int? warehouseId = null)
    {
        if (transactions == null || transactions.Count == 0) return;

        var key = new GroupKey(uniqueId, warehouseId);

        // Sort فقط یک بار - با List.Sort درجا یا ساخت لیست جدید (بدون تغییر روی ورودی)
        var sorted = transactions.OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).ToList();

        Domain.Entities.AssetTransaction first = sorted[0];
        long targetUniqueId = Convert.ToInt64(first.UniqueId);
        int targetWarehouseId = first.WarehouseId;

        try
        {
            // Trackers 
            var workingById = new Dictionary<long, Domain.Entities.AssetTransaction>(sorted.Count * 2);

            var falseAllocationIds = new HashSet<long>();
            var falseAllocationSeenIds = new HashSet<long>();
            var falseAllocations = new List<AssetAllocation>();

            var resetTransactionIds = new HashSet<long>();

            // local helpers - فقط capture، بدون allocation اضافه
            void Track(Domain.Entities.AssetTransaction tx)
            {
                if (tx is null) return;
                workingById[tx.Id] = tx;
            }

            //  تراکنش‌های ورودی
            foreach (Domain.Entities.AssetTransaction? tx in sorted) Track(tx);

            // get younger transactions from  db
            List<Domain.Entities.AssetTransaction>? youngerTransactions = await _assetTransactionRepository.GetYoungerDataAsync(targetUniqueId, targetWarehouseId, first.AssetTransactionCreateDate);

            if (youngerTransactions != null && youngerTransactions.Count > 0)
            {
                foreach (Domain.Entities.AssetTransaction tx in youngerTransactions)
                {
                    ICollection<AssetAllocation> allocs = tx.Allocations;
                    if (allocs != null)
                    {
                        foreach (AssetAllocation alloc in allocs)
                        {
                            if (alloc.Status == AssetAllocationStatus.Committed) return;

                            if (falseAllocationIds.Add(alloc.Id))
                            {
                                falseAllocations.Add(alloc);
                                falseAllocationSeenIds.Add(alloc.Id);
                            }
                        }
                    }

                    resetTransactionIds.Add(tx.Id);
                    Track(tx);
                }
            }

            //   قدیمی‌ترین تاریخ برای rebuild
            // (چون لیست sort شده، همان first است)
            DateTime earliestDate = first.AssetTransactionCreateDate;

            //  Available allocations
            List<AssetEntry>? availableAllocations = await _assetAllocationRepository.GetAvailableAssetAllocationAsync(targetUniqueId, targetWarehouseId, CancellationToken.None) ?? new List<AssetEntry>();

            if (availableAllocations.Count > 0)
            {
                availableAllocations.RemoveAll(x => falseAllocationIds.Contains(x.Id) || resetTransactionIds.Contains(x.AssetTransactionId));
            }

            //  Invalid allocations
            List<AssetExit> invalidAllos = await _assetAllocationRepository.GetYoungInvalidTransactionsAsync(targetUniqueId, targetWarehouseId, earliestDate);

            if (invalidAllos != null && invalidAllos.Count > 0)
            {
                foreach (AssetExit? invalid in invalidAllos)
                {
                    if (invalid is null) continue;

                    if (falseAllocationSeenIds.Add(invalid.Id))
                    {
                        falseAllocations.Add(invalid);
                    }

                    AssetAllocation? parent = invalid.AssetAllocation;
                    if (parent != null && falseAllocationSeenIds.Add(parent.Id))
                    {
                        falseAllocations.Add(parent);
                    }
                }
            }

            //  اگر falseAllocation وجود دارد، تراکنش‌های مربوطه را وارد کن
            if (falseAllocations.Count > 0)
            {
                DateTime minAlloDate = DateTime.MaxValue;
                foreach (AssetAllocation fa in falseAllocations)
                {
                    DateTime d = fa.AssetTransaction.AssetTransactionCreateDate;
                    if (d < minAlloDate) minAlloDate = d;
                }

                List<Domain.Entities.AssetTransaction> relatedTransactions = await _assetTransactionRepository.Query().Include(x => x.Allocations).Where(x => x.AssetTransactionCreateDate >= minAlloDate && x.UniqueId == targetUniqueId && x.WarehouseId == targetWarehouseId).ToListAsync();

                if (relatedTransactions.Count > 0)
                {
                    foreach (Domain.Entities.AssetTransaction? tx in relatedTransactions) Track(tx);
                }
            }

            var orderedTransactions = workingById.Values.OrderBy(x => x.AssetTransactionCreateDate).ThenBy(x => x.Id).ToList();

            var orderedTransactionIds = new HashSet<long>(orderedTransactions.Count);
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions) orderedTransactionIds.Add(tx.Id);

            // جمع‌آوری همه Allocationهای حذف‌شدنی
            var allocationIdsToDelete = new HashSet<long>();
            var allAllocationsToDelete = new List<AssetAllocation>(falseAllocations.Count);

            // حذف false allocationها
            foreach (AssetAllocation? alloc in falseAllocations)
            {
                if (alloc is null) continue;
                if (allocationIdsToDelete.Add(alloc.Id)) allAllocationsToDelete.Add(alloc);
            }

            // سپس Allocationهای تراکنش‌ها
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions)
            {
                ICollection<AssetAllocation>? allocs = tx.Allocations;
                if (allocs is null) continue;

                foreach (AssetAllocation? alloc in allocs)
                {
                    if (alloc is null) continue;
                    if (allocationIdsToDelete.Add(alloc.Id)) allAllocationsToDelete.Add(alloc);
                }
            }

            if (allAllocationsToDelete.Count > 0)
            {
                // قطع فارنکی برای Exitها
                foreach (AssetAllocation alloc in allAllocationsToDelete)
                {
                    if (alloc is AssetExit exit)
                    {
                        exit.AssetAllocationId = null;
                        exit.AssetAllocation = null;
                    }
                }

                // مرتب‌سازی  Exitها قبل از Entryها
                allAllocationsToDelete.Sort((a, b) =>
                {
                    int ak = a is AssetExit ? 0 : 1;
                    int bk = b is AssetExit ? 0 : 1;
                    return ak.CompareTo(bk);
                });

                await _assetAllocationRepository.DeleteRange(allAllocationsToDelete);
            }

            //  Reset تراکنش‌ها
            foreach (Domain.Entities.AssetTransaction? tx in orderedTransactions)
            {
                tx.Allocations?.Clear();
                tx.Status = AssetTransactionStatus.UnTouched;
            }

            // رفع Block
            var stateKey = new AllocationStateKey(targetUniqueId, targetWarehouseId);
            if (await _allocationStateStore.IsBlock(stateKey)) await _allocationStateStore.Unblock(stateKey);

            //   آخرین Snapshot معتبر قبل از rebuild
            AssetAllocation? lastValidSnapshot = await _assetAllocationRepository.GetLatestSnapshotBeforeDateAsync(targetUniqueId, targetWarehouseId, earliestDate);

            if (lastValidSnapshot is not null && orderedTransactionIds.Contains(lastValidSnapshot.AssetTransactionId))
            {
                lastValidSnapshot = null;
            }

            //  اگر Allocation موجود جزو تراکنش‌های rebuild بود، لیست را null کن
            if (availableAllocations != null && availableAllocations.Count > 0)
            {
                bool conflict = false;
                foreach (AssetEntry a in availableAllocations)
                {
                    if (orderedTransactionIds.Contains(a.AssetTransactionId))
                    {
                        conflict = true;
                        break;
                    }
                }
                if (conflict) availableAllocations = null;
            }

            //  ساخت Context
            var context = new AllocationWorkContext(orderedTransactions, availableAllocations, lastValidSnapshot);

            //  پردازش In-Memory
            bool processSucceeded = true;
            const int commitBatch = 5_000;
            int processed = 0;

            foreach (Domain.Entities.AssetTransaction? item in orderedTransactions)
            {
                if (await _allocationStateStore.IsBlock(stateKey))
                {
                    processSucceeded = false;
                    break;
                }

                bool result = await _assetTransactionProcessService.ProcessAsyncInMemory(item, context);

                if (!result)
                {
                    await _unitOfWork.SaveChangesAsync();
                    processSucceeded = false;
                    break;
                }

                //اگر به بچ رسید سیوش کن
                if (++processed % commitBatch == 0) await _unitOfWork.SaveChangesAsync();

            }

            //   Save نهایی
            if (processSucceeded && orderedTransactions.All(x => x.Status == AssetTransactionStatus.Committed)) await _unitOfWork.SaveChangesAsync();

        }
        catch (Exception ex)
        {
            await _log.LogIt(ex, nameof(ProcessGroupInMemory));
        }
        finally
        {
            _registry.Unregister(key);
        }
    }

    public async Task<bool> ReBuildAndAllocate(Domain.Entities.AssetTransaction transaction)
    {

        if (transaction == null || transaction.Id == 0) return false;

        long uniqueId = Convert.ToInt64(transaction.UniqueId);
        int warehouseId = transaction.WarehouseId;
        int symbolId = transaction.SymbolId;


        Domain.Entities.AssetTransaction oldestTransaction = transaction;
        List<Domain.Entities.AssetTransaction>? youngerAssetTransactions = await _assetTransactionRepository.GetYoungerDataAsync2(Convert.ToInt64(oldestTransaction.UniqueId), oldestTransaction.WarehouseId, oldestTransaction.SymbolId, oldestTransaction.AssetTransactionCreateDate);
        if (youngerAssetTransactions != null && youngerAssetTransactions?.Count > 0)
        {
            bool isAnyCommitted = youngerAssetTransactions
                .SelectMany(x => x.Allocations)
                .Any(x => x.Status == AssetAllocationStatus.Committed);
            if (isAnyCommitted) return false;

            youngerAssetTransactions.Insert(0, transaction);
            await _assetTransactionRepository.RemoveFalseAllocatedData(youngerAssetTransactions);
            youngerAssetTransactions.ForEach(x => x.Status = AssetTransactionStatus.UnTouched);
            await _allocationStateStore.Unblock(new AllocationStateKey(uniqueId, warehouseId));
        }
        else
        {
            youngerAssetTransactions = new List<Domain.Entities.AssetTransaction> { transaction };
        }

        if (youngerAssetTransactions.Count == 1 && await _allocationStateStore.IsBlock(new AllocationStateKey(uniqueId, warehouseId)))
            if (await _allocationStateStore.IsBlock(new AllocationStateKey(uniqueId, warehouseId))) await _allocationStateStore.Unblock(new AllocationStateKey(uniqueId, warehouseId));

        foreach (Domain.Entities.AssetTransaction item in youngerAssetTransactions)
        {
            if (await _allocationStateStore.IsBlock(new AllocationStateKey(
                Convert.ToInt64(item.UniqueId),
                item.WarehouseId)))
            {
                continue;
            }

            bool resProcess = await _assetTransactionProcessService.ProcessAsync(item);
            if (resProcess)
            {
                await _unitOfWork.SaveChangesAsync();
            }
            else
            {
                return false;

            }
        }
        return true;

    }

}




public readonly record struct GroupKey(long? UniqueId, int? WarehouseId)
{
    public override string ToString() => $"{UniqueId}:{WarehouseId}";
}

public interface IGroupJobRegistry
{
    /// <summary>
    /// اگر گروه قبلاً ثبت نشده باشد true برمی‌گرداند و آن را ثبت می‌کند.
    /// (یعنی اجازه ساخت/اجرای جاب برای این گروه داده می‌شود)
    /// </summary>
    bool TryRegister(GroupKey key);

    /// <summary>
    /// بعد از اتمام/شکست جاب، گروه آزاد می‌شود تا دوباره بتوان برایش جاب ساخت    .
    /// </summary>
    void Unregister(GroupKey key);
}

public class InMemoryGroupJobRegistry : IGroupJobRegistry
{
    // کلیدهایی که الان در صف/در حال پردازش هستند
    private readonly ConcurrentDictionary<GroupKey, byte> _inFlight = new();

    public bool TryRegister(GroupKey key) => _inFlight.TryAdd(key, 0);

    public void Unregister(GroupKey key) => _inFlight.TryRemove(key, out _);
}


public sealed class AllocationWorkContext
{
    public List<Domain.Entities.AssetTransaction>? Transactions { get; }

    public List<AssetEntry>? AvailableAllocations { get; set; }

    public AssetAllocation? LastSnapshot { get; private set; }

    public AllocationWorkContext(List<Domain.Entities.AssetTransaction>? transactions, IEnumerable<AssetEntry>? availableAllocations, AssetAllocation? lastSnapshot)
    {
        Transactions = transactions;
        AvailableAllocations = availableAllocations is null ? null : availableAllocations.OrderBy(x => x.CreateDate).ThenBy(x => x.Id).ToList();

        LastSnapshot = lastSnapshot;
    }

    public bool HasConflict => LastSnapshot?.HasConflict == true;

    public decimal AvailableQuantity => LastSnapshot?.AvailableQuantity ?? 0;

    public bool HasOlderUntouchedTransactions(Domain.Entities.AssetTransaction currentTransaction)
    {
        return Transactions.Any(x => x.Id != currentTransaction.Id && x.AssetTransactionCreateDate < currentTransaction.AssetTransactionCreateDate && x.Status == AssetTransactionStatus.UnTouched);
    }

    public void AddEntry(AssetEntry entry)
    {
        if (AvailableAllocations is null) AvailableAllocations = [];
        AvailableAllocations.Add(entry);
        LastSnapshot = entry;
    }

    public void AddExit(AssetExit exit)
    {
        LastSnapshot = exit;
    }

    public void ResolveLastSnapshotConflict()
    {
        if (LastSnapshot != null) LastSnapshot.HasConflict = false;
    }
}
