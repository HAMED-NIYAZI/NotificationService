﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Newtonsoft.Json;

namespace AssetFlow.Application.Common.Services
{
    public class SellAllocatorService : IAssetTransactionAllocatorService
    {
        private readonly IAssetAllocationRepository _assetAllocationRepository;
        private readonly IAssetTransactionRepository _assetTransactionRepository;
        private readonly IAssetLogRepository _log;
        private readonly IAllocationStateStore _allocationStateStore;


        public AssetTransactionType Type => AssetTransactionType.Sell;

        public SellAllocatorService(IAllocationStateStore allocationStateStore, IAssetAllocationRepository assetAllocationRepository, IAssetTransactionRepository assetTransactionRepository, IAssetLogRepository logRepository)
        {
            _assetAllocationRepository = assetAllocationRepository;
            _assetTransactionRepository = assetTransactionRepository;
            _log = logRepository;
            _allocationStateStore = allocationStateStore;
        }
        public async Task<bool> AllocateAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {

            var allocationBlockKey = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);
            //Sell
            try
            {

                decimal sellQuantity = assetTransaction.Quantity;

                List<AssetEntry>? availableAllocations = await _assetAllocationRepository.GetAvailableAssetAllocationAsync(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, cancellationToken);
                decimal totalAvailableQuantity = availableAllocations?.Sum(x => x.RemainingQuantity) ?? 0;


                AssetAllocation? lastSnapshot = await _assetAllocationRepository.GetLatestSnapshot(new AssetExit
                {
                    SymbolId = assetTransaction.SymbolId,
                    UniqueId = assetTransaction.UniqueId,
                    WarehouseId = assetTransaction.WarehouseId
                });


                var anyAvailableAllocationsHasConflict = lastSnapshot?.HasConflict == true;

                if (availableAllocations is null || availableAllocations.Count == 0 || totalAvailableQuantity < sellQuantity || anyAvailableAllocationsHasConflict)
                {
                    if (!anyAvailableAllocationsHasConflict)
                    {
                        await _assetAllocationRepository.UpdateLatestSnapshotToHasConflict(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, assetTransaction.SymbolId);
                        await _log.LogIt(new AssetLog { Request = $"totalAvailableQuantity < sellQuantity  ----- {totalAvailableQuantity} < {sellQuantity}   , assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "در زمان فروش از مارکت . مقدار موجودی از مقدار خروجی کمتر است و مانده منفی میشود" });
                    }
                    await _allocationStateStore.BlockAsync(allocationBlockKey);
                    return false;
                }

                decimal remainingSellQuantity = sellQuantity;




                foreach (AssetEntry sourceAllocation in availableAllocations)
                {
                    if (remainingSellQuantity <= 0)
                    {
                        break;
                    }

                    decimal consumedQuantity = Math.Min(sourceAllocation.RemainingQuantity, remainingSellQuantity);
                    sourceAllocation.RemainingQuantity -= consumedQuantity;

                    AssetExit sellAllocation = new()
                    {
                        WarehouseId = assetTransaction.WarehouseId,
                        SymbolId = assetTransaction.SymbolId,
                        UniqueId = assetTransaction.UniqueId,
                        Quantity = sellQuantity,
                        AllocatedQuantity = consumedQuantity,
                        AssetTransactionId = assetTransaction.Id,
                        AssetSourceType = sourceAllocation.AssetSourceType,
                        TradeId = assetTransaction.TradeId,
                        Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {sourceAllocation.Id}",
                        AssetAllocation = sourceAllocation
                    };


                    remainingSellQuantity -= consumedQuantity;
                    decimal previousAvailableQuantity = lastSnapshot == null ? 0 : lastSnapshot.AvailableQuantity;
                    decimal newAvailableQuantity = previousAvailableQuantity - consumedQuantity;
                    if (newAvailableQuantity < 0)
                    {
                        await _log.LogIt(new AssetLog { Request = $"newAvailableQuantity < 0  ----- {newAvailableQuantity} < 0   , assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "در زمان فروش از مارکت . مقدار موجودی از مقدار خروجی کمتر است و مانده منفی میشود" });
                        await _allocationStateStore.BlockAsync(allocationBlockKey);

                        return false;
                    }

                    sellAllocation.AvailableQuantity = newAvailableQuantity;

                    await _assetAllocationRepository.Save(sellAllocation);
                    lastSnapshot = sellAllocation;

                }

                //برای حالت هایی که مقدار منفی شده و الوکیشن هم پایان یافته و مقدار باقیمانده منفی باید در دیتا بیس بخورد
                if (remainingSellQuantity > 0)
                {
                    if (availableAllocations is null || availableAllocations.Count == 0)
                    {

                        AssetExit sellAllocation = new()
                        {
                            WarehouseId = assetTransaction.WarehouseId,
                            SymbolId = assetTransaction.SymbolId,
                            UniqueId = assetTransaction.UniqueId,
                            Quantity = sellQuantity,
                            AllocatedQuantity = remainingSellQuantity,
                            AssetTransactionId = assetTransaction.Id,
                            AssetSourceType = AssetSourceType.WarehouseEntry,//از حالت منفی استفاده شده و تامین شده
                            TradeId = assetTransaction.TradeId,
                            Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {-1}",
                            AssetAllocation = null
                        };

                        sellAllocation.AvailableQuantity = lastSnapshot is null ? -remainingSellQuantity : lastSnapshot.AvailableQuantity + -remainingSellQuantity;

                        await _assetAllocationRepository.Save(sellAllocation);
                    }
                    else
                    {
                        AssetExit sellAllocation = new()
                        {
                            WarehouseId = assetTransaction.WarehouseId,
                            SymbolId = assetTransaction.SymbolId,
                            UniqueId = assetTransaction.UniqueId,
                            Quantity = sellQuantity,
                            AllocatedQuantity = remainingSellQuantity,
                            AssetTransactionId = assetTransaction.Id,
                            AssetSourceType = AssetSourceType.WarehouseEntry,
                            TradeId = assetTransaction.TradeId,
                            Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {-1}",
                            AssetAllocation = null
                        };

                        sellAllocation.AvailableQuantity = lastSnapshot is null ? -remainingSellQuantity : lastSnapshot.AvailableQuantity + -remainingSellQuantity;

                        await _assetAllocationRepository.Save(sellAllocation);
                    }
                }

                assetTransaction.Status = AssetTransactionStatus.Committed;
                await _assetTransactionRepository.UpdateStatusAsync(assetTransaction);
                await _allocationStateStore.Unblock(allocationBlockKey);

                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(allocationBlockKey);
                await _log.LogIt(ex, nameof(SellAllocatorService), assetTransaction);
                return false;
            }
        }

        public async Task<bool> AllocateAsync_(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {

             //Sell
            try
            {

                decimal sellQuantity = assetTransaction.Quantity;

                List<AssetEntry>? availableAllocations = await _assetAllocationRepository.GetAvailableAssetAllocationAsync(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, cancellationToken);
                decimal totalAvailableQuantity = availableAllocations?.Sum(x => x.RemainingQuantity) ?? 0;


                AssetAllocation? lastSnapshot = await _assetAllocationRepository.GetLatestSnapshot(new AssetExit
                {
                    SymbolId = assetTransaction.SymbolId,
                    UniqueId = assetTransaction.UniqueId,
                    WarehouseId = assetTransaction.WarehouseId
                });



                decimal remainingSellQuantity = sellQuantity;




                foreach (AssetEntry sourceAllocation in availableAllocations)
                {
                    if (remainingSellQuantity <= 0)
                    {
                        break;
                    }

                    decimal consumedQuantity = Math.Min(sourceAllocation.RemainingQuantity, remainingSellQuantity);
                    sourceAllocation.RemainingQuantity -= consumedQuantity;

                    AssetExit sellAllocation = new()
                    {
                        WarehouseId = assetTransaction.WarehouseId,
                        SymbolId = assetTransaction.SymbolId,
                        UniqueId = assetTransaction.UniqueId,
                        Quantity = sellQuantity,
                        AllocatedQuantity = consumedQuantity,
                        AssetTransactionId = assetTransaction.Id,
                        AssetSourceType = sourceAllocation.AssetSourceType,
                        TradeId = assetTransaction.TradeId,
                        Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {sourceAllocation.Id}",
                        AssetAllocation = sourceAllocation
                    };


                    remainingSellQuantity -= consumedQuantity;
                    decimal previousAvailableQuantity = lastSnapshot == null ? 0 : lastSnapshot.AvailableQuantity;
                    decimal newAvailableQuantity = previousAvailableQuantity - consumedQuantity;
                    if (newAvailableQuantity < 0)
                    {
                        await _log.LogIt(new AssetLog { Request = $"newAvailableQuantity < 0  ----- {newAvailableQuantity} < 0   , assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "در زمان فروش از مارکت . مقدار موجودی از مقدار خروجی کمتر است و مانده منفی میشود" });
 
                        return false;
                    }

                    sellAllocation.AvailableQuantity = newAvailableQuantity;

                    await _assetAllocationRepository.Save(sellAllocation);
                    lastSnapshot = sellAllocation;

                }

                //برای حالت هایی که مقدار منفی شده و الوکیشن هم پایان یافته و مقدار باقیمانده منفی باید در دیتا بیس بخورد
                if (remainingSellQuantity > 0)
                {
                    if (availableAllocations is null || availableAllocations.Count == 0)
                    {

                        AssetExit sellAllocation = new()
                        {
                            WarehouseId = assetTransaction.WarehouseId,
                            SymbolId = assetTransaction.SymbolId,
                            UniqueId = assetTransaction.UniqueId,
                            Quantity = sellQuantity,
                            AllocatedQuantity = remainingSellQuantity,
                            AssetTransactionId = assetTransaction.Id,
                            AssetSourceType = AssetSourceType.WarehouseEntry,//از حالت منفی استفاده شده و تامین شده
                            TradeId = assetTransaction.TradeId,
                            Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {-1}",
                            AssetAllocation = null
                        };

                        sellAllocation.AvailableQuantity = lastSnapshot is null ? -remainingSellQuantity : lastSnapshot.AvailableQuantity + -remainingSellQuantity;

                        await _assetAllocationRepository.Save(sellAllocation);
                    }
                    else
                    {
                        AssetExit sellAllocation = new()
                        {
                            WarehouseId = assetTransaction.WarehouseId,
                            SymbolId = assetTransaction.SymbolId,
                            UniqueId = assetTransaction.UniqueId,
                            Quantity = sellQuantity,
                            AllocatedQuantity = remainingSellQuantity,
                            AssetTransactionId = assetTransaction.Id,
                            AssetSourceType = AssetSourceType.WarehouseEntry,
                            TradeId = assetTransaction.TradeId,
                            Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {-1}",
                            AssetAllocation = null
                        };

                        sellAllocation.AvailableQuantity = lastSnapshot is null ? -remainingSellQuantity : lastSnapshot.AvailableQuantity + -remainingSellQuantity;

                        await _assetAllocationRepository.Save(sellAllocation);
                    }
                }

                assetTransaction.Status = AssetTransactionStatus.Committed;
 
                return true;
            }
            catch (Exception ex)
            {
                 await _log.LogIt(ex, nameof(SellAllocatorService), assetTransaction);
                return false;
            }
        }

        public async Task<bool> AllocateInMemoryAsync(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context)
        {
            var key = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);
            try
            {
                decimal sellQuantity = assetTransaction.Quantity;
                if (context.AvailableAllocations.Count == 0 || context.AvailableAllocations.Where(x => x.RemainingQuantity > 0).Sum(x => x.RemainingQuantity) < sellQuantity || context.HasConflict)
                {
                    if (!context.HasConflict && context.LastSnapshot != null)
                    {
                        context.LastSnapshot.HasConflict = true;
                    }
                    await _allocationStateStore.BlockAsync(key);
                    return false;
                }

                decimal remainingSellQuantity = sellQuantity;
                var availableEntries = context.AvailableAllocations.Where(x => x.RemainingQuantity > 0).ToList();

                foreach (var sourceAllocation in availableEntries)
                {
                    if (remainingSellQuantity <= 0) break;
                    decimal consumedQuantity = Math.Min(sourceAllocation.RemainingQuantity, remainingSellQuantity);
                    sourceAllocation.RemainingQuantity -= consumedQuantity;
                    decimal previousAvailableQuantity = context.LastSnapshot?.AvailableQuantity ?? 0;
                    decimal newAvailableQuantity = previousAvailableQuantity - consumedQuantity;

                    if (newAvailableQuantity < 0)
                    {
                        if (context.LastSnapshot != null)
                        {
                            context.LastSnapshot.HasConflict = true;
                        }
                        await _allocationStateStore.BlockAsync(key);
                        return false;
                    }

                    var sellAllocation = new AssetExit
                    {
                        WarehouseId = assetTransaction.WarehouseId,
                        SymbolId = assetTransaction.SymbolId,
                        UniqueId = assetTransaction.UniqueId,
                        Quantity = sellQuantity,
                        AllocatedQuantity = consumedQuantity,
                        AvailableQuantity = newAvailableQuantity,
                        AssetTransactionId = assetTransaction.Id,
                        AssetSourceType = sourceAllocation.AssetSourceType,
                        TradeId = assetTransaction.TradeId,
                        Description = $"فروش از مارکت - مصرف موجودی FIFO از AllocationId: {sourceAllocation.Id}",
                        AssetAllocation = sourceAllocation
                    };

                    remainingSellQuantity -= consumedQuantity;
                    await _assetAllocationRepository.Save(sellAllocation);
                    context.AddExit(sellAllocation);
                }

                if (remainingSellQuantity > 0)
                {
                    decimal previousAvailableQuantity = context.LastSnapshot?.AvailableQuantity ?? 0;
                    var negativeExit = new AssetExit
                    {
                        WarehouseId = assetTransaction.WarehouseId,
                        SymbolId = assetTransaction.SymbolId,
                        UniqueId = assetTransaction.UniqueId,
                        Quantity = sellQuantity,
                        AllocatedQuantity = remainingSellQuantity,
                        AvailableQuantity = previousAvailableQuantity - remainingSellQuantity,
                        AssetTransactionId = assetTransaction.Id,
                        AssetSourceType = AssetSourceType.WarehouseEntry,
                        TradeId = assetTransaction.TradeId,
                        Description = "فروش از مارکت - حالت کسری موجودی",
                        AssetAllocation = null
                    };
                    await _assetAllocationRepository.Save(negativeExit);
                    context.AddExit(negativeExit);
                }

                assetTransaction.Status = AssetTransactionStatus.Committed;
                await _allocationStateStore.Unblock(key);
                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(key);
                await _log.LogIt(ex, nameof(SellAllocatorService), assetTransaction);
                return false;
            }
        }
    }
}
