﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Newtonsoft.Json;

namespace AssetFlow.Application.Common.Services
{


    public class EntryAllocatorService : IAssetTransactionAllocatorService
    {
        private readonly IAssetAllocationRepository _assetAllocationRepository;
        private readonly IAssetTransactionRepository _assetTransactionRepository;
        private readonly IAssetLogRepository _log;
        private readonly IAllocationStateStore _allocationStateStore;



        public EntryAllocatorService(IAllocationStateStore allocationStateStore, IAssetAllocationRepository assetAllocationRepository,
             IAssetTransactionRepository assetTransactionRepository,
            IAssetLogRepository logRepository)
        {
            _assetAllocationRepository = assetAllocationRepository;
            _assetTransactionRepository = assetTransactionRepository;
            _log = logRepository;
            _allocationStateStore = allocationStateStore;
        }
        public AssetTransactionType Type => AssetTransactionType.Entry;

        public async Task<bool> AllocateAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {
            var allocationBlockKey = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);

            //Entry
            try
            {
                AssetEntry newAssetAllocation = new()
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.WarehouseEntry,
                    Description = "ورود دارایی به مارکت - افزایش موجودی از منشا قبض انبار",
                    SymbolId = assetTransaction.SymbolId,
                    EntranceId = assetTransaction.EntranceId
                };
                AssetAllocation lastSnapshot = await _assetAllocationRepository.GetLatestSnapshot(newAssetAllocation);


                var anyAvailableAllocationsHasConflict = !(lastSnapshot is null) && lastSnapshot.HasConflict;

                var hasYoungerUntouchedAssetTransactions = await _assetTransactionRepository.AnyAsync(x =>
                    x.AssetTransactionCreateDate < assetTransaction.AssetTransactionCreateDate &&
                    x.Status == AssetTransactionStatus.UnTouched);
                if (!hasYoungerUntouchedAssetTransactions && lastSnapshot?.Id > 0)
                {
                    await _assetAllocationRepository.ResolveLatestSnapshotToHasConflict(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, assetTransaction.SymbolId);
                }
                else if ((lastSnapshot is not null && lastSnapshot.Id > 0 && lastSnapshot.AvailableQuantity < 0) || anyAvailableAllocationsHasConflict)
                {
                    if (!anyAvailableAllocationsHasConflict)
                    {
                        await _assetAllocationRepository.UpdateLatestSnapshotToHasConflict(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, assetTransaction.SymbolId);
                        await _log.LogIt(new AssetLog { Request = $"lastAssetBalanceSnapshot is -minus  lastAssetBalanceSnapshot= {JsonConvert.SerializeObject(lastSnapshot)}, lastAssetBalanceSnapshot.AvailableQuantity= {lastSnapshot.AvailableQuantity} assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "در زمان ورود دارایی به مارکت - افزایش موجودی از منشا قبض انبار . مقدار اخرین موجودی منفی است" });
                    }
                    await _allocationStateStore.BlockAsync(allocationBlockKey);

                    return false;
                }

                newAssetAllocation.AvailableQuantity = assetTransaction.Quantity + (lastSnapshot?.AvailableQuantity ?? 0);

                await _assetAllocationRepository.Save(newAssetAllocation);

                assetTransaction.Status = AssetTransactionStatus.Committed;
               // await _assetTransactionRepository.UpdateStatusAsync(assetTransaction);
                await _allocationStateStore.Unblock(allocationBlockKey);
                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(allocationBlockKey);

                await _log.LogIt(ex, nameof(EntryAllocatorService), assetTransaction);
                return false;
            }
        }
        public async Task<bool> AllocateAsync_(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {
            var allocationBlockKey = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);

            //Entry
            try
            {
                AssetEntry newAssetAllocation = new()
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.WarehouseEntry,
                    Description = "ورود دارایی به مارکت - افزایش موجودی از منشا قبض انبار",
                    SymbolId = assetTransaction.SymbolId,
                    EntranceId = assetTransaction.EntranceId
                };
                AssetAllocation lastSnapshot = await _assetAllocationRepository.GetLatestSnapshot(newAssetAllocation);


 
                

                newAssetAllocation.AvailableQuantity = assetTransaction.Quantity + (lastSnapshot?.AvailableQuantity ?? 0);

                await _assetAllocationRepository.Save(newAssetAllocation);

                assetTransaction.Status = AssetTransactionStatus.Committed;
                 await _allocationStateStore.Unblock(allocationBlockKey);
                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(allocationBlockKey);

                await _log.LogIt(ex, nameof(EntryAllocatorService), assetTransaction);
                return false;
            }
        }

        public async Task<bool> AllocateInMemoryAsync(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context)
        {
            var key = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);

            try
            {
                var hasOlderUntouched = context.HasOlderUntouchedTransactions(assetTransaction);

                if (!hasOlderUntouched && context.LastSnapshot?.Id > 0)
                {
                    context.ResolveLastSnapshotConflict();
                }
                else if ((context.LastSnapshot?.Id > 0 && context.AvailableQuantity < 0) || context.HasConflict)
                {
                    if (!context.HasConflict)
                    {
                        context.LastSnapshot!.HasConflict = true;

                        await _log.LogIt(new AssetLog
                        {
                            Request = $"Entry blocked. " + $"Available={context.AvailableQuantity} " + $"Transaction={assetTransaction.Id}",
                            UniqueId = assetTransaction.UniqueId,
                            Description = "در زمان ورود دارایی، موجودی آخرین Snapshot منفی است."
                        });
                    }

                    await _allocationStateStore.BlockAsync(key);

                    return false;
                }

                var newAssetEntry = new AssetEntry
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    AvailableQuantity = assetTransaction.Quantity + context.AvailableQuantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.WarehouseEntry,
                    Description = "ورود دارایی به مارکت - افزایش موجودی از منشا قبض انبار",
                    SymbolId = assetTransaction.SymbolId,
                    EntranceId = assetTransaction.EntranceId
                };

                await _assetAllocationRepository.Save(newAssetEntry);
                context.AddEntry(newAssetEntry);

                assetTransaction.Status = AssetTransactionStatus.Committed;

                await _allocationStateStore.Unblock(key);

                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(key);
                await _log.LogIt(ex, nameof(EntryAllocatorService), assetTransaction);

                return false;
            }
        }
    }
}
