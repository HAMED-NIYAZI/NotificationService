﻿using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services;

public class WarehouseGroupTaxRule : IWarehouseGroupTaxRule
{
    private readonly IEnumerable<IRule> _taxRules;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IAssetLogRepository _log;
    private readonly IAssetProcessDetailRepository _assetProcessDetailRepository;
    private readonly IAssetProcessRepository _assetProcessRepository;

    public WarehouseGroupTaxRule(IAssetLogRepository log, IEnumerable<IRule> taxRules, IUnitOfWork unitOfWork, IAssetProcessRepository assetProcessRepository, IAssetProcessDetailRepository assetProcessDetailRepository)
    {
        _log = log;
        _taxRules = taxRules;
        _unitOfWork = unitOfWork;
        _assetProcessRepository = assetProcessRepository;
        _assetProcessDetailRepository = assetProcessDetailRepository;
    }

    public async Task<AssetProcess> SaveAssetProcessDetail(List<AssetExit> allocations)
    {
        AssetProcess process = new();
        if (allocations is not null && allocations.Count > 0)
        {

            List<AssetProcessDetail> details = new();

            var rule = _taxRules.First(x => x is WarehouseGroupClearanceTaxRule);

            foreach (AssetExit allocation in allocations)
            {
                var detail = await rule.GenerateAssetProcessDetail(allocation);
                details.Add(detail);
            }



            try
            {
                if (details is not null && details.Count > 0)
                {
                    process = await rule.GenerateAssetProcess(details);
                    details.ForEach(x => x.AssetProcess = process);

                    await _unitOfWork.BeginTransactionAsync();
                    await _assetProcessRepository.AddAsync(process);
                    await _assetProcessDetailRepository.AddRangeAsync(details);
                    await _unitOfWork.CommitAsync();
                }
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackAsync();
                _log.LogIt(ex);
                throw;
            }
        }
        return process;
    }

    public async Task<List<AssetProcess>?> SaveAssetProcessDetailForGetTaxSummaries(List<AssetExit> allocations)
    {
        List<AssetProcessDetail>? details = new();
        List<AssetProcess> process = [];

        var rule = _taxRules.First(x => x is WarehouseGroupSellTaxRule);

        foreach (AssetExit allocation in allocations)
        {
            if (await rule.IsIncludeRule(allocation))
            {
                var detail = await rule.GenerateAssetProcessDetail(allocation);
                details.Add(detail);
            }
        }

        if (details is not null && details.Count > 0)
        {
            process = await rule.GenerateAssetProcessList(details);
            details = await AssingedProccess(details, process);
            try
            {
                await _unitOfWork.BeginTransactionAsync();
                await _assetProcessRepository.AddRangeAsync(process);
                await _assetProcessDetailRepository.AddRangeAsync(details);
                await _unitOfWork.CommitAsync();
                return process;
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackAsync();
                _log.LogIt(ex);
                return null;
            }
        }
        else
        {
            return null;
        }
    }

    private async Task<List<AssetProcessDetail>> AssingedProccess(List<AssetProcessDetail> details, List<AssetProcess> process)
    {
        var processLookup = process.ToDictionary(x => new
        {
            x.WarehouseId,
            x.SymbolId,
            x.UniqueId
        });

        foreach (var detail in details)
        {
            var key = new
            {
                detail.WarehouseId,
                detail.SymbolId,
                detail.UniqueId
            };

            if (!processLookup.TryGetValue(key, out var relatedProcess))
            {
                //    throw new InvalidOperationException($"AssetProcess not found for WarehouseId={detail.WarehouseId}, SymbolId={detail.SymbolId}, UniqueId={detail.UniqueId}, UniqueIdIME={detail.UniqueIdIME}, UniqueId={detail.UniqueId}");
            }

            detail.AssetProcess = relatedProcess;
        }
        return details;
    }
}
