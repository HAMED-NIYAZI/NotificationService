﻿using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services;

public class WarehouseGroupSellTaxRule : IRule
{
    public string RuleName => "SellTaxRule";
    public AssetProcessDetailType RuleType => AssetProcessDetailType.Sell;
    public async Task<bool> IsIncludeRule(AssetExit allocation)
    {
        try
        {
            return allocation.AssetAllocation is not null && allocation.AssetTransaction.Type == AssetTransactionType.Sell && allocation.AssetAllocation.AssetSourceType == AssetSourceType.WarehouseEntry;
        }
        catch (Exception)
        {
            return false;
        }
    }
    public async Task<AssetProcessDetail> GenerateAssetProcessDetail(AssetExit allocation)
    {
        return new AssetProcessDetail()
        {
            AssetAllocationId = allocation.Id,
            AssetAllocation = allocation,
            UniqueId = allocation.UniqueId,
            WarehouseId = allocation.WarehouseId,
            SymbolId = allocation.SymbolId,
            ReferenceId = allocation.ReferenceId,
            Description = allocation.Description,
            Price = allocation.AssetTransaction.Price,
            Quantity = allocation.AllocatedQuantity,
            Status = AssetProcessDetailStatus.Draft,
            Type = RuleType,
            Included = await IsIncludeRule(allocation),
            RuleCode = RuleName
        };
    }
    public async Task<AssetProcess> GenerateAssetProcess(List<AssetProcessDetail> assetProcessDetails)
    {
        AssetProcess newAssetProcess = new();

        foreach (var assetProcessDetail in assetProcessDetails)
        {
            if (assetProcessDetail.Included)
            {
                newAssetProcess.Quantity += assetProcessDetail.Quantity;
                newAssetProcess.TotalPrice += assetProcessDetail.Quantity * assetProcessDetail.Price;
            }
        }
        newAssetProcess.AveragePrice = newAssetProcess.TotalPrice / newAssetProcess.Quantity;
        newAssetProcess.UniqueId = assetProcessDetails[0].UniqueId;
        newAssetProcess.WarehouseId = assetProcessDetails[0].WarehouseId;
        newAssetProcess.SymbolId = assetProcessDetails[0].SymbolId;
        newAssetProcess.Description = "Sell صدور اعلامیه";
        newAssetProcess.Status = AssetProcessDetailStatus.Draft;
        newAssetProcess.RuleCode = RuleName;
        newAssetProcess.Type = RuleType;
        newAssetProcess.ReferenceId = assetProcessDetails[0].ReferenceId;
        return newAssetProcess;
    }

    public async Task<List<AssetProcess>> GenerateAssetProcessList(List<AssetProcessDetail> assetProcessDetails)
    {
        var groups = assetProcessDetails.GroupBy(detail => new
        {
            detail.WarehouseId,
            detail.SymbolId,
            detail.UniqueId
        });

        List<AssetProcess> assetProcesses = new();

        foreach (var group in groups)
        {
            List<AssetProcessDetail> details = group.ToList();

            var assetProcess = await GenerateAssetProcess(details)
                ?? throw new InvalidOperationException(
                    $"AssetProcess could not be generated for " +
                    $"WarehouseId={group.Key.WarehouseId}, " +
                    $"SymbolId={group.Key.SymbolId}, " +
                    $"UniqueId={group.Key.UniqueId}, ");

            foreach (var detail in details)
            {
                detail.AssetProcess = assetProcess;
            }

            assetProcesses.Add(assetProcess);
        }

        return assetProcesses;
    }
}
