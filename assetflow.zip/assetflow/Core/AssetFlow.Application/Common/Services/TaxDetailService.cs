﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.TaxDetail.Dtos;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Dtos;
using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services
{
    public class TaxDetailService : ITaxDetailService
    {
        private readonly IAssetProcessRepository _assetProcessRepository;
        private readonly IAssetTransactionRepository _assetTransactionRepository;
        private readonly IAssetAllocationRepository _assetAllocationRepository;
        private readonly IWarehouseGroupTaxRule _warehouseGroupTaxRule;
        private readonly IAssetLogRepository _log;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICdcWarehouseManagementService cdcWarehouseManagementService;

        public TaxDetailService(ICdcWarehouseManagementService cdcWarehouseManagementService, IAssetProcessRepository assetProcessRepository, IAssetTransactionRepository assetTransactionRepository, IAssetAllocationRepository assetAllocationRepository, IWarehouseGroupTaxRule warehouseGroupTaxRule, IAssetLogRepository logRepository, IUnitOfWork unitOfWork)
        {
            this.cdcWarehouseManagementService = cdcWarehouseManagementService;
            _assetProcessRepository = assetProcessRepository;
            _assetTransactionRepository = assetTransactionRepository;
            _assetAllocationRepository = assetAllocationRepository;
            _warehouseGroupTaxRule = warehouseGroupTaxRule;
            _log = logRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<ResponseModel<List<AssetProcessDto>?>> GetTaxSummaries(GetSellTaxSummariesRequest request)
        {
            //اگر صادر شده بود بده وگرنه نده 
            // اگر در این باز حتی اگه یک مشتری ای وجود داشته باشد که جمع تجمیعی منفی داشته باشد در اینصورت 
            //از همان مشتری کلا رد بشه
            //و بقیه را حساب کنه
            List<AssetProcessDto>? assetProcesses = null;
            try
            {
                //برای گروهی هم با دیتای غیر نرمان چک شود
                //if (await _assetAllocationRepository.CheckAbnormalAvailableQuantity(request.WarehouseGroupId))
                //{
                //    return FailedResponseList(assetProcesses);
                //}
                assetProcesses = await GetAssetProcessList(request.WarehouseGroupId, request.TaxDate);

                if (assetProcesses is null || assetProcesses.Count == 0)
                {
                    List<AssetExit> allocations = await GetAssetAllocations(request.WarehouseGroupId, request.TaxDate);
                    List<AssetProcess>? process = await _warehouseGroupTaxRule.SaveAssetProcessDetailForGetTaxSummaries(allocations);

                    if (process is not null && process.Count > 0)
                    {
                        assetProcesses = await GetAssetProcessList(request.WarehouseGroupId, request.TaxDate);
                        return SuccessResponse(assetProcesses);
                    }
                    else
                    {
                        return NotFoundResponseForAssetProccessList();
                    }
                }
                else
                {
                    return SuccessResponse(assetProcesses);
                }
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, $"{nameof(GetTaxSummaries)} in {nameof(TaxDetailService)}");
                return InternalServerErrorResponseForAssetProccessList();
            }
        }

        public async Task<ResponseModel<AssetProcessDto?>> GetTaxSummariesByUniqueId(GetTaxSummariesByUniqueIdRequest request)
        {
            // با رف و با یونیک کد دنبال رف بگرد
            // و اعلامیه همان رف را بده
            // مشتری رف و یونیک کد میفرستد
            // اگر با اون رف کلیرنسی بود الوکیت های ان کلیرنس رو بردارُ
            // و در جدول پراسس دیتیل بزن
            // اگر رف نبود بگو رف موجود نیست
            // همرو که پیدا کرد بیاد تبدیل به یک پراسس کنه - تجمیع کنه
            // و حاصل را برگردونه 
            // اگر چیزی نبود نال برگردونه
            // دیتیل رو از روی الوکیت میسازه+ پراسس رو 
            //اگر واقعا صادر کردی بگو کامیت  وگرنه درفت
            //محاسبه بر رول مخصوص کلیرنس باشه

            AssetProcessDto? assetProcess = null;
            try
            {

                var validate = await Validate(request.ReferenceId);
                if (validate != null) return validate;


                assetProcess = await GetAssetProcess(request.ReferenceId);
                if (assetProcess is null || assetProcess.Id == 0)
                {
                    List<AssetExit> allocations = await GetAssetAllocations(request.ReferenceId);
                    AssetProcess? process = await _warehouseGroupTaxRule.SaveAssetProcessDetail(allocations);


                    if (process is not null && process.Id > 0)
                    {
                        assetProcess = await GetAssetProcess(request.ReferenceId);

                        return SuccessResponse(assetProcess);
                    }
                    else
                    {
                        return NotFoundResponse();

                    }
                }
                else
                {
                    return SuccessResponse(assetProcess);
                }
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, $"{nameof(GetTaxSummariesByUniqueId)} in {nameof(TaxDetailService)}");
                return InternalServerErrorResponse();
            }
        }



        public async Task<ResponseModel<AssetProcessDto?>> GetClearanceTaxSummary(GetClearanceTaxSummaryRequest request)
        {
            AssetProcessDto? assetProcess;
            try
            {
                var validate = await Validate(request.ReferenceId);
                if (validate != null) return validate;

                assetProcess = await GetAssetProcessForClearanceTaxSummary(request.ReferenceId, request.FromAmount, request.ToAmount);
                if (assetProcess is null || assetProcess.Id == 0)
                {
                    List<AssetExit> allocations = await GetAssetAllocations(request.ReferenceId);
                    AssetProcess? process = await _warehouseGroupTaxRule.SaveAssetProcessDetail(allocations);


                    if (process is not null && process.Id > 0)
                    {
                        assetProcess = await GetAssetProcessForClearanceTaxSummary(request.ReferenceId, request.FromAmount, request.ToAmount);
                        return SuccessResponse(assetProcess);
                    }
                    else
                    {
                        return NotFoundResponse();
                    }
                }
                else
                {
                    return SuccessResponse(assetProcess);
                }
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, $"{nameof(GetClearanceTaxSummary)} in {nameof(TaxDetailService)}");
                return InternalServerErrorResponse();
            }




        }


        //public async Task<ResponseModel<AssetProcessDto?>> GetTaxSummariesByUniqueIdIME(GetTaxSummariesByUniqueIdIMERequest request)
        //{
        //    AssetProcessDto? assetProcess;
        //    try
        //    {

        //        var validate = await Validate(request.ReferenceId);
        //        if (validate != null) return validate;

        //        assetProcess = await GetAssetProcess(request.ReferenceId);
        //        if (assetProcess is null || assetProcess.Id == 0)
        //        {
        //            List<AssetExit> allocations = await GetAssetAllocations(request.ReferenceId);
        //            AssetProcess? process = await _warehouseGroupTaxRule.SaveAssetProcessDetail(allocations);


        //            if (process is not null && process.Id > 0)
        //            {
        //                assetProcess = await GetAssetProcess(request.ReferenceId);
        //                return SuccessResponse(assetProcess);
        //            }
        //            else
        //            {
        //                return NotFoundResponse();
        //            }
        //        }
        //        else
        //        {
        //            return SuccessResponse(assetProcess);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        await _logRepository.LogIt(ex, $"{nameof(GetTaxSummariesByUniqueIdIME)} in {nameof(TaxDetailService)}");
        //        return InternalServerErrorResponse();
        //    }




        //}

        public async Task<ResponseModel<AssetProcessDto?>> GetTaxSummariesByUniqueId2(GetTaxSummariesByUniqueIdRequest request)
        {
            AssetProcessDto? assetProcess;
            try
            {
                var validate = await Validate(request.ReferenceId);
                if (validate != null) return validate;

                assetProcess = await GetAssetProcess(request.ReferenceId);
                if (assetProcess is null || assetProcess.Id == 0)
                {
                    List<AssetExit> allocations = await GetAssetAllocations(request.ReferenceId);
                    AssetProcess? process = await _warehouseGroupTaxRule.SaveAssetProcessDetail(allocations);


                    if (process is not null && process.Id > 0)
                    {
                        assetProcess = await GetAssetProcess(request.ReferenceId);
                        return SuccessResponse(assetProcess);
                    }
                    else
                    {
                        return NotFoundResponse();
                    }
                }
                else
                {
                    return SuccessResponse(assetProcess);
                }
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, $"{nameof(GetTaxSummariesByUniqueId)} in {nameof(TaxDetailService)}");
                return InternalServerErrorResponse();
            }
        }

        private async Task<bool> HandleInvalidDataAsync(long uniqueId, long referenceId)
        {
            return await _assetTransactionRepository.CheckAbnormalTransactionsByReferenceIdAsync(uniqueId, referenceId);
        }


        private async Task<List<AssetProcessDto>?> GetAssetProcessList(int warehouseGroupId, DateTime TaxDate)
        {
            List<AssetProcessDto>? assetProcesses = await _assetProcessRepository.GetTaxSummaries(warehouseGroupId, TaxDate);
            return assetProcesses;
        }

        private async Task<AssetProcessDto?> GetAssetProcess(long referenceId)
        {
            AssetProcessDto? assetProcess = await _assetProcessRepository.Get(x => x.ReferenceId == referenceId);

            if (assetProcess is null || assetProcess.Id <= 0 || assetProcess.Status != AssetProcessDetailStatus.Draft)
            {
                return assetProcess;
            }

            assetProcess.Status = AssetProcessDetailStatus.Committed;

            List<long> allocationIds = assetProcess.AssetProcessDetails
               .Where(x => x.AssetAllocationId > 0)
               .Select(x => x.AssetAllocationId)
               .Distinct()
               .ToList();

            List<AssetAllocation> allocations = await _assetAllocationRepository.GetAll(x => allocationIds.Contains(x.Id));

            foreach (var detail in assetProcess.AssetProcessDetails)
            {
                detail.Status = AssetProcessDetailStatus.Committed;
            }

            foreach (var allocation in allocations)
            {
                allocation.Status = AssetAllocationStatus.Committed;
            }

            await _unitOfWork.SaveChangesAsync();

            return assetProcess;
        }


        private async Task<AssetProcessDto?> GetAssetProcessForClearanceTaxSummary(
    long referenceId,
    decimal fromAmount,
    decimal toAmount)
        {
            var assetProcess = await _assetProcessRepository.Get(x => x.ReferenceId == referenceId);

            if (assetProcess is null || assetProcess.Id <= 0) return null;

            decimal totalAvailableQuantity = assetProcess.AssetProcessDetails.Sum(x => x.Quantity);

            decimal mathFrom = fromAmount - 1;
            decimal mathTo = toAmount;

            if (mathTo > totalAvailableQuantity)
            {
                throw new ArgumentOutOfRangeException(nameof(toAmount), $"بازه‌ی درخواستی از کل موجودی ({totalAvailableQuantity}) بیشتر است.");
            }

            if (mathFrom < 0 || mathFrom >= mathTo)
            {
                throw new ArgumentException("بازه شروع نامعتبر است.");
            }

            // تغییر وضعیت به Committed
            if (assetProcess.Status == AssetProcessDetailStatus.Draft)
            {
                assetProcess.Status = AssetProcessDetailStatus.Committed;
                await _unitOfWork.SaveChangesAsync();
            }


            var details = assetProcess.AssetProcessDetails.OrderBy(x => x.Id).ToList();
            var result = new List<AssetProcessDetailDto>();
            decimal currentCumulative = 0;

            foreach (var item in details)
            {
                if (currentCumulative >= mathTo) break;

                var itemStart = currentCumulative;
                var itemEnd = currentCumulative + item.Quantity;

                // محاسبه همپوشانی بازه کلاینت با این آیتم
                decimal overlapStart = Math.Max(mathFrom, itemStart);
                decimal overlapEnd = Math.Min(mathTo, itemEnd);

                if (overlapEnd > overlapStart)
                {
                    decimal takeQuantity = overlapEnd - overlapStart;

                    result.Add(new AssetProcessDetailDto
                    {
                        Id = item.Id,
                        Price = item.Price,
                        Quantity = takeQuantity
                    });
                }

                currentCumulative = itemEnd;
            }

            // آپدیت مقادیر اصلی شیء assetProcess
            var Quantity = assetProcess.AssetProcessDetails.Sum(x => x.Quantity);
            var TotalPrice = assetProcess.AssetProcessDetails.Sum(x => x.Quantity * x.Price);
            assetProcess.Quantity = Quantity;
            assetProcess.TotalPrice = TotalPrice;
            assetProcess.AveragePrice = TotalPrice / Quantity;

            decimal expectedQuantity = toAmount - fromAmount + 1;
            var totalQuantity = result.Sum(x => x.Quantity);
            if (totalQuantity != expectedQuantity) throw new InvalidOperationException($"خطا: مجموع برداشتی ({totalQuantity}) با بازه درخواستی ({expectedQuantity}) مطابقت ندارد.");


            return assetProcess;

        }





        private async Task<AssetProcessDto?> GetAssetProcessForClearanceTaxSummary1(
            long referenceId,
            decimal fromAmount,
            decimal toAmount)
        {
            var assetProcess = await _assetProcessRepository.Get(x => x.ReferenceId == referenceId);

            if (assetProcess is null || assetProcess.Id <= 0) return null;


            // اعتبارسنجی بازه درخواستی نسبت به موجودی واقعی
            decimal totalAvailableQuantity = assetProcess.AssetProcessDetails.Sum(x => x.Quantity);

            if (toAmount > totalAvailableQuantity)
            {
                throw new ArgumentOutOfRangeException(nameof(toAmount), $"بازه‌ی درخواستی ({toAmount}) از کل مقدار موجود ({totalAvailableQuantity}) بیشتر است.");
            }

            if (fromAmount < 0 || fromAmount >= toAmount)
            {
                throw new ArgumentException("بازه شروع نباید منفی یا بزرگتر از پایان باشد.");
            }



            if (assetProcess.Status == AssetProcessDetailStatus.Draft)
            {
                assetProcess.Status = AssetProcessDetailStatus.Committed;
                await _unitOfWork.SaveChangesAsync();
            }


            var details = assetProcess.AssetProcessDetails.OrderBy(x => x.Id).ToList();

            var result = new List<AssetProcessDetailDto>();
            decimal currentAmount = 0;

            foreach (var item in details)
            {
                if (currentAmount >= toAmount) break;

                var itemEnd = currentAmount + item.Quantity;

                // هنوز به fromAmount نرسیدیم
                if (itemEnd <= fromAmount)
                {
                    currentAmount = itemEnd;
                    continue;
                }

                // بخشی از آیتم داخل بازه است
                var startInItem = Math.Max(fromAmount, currentAmount);
                var endInItem = Math.Min(toAmount, itemEnd);

                var takeQuantity = endInItem - startInItem;

                if (takeQuantity > 0)
                {
                    result.Add(new AssetProcessDetailDto
                    {
                        // اگر خواستی از خود item کپی کن
                        Id = item.Id,
                        Price = item.Price,
                        Quantity = takeQuantity
                    });
                }

                currentAmount = itemEnd;
            }

            assetProcess.AssetProcessDetails = result;


            var Quantity = assetProcess.AssetProcessDetails.Sum(x => x.Quantity);
            var TotalPrice = assetProcess.AssetProcessDetails.Sum(x => x.Quantity * x.Price);
            assetProcess.Quantity = Quantity;
            assetProcess.TotalPrice = TotalPrice;
            assetProcess.AveragePrice = TotalPrice / Quantity;



            var totalQuantity = result.Sum(x => x.Quantity);
            if (totalQuantity != (toAmount - fromAmount)) throw new InvalidOperationException("جمع quantity ها برابر بازه درخواستی نیست.");

            return assetProcess;
        }


        private async Task<List<AssetExit>> GetAssetAllocations(long referenceId)
        {
            List<AssetExit> allocations = await _assetAllocationRepository.GetAllAssetAllocation(x => x.AssetTransaction.ReferenceId == referenceId && x.Status == AssetAllocationStatus.UnTouched);
            return allocations;
        }
        private async Task<List<AssetExit>> GetAssetAllocations(int warehouseGroupId, DateTime TaxDate)
        {
            List<AssetExit> allocations = await _assetAllocationRepository.GetAllAssetAllocationForTaxSummaries(warehouseGroupId, TaxDate);
            return allocations;
        }



        private static ResponseModel<AssetProcessDto?> InternalServerErrorResponse()
        {
            return ResponseModel<AssetProcessDto?>.InternalServerErrorResponse();
        }

        private static ResponseModel<AssetProcessDto?> SuccessResponse(AssetProcessDto? assetProcessDto)
        {
            return ResponseModel<AssetProcessDto?>.SuccessResponse(assetProcessDto);
        }

        private static ResponseModel<AssetProcessDto?> NotFoundResponse()
        {
            return ResponseModel<AssetProcessDto?>.NotFoundResponse();
        }




        private static ResponseModel<List<AssetProcessDto>?> InternalServerErrorResponseForAssetProccessList()
        {
            return ResponseModel<List<AssetProcessDto>?>.InternalServerErrorResponse();
        }

        private static ResponseModel<List<AssetProcessDto>?> SuccessResponse(List<AssetProcessDto>? assetProcessDto)
        {
            return ResponseModel<List<AssetProcessDto>?>.SuccessResponse(assetProcessDto);
        }

        private static ResponseModel<List<AssetProcessDto>?> NotFoundResponseForAssetProccessList()
        {
            return ResponseModel<List<AssetProcessDto>?>.NotFoundResponse();
        }

        private static ResponseModel<AssetProcessDto?> FailedResponseAbnormalAvailableQuantity(AssetProcessDto? assetProcess)
        {
            return new ResponseModel<AssetProcessDto> { StatusCode = 400, Message = "Transaction With referenceId has minus AvailableQuantity" };
        }
        private static ResponseModel<AssetProcessDto?> FailedResponseMismatchAvailableQuantityWithWarehouse(long? referenceId, AssetAllocation? lastSnapshot, CustomerBalanceDto CustomerBalanceDto, int ContractRate)
        {
            return new ResponseModel<AssetProcessDto> { StatusCode = 400, Message = $"Transaction With referenceId = {referenceId} has Mismatch AvailableQuantity({lastSnapshot?.AvailableQuantity}) With Warehouse balance( CustomerBalanceDto.Balance * ContractRate ) => ({CustomerBalanceDto?.Balance} * {ContractRate})  point: [ CustomerBalanceDto.Balance = null means notfound in warehouse api]" };
        }
        private static ResponseModel<AssetProcessDto?> FailedResponseReferenceIdHasAllocationData()
        {
            return ResponseModel<AssetProcessDto>.NotFoundResponse("ReferenceId not found in Allocations");
        }
        private static ResponseModel<AssetProcessDto?> FailedResponseReferenceIdHasTransactionsData()
        {
            return ResponseModel<AssetProcessDto>.NotFoundResponse("ReferenceId not found in AssetTransactions");
        }
        private static ResponseModel<List<AssetProcessDto>?> FailedResponseList(List<AssetProcessDto>? assetProcess)
        {
            return new ResponseModel<List<AssetProcessDto>?> { StatusCode = 400, Message = "Invalid data detected" };
        }


        private async Task<ResponseModel<AssetProcessDto?>?> Validate(long ReferenceId)
        {
            if (ReferenceId <= 0)
            {
                return FailedResponseReferenceIdHasTransactionsData();
            }
            if (await _assetAllocationRepository.CheckReferenceIdHasTransactionData(ReferenceId))
            {
                return FailedResponseReferenceIdHasTransactionsData();
            }
            if (await _assetAllocationRepository.CheckReferenceIdHasAllocationData(ReferenceId))
            {
                return FailedResponseReferenceIdHasAllocationData();
            }
            if (await _assetAllocationRepository.CheckAbnormalAvailableQuantity2(ReferenceId))
            {
                return FailedResponseAbnormalAvailableQuantity(null);
            }


            var Atransaction = await _assetAllocationRepository.GetTransactionByReferenceId(ReferenceId);
            var getWarehouseBalance = await cdcWarehouseManagementService.GetCustomerBalanceAsync((long)Atransaction.UniqueId, Atransaction.WarehouseId, DateTime.Now);
            AssetAllocation? lastSnapshot = await _assetAllocationRepository.GetLatestSnapshot(new AssetExit
            {
                SymbolId = Atransaction.SymbolId,
                UniqueId = Atransaction.UniqueId,
                WarehouseId = Atransaction.WarehouseId
            });

            var ContractRate = 10;//GetContractRate(Atransaction.WarehouseId);
            if ((getWarehouseBalance is not null && getWarehouseBalance.AssetOwnerUniqueCode == (long)Atransaction.UniqueId) && (lastSnapshot is not null && lastSnapshot.Id > 0))
            {
                if (getWarehouseBalance.Balance * ContractRate != Convert.ToDouble(lastSnapshot?.AvailableQuantity))
                {
                    return FailedResponseMismatchAvailableQuantityWithWarehouse(ReferenceId, lastSnapshot, getWarehouseBalance, ContractRate);
                }
                else
                {
                    return null;
                }
            }
            return FailedResponseMismatchAvailableQuantityWithWarehouse(ReferenceId, lastSnapshot, getWarehouseBalance, ContractRate);

        }

    }
}
