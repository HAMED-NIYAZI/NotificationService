﻿using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using MapsterMapper;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
namespace AssetFlow.Application.Common.Services;


public class CdcWarehouseManagementService : ICdcWarehouseManagementService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IAllocationStateStore _allocationStateStore;
    private readonly ISymbolRepository _symbolRepository;
    private HttpClient client;
    private readonly IMapper _mapper;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<CdcWarehouseManagementService> _logger;
    private readonly string _baseUrl = "https://whmapp.ime.co.ir:8080";
    private readonly string _username = "assetflow";
    private readonly string _password = "NiAzMand";

    private string _cachedToken;
    private DateTime _tokenExpiration;

    private readonly AsyncRetryPolicy _loginRetryPolicy;

    private readonly AsyncRetryPolicy<HttpResponseMessage> _apiRetryPolicy;

    public CdcWarehouseManagementService(ISymbolRepository symbolRepository, IAllocationStateStore allocationStateStore, IUnitOfWork unitOfWork, IMapper mapper, IHttpClientFactory httpClientFactory, ILogger<CdcWarehouseManagementService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _allocationStateStore = allocationStateStore;
        _symbolRepository = symbolRepository;
        _logger = logger;
        _mapper = mapper;
        _unitOfWork = unitOfWork;

        client = _httpClientFactory.CreateClient("WarehouseClient");

        _loginRetryPolicy = Policy
           .Handle<HttpRequestException>()
           .Or<TaskCanceledException>()
           .WaitAndRetryAsync(
               3,
               retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
               onRetry: (exception, timeSpan, retryCount, context) =>
               {
                   _logger.LogWarning($"Login failed (network). Retry {retryCount} in {timeSpan.TotalSeconds} sec.");
               });

        _apiRetryPolicy = Policy
           .HandleResult<HttpResponseMessage>(r => r.StatusCode == HttpStatusCode.Unauthorized)
           .WaitAndRetryAsync(
               3,
               retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
               onRetry: (response, timeSpan, retryCount, context) =>
               {
                   _logger.LogWarning($"Received 401 Unauthorized. Clearing token and retrying {retryCount} of 3.");

                   _cachedToken = null;
                   _tokenExpiration = DateTime.UtcNow;
               });
    }

    private async Task<string> GetValidTokenAsync()
    {
        if (!string.IsNullOrEmpty(_cachedToken) && _tokenExpiration > DateTime.UtcNow)
            return _cachedToken;
        return await _loginRetryPolicy.ExecuteAsync(async () =>
        {
            var loginUrl = $"{_baseUrl}/Auth/Login";

            var loginData = new { username = _username, password = _password };
            var json = JsonConvert.SerializeObject(loginData);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(loginUrl, content);
            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();
            var loginResult = JsonConvert.DeserializeObject<LoginApiResponse>(responseJson);

            _cachedToken = loginResult.Data.Token;
            _tokenExpiration = loginResult.Data.TokenExpireTime;

            _logger.LogInformation("Login successful. Token valid until {Expiration}", _tokenExpiration);
            return _cachedToken;
        });
    }

    public async Task<List<CustomerBalanceDto>> GetAllCustomerBalancesAsync(int warehouseId, DateTime dateTime)
    {
        var dateString = dateTime.ToString("yyyy-MM-dd");
        var url = $"{_baseUrl}/Trading/CustomerBalances/{warehouseId}/{dateString}";

        var response = await _apiRetryPolicy.ExecuteAsync(async () =>
       {

           var token = await GetValidTokenAsync();


           client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
           client.DefaultRequestHeaders.Add("accept", "text/plain");

           return await client.GetAsync(url);
       });

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            _logger.LogError("Failed to get balances after retries. Status: {StatusCode}, Error: {Error}",
                response.StatusCode, errorContent);
            throw new HttpRequestException($"API returned {response.StatusCode}: {errorContent}");
        }

        var responseModel = JsonConvert.DeserializeObject<List<CustomerBalanceDto>>(await response.Content.ReadAsStringAsync());

        return responseModel;
    }


    public async Task<CustomerBalanceDto> GetCustomerBalanceAsync(long? uniqueId, int warehouseId, DateTime dateTime)
    {
        var GetCustomerBalances = await GetAllCustomerBalancesAsync(warehouseId, dateTime.AddDays(1));
        var GetCustomerBalance = GetCustomerBalances.FirstOrDefault(x => x.AssetOwnerUniqueCode == uniqueId);

        // data = GetCustomerBalance.Balance * 10,
        if (GetCustomerBalance is not null)
        {
            var symbolId = _symbolRepository.GetSymbolId(warehouseId);

            _allocationStateStore.CreateOrUpdateBalance(
                new AllocationStateKey(0000000, warehouseId), GetCustomerBalance.Balance, DateOnly.FromDateTime(dateTime)
                );

        }


        return GetCustomerBalance;
    }

    public async Task GetAllAndSaveAsync(int warehouseId, DateTime dateTime)
    {
        var dateString = dateTime.ToString("yyyy-MM-dd");
        var url = $"{_baseUrl}/Trading/CustomerBalances/{warehouseId}/{dateString}";

        var response = await _apiRetryPolicy.ExecuteAsync(async () =>
        {

            var token = await GetValidTokenAsync();


            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            client.DefaultRequestHeaders.Add("accept", "text/plain");

            return await client.GetAsync(url);
        });

        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            _logger.LogError("Failed to get balances after retries. Status: {StatusCode}, Error: {Error}",
                response.StatusCode, errorContent);
        }

        var responseModel = JsonConvert.DeserializeObject<List<CustomerBalanceDto>>(await response.Content.ReadAsStringAsync());


    }

    public async Task<IReadOnlyList<CustomerAssetClearanceDto>> GetClearanceFromWarehouseManagement(int warehouseId)
    {
        var url = $"{_baseUrl}/CustomerAssets/asset-clearings/{warehouseId}";

        var response = await _apiRetryPolicy.ExecuteAsync(async () =>
        {

            var token = await GetValidTokenAsync();


            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            client.DefaultRequestHeaders.Add("accept", "text/plain");

            return await client.GetAsync(url);
        });

        if (!response.IsSuccessStatusCode)
        {
            _cachedToken = string.Empty;
            var errorContent = await response.Content.ReadAsStringAsync();
            _logger.LogError("Failed to get balances after retries. Status: {StatusCode}, Error: {Error}",
                response.StatusCode, errorContent);
            return null;
        }

        var responseModel = JsonConvert.DeserializeObject<IReadOnlyList<CustomerAssetClearanceDto>>(await response.Content.ReadAsStringAsync());

        foreach (var item in responseModel)
        {
            if (item.warehouseGroupId is null) item.warehouseGroupId = warehouseId;
        }

        return responseModel;
    }
    public async Task<IReadOnlyList<CustomerAssetEntryDto>> GetEntranceFromWarehouseManagement(int warehouseId)
    {
        var url = $"{_baseUrl}/CustomerAssets/asset-entries/{warehouseId}";

        var response = await _apiRetryPolicy.ExecuteAsync(async () =>
        {

            var token = await GetValidTokenAsync();


            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            client.DefaultRequestHeaders.Add("accept", "text/plain");

            return await client.GetAsync(url);
        });

        if (!response.IsSuccessStatusCode)
        {
            _cachedToken = string.Empty;
            var errorContent = await response.Content.ReadAsStringAsync();
            _logger.LogError("Failed to get balances after retries. Status: {StatusCode}, Error: {Error}",
                response.StatusCode, errorContent);
            throw new HttpRequestException($"API returned {response.StatusCode}: {errorContent}");
        }

        var responseModel = JsonConvert.DeserializeObject<IReadOnlyList<CustomerAssetEntryDto>>(await response.Content.ReadAsStringAsync());
        foreach (var item in responseModel)
        {
            if (item.warehouseGroupId is null)
                item.warehouseGroupId = warehouseId;
        }
        return responseModel;
    }
}







public class LoginData
{
    public string Username { get; set; }
    public string Token { get; set; }
    public DateTime TokenExpireTime { get; set; }
}

public class LoginApiResponse
{
    public LoginData Data { get; set; }
    public int Code { get; set; }
    public string Message { get; set; }
    public bool Success { get; set; }
}


public class CustomerBalanceDto
{
    /// <summary>
    /// Eequal to CustomerIme
    /// </summary>
    public long CustomerAppId { get; set; }

    /// <summary>
    /// Eequal to CustomerIme
    /// </summary>
    public long UniqueId { get; set; }

    /// <summary>
    /// Equal to UniquId
    /// </summary>
    public long AssetOwnerUniqueCode { get; set; }

    /// <summary>
    /// Available Quantity
    /// </summary>
    public double Balance { get; set; }
    public double LastTransactionAmount { get; set; }
    public DateTime LastTransactionTime { get; set; }
    public long LastTransactionId { get; set; }
}

public class CustomerAssetClearanceDto
{
    public long transactionId { get; set; }
    public int? warehouseGroupId { get; set; }
    public long assetOwnerUniqueCode { get; set; }
    public double amount { get; set; }
    public string? referenceId { get; set; }
    public DateTime date { get; set; }
}


public class CustomerAssetEntryDto
{
    public long transactionId { get; set; }
    public int? warehouseGroupId { get; set; }
    public long assetOwnerUniqueCode { get; set; }
    public double amount { get; set; }
    public DateTime date { get; set; }
}
