﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs
{
    public interface IRecurringJobScheduler
    {
        void ScheduleJob();
        void EnqueueJob();
    }
}
