﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;

public interface IEntranceSyncDataJob : ISyncDataJob
{
}
