﻿using AssetFlow.Application.Common.Services.ExternalServices;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Hangfire;

namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs
{
    public interface ISyncClearanceAndEntranceFromMarket
    {
        Task SyncOldClearancesFromMarket();
        Task SyncDailyClearancesFromMarket();
    }

    public class SyncClearanceAndEntranceFromMarket : ISyncClearanceAndEntranceFromMarket
    {
        private readonly ICustomerRepository customerRepository;
        private readonly IMarketService marketService;
        private readonly IMarketRepository marketRepository;
        private static TimeSpan TimeSpanBatch = TimeSpan.FromMinutes(5) + TimeSpan.FromSeconds(5);
        public SyncClearanceAndEntranceFromMarket(ICustomerRepository customerRepository, IMarketService marketService, IMarketRepository marketRepository)
        {
            this.marketService = marketService;
            this.marketRepository = marketRepository;
            this.customerRepository = customerRepository;
        }

        [DisableConcurrentExecution(timeoutInSeconds: 0)]
        public async Task SyncOldClearancesFromMarket()
        {
            var fromDate = DateTime.Today;
            var toDate = DateTime.Today.AddDays(1).AddMilliseconds(-1);
            IReadOnlyList<MarketCustomerClearance> clearances;
            try
            {
                clearances = await marketService.GetCustomersClearances(fromDate, toDate);
                await marketRepository.BulkUpsertAsync(clearances);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                BackgroundJob.Schedule(() => SyncOldClearancesFromMarket(), TimeSpanBatch);
            }
        }

        public async Task SyncDailyClearancesFromMarket()
        {

            var now = DateTime.Today.AddDays(-1);
            var fromDate = now;
            var toDate = now.AddDays(1).AddMilliseconds(-1);
            IReadOnlyList<MarketCustomerClearance> clearances;
            try
            {
                clearances = await marketService.GetCustomersClearances(fromDate, toDate);

                //var str = "[{\"referenceId\":2026090514160315363,\"executedQuantity\":1.000000,\"receiveTime\":\"2026-09-06T08:24:23.217\",\"warehouseGroupID\":39,\"customerID_
                //\":529707,\"uniqueID\":337784,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090514300015364,\"executedQuantity\":5.000000,\"receiveTime\":\"2026-09-06T08:24:30.003\",\"warehouseGroupID\":39,\"customerID_IME\":17135,\"uniqueID\":806347,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090516320615373,\"executedQuantity\":11.000000,\"receiveTime\":\"2026-09-06T08:24:42.83\",\"warehouseGroupID\":39,\"customerID_IME\":909736,\"uniqueID\":980906,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090514024915361,\"executedQuantity\":15.000000,\"receiveTime\":\"2026-09-06T08:23:58.103\",\"warehouseGroupID\":39,\"customerID_IME\":1155411,\"uniqueID\":1110024,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090516573415374,\"executedQuantity\":24.000000,\"receiveTime\":\"2026-09-06T08:24:47.647\",\"warehouseGroupID\":39,\"customerID_IME\":1192199,\"uniqueID\":1146888,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090515122215365,\"executedQuantity\":49.000000,\"receiveTime\":\"2026-09-06T08:24:34.74\",\"warehouseGroupID\":39,\"customerID_IME\":1129492,\"uniqueID\":1083734,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090514052115362,\"executedQuantity\":127.000000,\"receiveTime\":\"2026-09-06T08:24:10.593\",\"warehouseGroupID\":39,\"customerID_IME\":1089022,\"uniqueID\":1043232,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518045415379,\"executedQuantity\":180.000000,\"receiveTime\":\"2026-09-06T08:24:53.617\",\"warehouseGroupID\":39,\"customerID_IME\":1043065,\"uniqueID\":794610,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090608164615386,\"executedQuantity\":210.000000,\"receiveTime\":\"2026-09-06T08:25:06.337\",\"warehouseGroupID\":39,\"customerID_IME\":39380,\"uniqueID\":841222,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518380215384,\"executedQuantity\":326.000000,\"receiveTime\":\"2026-09-06T08:24:59.837\",\"warehouseGroupID\":39,\"customerID_IME\":1096131,\"uniqueID\":1050340,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518034515377,\"executedQuantity\":1000.000000,\"receiveTime\":\"2026-09-06T09:49:07.813\",\"warehouseGroupID\":38,\"customerID_IME\":1043065,\"uniqueID\":794610,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518370615381,\"executedQuantity\":1004.000000,\"receiveTime\":\"2026-09-06T09:39:39.92\",\"warehouseGroupID\":38,\"customerID_IME\":1186017,\"uniqueID\":1140698,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090511231315360,\"executedQuantity\":1004.000000,\"receiveTime\":\"2026-09-06T09:50:00.77\",\"warehouseGroupID\":38,\"customerID_IME\":1158243,\"uniqueID\":1112860,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518374015383,\"executedQuantity\":2008.000000,\"receiveTime\":\"2026-09-06T09:36:02.4\",\"warehouseGroupID\":38,\"customerID_IME\":1125688,\"uniqueID\":1079930,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518372315382,\"executedQuantity\":2008.000000,\"receiveTime\":\"2026-09-06T09:42:04.463\",\"warehouseGroupID\":38,\"customerID_IME\":1156613,\"uniqueID\":1111229,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090608195015388,\"executedQuantity\":3000.000000,\"receiveTime\":\"2026-09-06T09:33:54.023\",\"warehouseGroupID\":38,\"customerID_IME\":1174599,\"uniqueID\":1129270,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090517335915375,\"executedQuantity\":4000.000000,\"receiveTime\":\"2026-09-06T09:26:16.09\",\"warehouseGroupID\":38,\"customerID_IME\":1157629,\"uniqueID\":1112296,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090609170015390,\"executedQuantity\":5012.000000,\"receiveTime\":\"2026-09-06T10:04:35.857\",\"warehouseGroupID\":38,\"customerID_IME\":1163562,\"uniqueID\":1118179,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090608170415387,\"executedQuantity\":6000.000000,\"receiveTime\":\"2026-09-06T09:21:53.11\",\"warehouseGroupID\":38,\"customerID_IME\":267444,\"uniqueID\":708638,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090518042615378,\"executedQuantity\":6024.000000,\"receiveTime\":\"2026-09-06T09:24:04.487\",\"warehouseGroupID\":38,\"customerID_IME\":245383,\"uniqueID\":699979,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090608394315389,\"executedQuantity\":12000.000000,\"receiveTime\":\"2026-09-06T09:15:45.34\",\"warehouseGroupID\":38,\"customerID_IME\":1095272,\"uniqueID\":1049482,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null},{\"referenceId\":2026090509285515359,\"executedQuantity\":24000.000000,\"receiveTime\":\"2026-09-06T09:15:57.733\",\"warehouseGroupID\":44,\"customerID_IME\":1006137,\"uniqueID\":541371,\"clearanceType\":\"M\",\"Id\":0,\"MarketCustomerClearanceId\":0,\"DrvCustomerID\":null}]";
                // clearances=JsonConvert.DeserializeObject<IReadOnlyList<MarketCustomerClearance>>(str);
                await marketRepository.BulkUpsertAsync(clearances);
            }
            catch (Exception ex)
            {
                BackgroundJob.Schedule(() => SyncOldClearancesFromMarket(), TimeSpanBatch);
            }
        }

        private static readonly List<(DateTime From, DateTime To)> HistoricalBatches =
            [
            (new DateTime(2023, 01, 01,00,00,00), new DateTime(2023, 06, 30,23,59,59)),
            (new DateTime(2023, 07, 01,00,00,00), new DateTime(2023, 12, 30,23,59,59)),
            (new DateTime(2024, 01, 01,00,00,00), new DateTime(2024, 06, 30,23,59,59)),
            (new DateTime(2024, 07, 01,00,00,00), new DateTime(2024, 12, 30,23,59,59)),
            (new DateTime(2025, 01, 01,00,00,00), new DateTime(2025, 06, 30,23,59,59)),
            (new DateTime(2025, 07, 01,00,00,00), new DateTime(2025, 12, 30,23,59,59)),
            (new DateTime(2026, 01, 01,00,00,00), new DateTime(2026, 06, 30,23,59,59)),
            (new DateTime(2026, 07, 01,00,00,00), new DateTime(2026, 12, 30,23,59,59))
            ];

    }
}
