﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs
{
    public interface IAllocatorJob
    {
        Task ExecuteBatchAsync(CancellationToken cancellationToken = default);
        Task AllocateSingleAsync(long uniqueId, long warehouseId, long symbolId, CancellationToken cancellationToken = default);
        Task GetTransactionsAndAllocateByGroup(CancellationToken cancellationToken = default);
        Task GetAllTransactionsAndAllocateBySingle(CancellationToken cancellationToken = default);
        Task GetAllCustomerTransactionsAndAllocateBySingle(long uniqueId, long warehouseId, long symbolId);
        Task ProcessGroup(List<Domain.Entities.AssetTransaction> transactions, long? uniqueId = null, int? warehouseId = null);
        Task ProcessGroupInMemory(List<Domain.Entities.AssetTransaction> transactions, long? uniqueId = null, int? warehouseId = null);
        Task<bool> ReBuildAndAllocate(Domain.Entities.AssetTransaction transaction);
        Task SaveAndAllocateTransactionGroup(List<Domain.Entities.AssetTransaction> transactions);
        Task ProcessGroup_(List<Domain.Entities.AssetTransaction> transactions, long? targetUniqueId = null, int? targetWarehouseId = null);
    }
}
