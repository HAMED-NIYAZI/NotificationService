﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;

public interface ISyncDataAndAllocateCustomerJob
{
    Task ExecuteAsync(long uniqueId, int warehouseId, int symbolId);
}
