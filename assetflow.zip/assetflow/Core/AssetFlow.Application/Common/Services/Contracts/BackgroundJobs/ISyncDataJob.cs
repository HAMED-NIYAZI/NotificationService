﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;

public interface ISyncDataJob
{
    Task ExecuteAsync(CancellationToken cancellationToken = default);
}
