﻿using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Hangfire;
using Mapster;

namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs
{
    public interface ISyncClearanceAndEntranceFromWarehouse
    {
        Task SyncDailyClearancesFromWarehouse();
        Task SyncDailyEntrancesFromWarehouse();
    }

    public class SyncClearanceAndEntranceFromWarehouse : ISyncClearanceAndEntranceFromWarehouse
    {
        private readonly ICdcWarehouseManagementService cdcWarehouseManagementService;
        private readonly IWarehouseRepository warehouseRepository;
        private readonly ISymbolRepository symbolRepository;
        private readonly IAssetLogRepository _log;
        private static TimeSpan TimeSpanBatch = TimeSpan.FromMinutes(5) + TimeSpan.FromSeconds(5);
        public SyncClearanceAndEntranceFromWarehouse(ISymbolRepository symbolRepository,
            ICdcWarehouseManagementService cdcWarehouseManagementService,
            IWarehouseRepository warehouseRepository,
             IAssetLogRepository assetLogRepository)
        {
            this.cdcWarehouseManagementService = cdcWarehouseManagementService;
            this.symbolRepository = symbolRepository;
            this.warehouseRepository = warehouseRepository;
            this._log = assetLogRepository;
        }

        [DisableConcurrentExecution(timeoutInSeconds: 0)]
        public async Task SyncDailyClearancesFromWarehouse()
        {

            IReadOnlyList<CustomerAssetClearanceDto> clearances;
            try
            {
                var allWarehouses = await symbolRepository.GetAll();
                foreach (var wh in allWarehouses)
                {
                    clearances = await cdcWarehouseManagementService.GetClearanceFromWarehouseManagement(wh.WarehouseId);
                    if (clearances.Count > 0)
                    {
                        var dataclearances = clearances.Adapt<IReadOnlyCollection<WarehouseCustomerClearance>>();
                        await warehouseRepository.BulkUpsertWarehouseCustomerClearanceAsync(dataclearances);
                    }
                }

            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, ex.Message, null);
            }
            finally
            {
               // BackgroundJob.Schedule(() => SyncDailyClearancesFromWarehouse(), TimeSpanBatch);
            }
        }

        [DisableConcurrentExecution(timeoutInSeconds: 0)]
        public async Task SyncDailyEntrancesFromWarehouse()
        {

            IReadOnlyList<CustomerAssetEntryDto> entrances;
            try
            {
                var allWarehouses = await symbolRepository.GetAll();

                foreach (var wh in allWarehouses)
                {
                    entrances = await cdcWarehouseManagementService.GetEntranceFromWarehouseManagement(wh.WarehouseId);
                    if (entrances.Count > 0)
                    {
                        var dataentrances = entrances.Adapt<IReadOnlyCollection<WarehouseCustomerEntrance>>();
                        await warehouseRepository.BulkUpsertWarehouseCustomerEntranceAsync(dataentrances);
                    }
                }
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, ex.Message, null);
            }
            finally
            {
                //BackgroundJob.Schedule(() => SyncDailyEntrancesFromWarehouse(), TimeSpanBatch);
            }

        }


    }
}
