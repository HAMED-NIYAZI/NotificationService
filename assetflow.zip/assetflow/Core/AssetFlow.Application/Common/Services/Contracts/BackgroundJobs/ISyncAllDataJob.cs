﻿namespace AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;

public interface ISyncAllDataJob : ISyncDataJob
{
    Task SyncAllDataAndAllocateByGroup();
    Task SyncAllDataAndAllocateBySingle();
}
