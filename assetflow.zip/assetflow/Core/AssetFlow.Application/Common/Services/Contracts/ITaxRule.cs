﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services.Contracts
{
    public interface IRule
    {
        string RuleName { get; }
        AssetProcessDetailType RuleType { get; }
        Task<bool> IsIncludeRule(AssetExit allocation);
        Task<AssetProcessDetail> GenerateAssetProcessDetail(AssetExit allocation);
        Task<AssetProcess> GenerateAssetProcess(List<AssetProcessDetail> assetProcessDetails);
        Task<List<AssetProcess>> GenerateAssetProcessList(List<AssetProcessDetail> assetProcessDetails);
    }
}
