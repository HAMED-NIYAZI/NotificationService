﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services.Contracts;

public interface IWarehouseGroupTaxRule
{
    Task<AssetProcess> SaveAssetProcessDetail(List<AssetExit> allocations);
    Task<List<AssetProcess>?> SaveAssetProcessDetailForGetTaxSummaries(List<AssetExit> allocations);
}