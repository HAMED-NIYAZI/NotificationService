﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.TaxDetail.Dtos;
using AssetFlow.Domain.Dtos;

namespace AssetFlow.Application.Common.Services.Contracts
{
    public interface ITaxDetailService
    {
        Task<ResponseModel<AssetProcessDto?>> GetClearanceTaxSummary(GetClearanceTaxSummaryRequest request);
        Task<ResponseModel<AssetProcessDto?>> GetTaxSummariesByUniqueId(GetTaxSummariesByUniqueIdRequest request);
        Task<ResponseModel<List<AssetProcessDto>?>> GetTaxSummaries(GetSellTaxSummariesRequest request);
    }
}
