﻿namespace AssetFlow.Application.Common.Services.Contracts
{
    public interface ICdcWarehouseManagementService
    {
        Task<List<CustomerBalanceDto>> GetAllCustomerBalancesAsync(int warehouseId, DateTime dateTime);
        Task GetAllAndSaveAsync(int warehouseId, DateTime dateTime);
        Task<CustomerBalanceDto> GetCustomerBalanceAsync(long? uniqueId, int warehouseId, DateTime dateTime);


        Task<IReadOnlyList<CustomerAssetClearanceDto>> GetClearanceFromWarehouseManagement(int warehouseId);
        Task<IReadOnlyList<CustomerAssetEntryDto>> GetEntranceFromWarehouseManagement(int warehouseId);

    }

}
