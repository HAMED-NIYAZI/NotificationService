﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;

namespace AssetFlow.Application.Common.Services
{
    public class AssetTransactionProcessService : IAssetTransactionProcessService
    {
        private readonly Dictionary<AssetTransactionType, IAssetTransactionAllocatorService> _allocatorService;
        private readonly IValidator<Domain.Entities.AssetTransaction> _entryValidator;
        private readonly IAssetLogRepository _log;


        public AssetTransactionProcessService(IEnumerable<IAssetTransactionAllocatorService> allocatorService, IValidator<Domain.Entities.AssetTransaction> entryValidator)
        {
            _allocatorService = allocatorService.ToDictionary(x => x.Type, x => x);
            _entryValidator = entryValidator;
        }

        public async Task<bool> ProcessAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {
            if (!_allocatorService.TryGetValue(assetTransaction.Type, out IAssetTransactionAllocatorService? processor))
            {
                throw new NotSupportedException($"No processor registered for type '{assetTransaction.Type}'.");
            }

            ValidationResult resultValidate = await _entryValidator.ValidateAsync(assetTransaction);
            if (!resultValidate.IsValid)
            {
                await _log.LogIt(new AssetLog { Request = $"{assetTransaction.Id} {assetTransaction.UniqueId} {assetTransaction.WarehouseId} {assetTransaction.SymbolId}, assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "خطای ولیدیشن ValidationResult " });
                return false;
            }

            bool result = await processor.AllocateAsync_(assetTransaction, cancellationToken);
            return result;
        }
        public async Task<bool> ProcessAsyncInMemory(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context)
        {
            if (!_allocatorService.TryGetValue(assetTransaction.Type, out var processor))
            {
                throw new NotSupportedException($"No processor registered for type '{assetTransaction.Type}'.");
            }

            var resultValidate = await _entryValidator.ValidateAsync(assetTransaction);

            if (!resultValidate.IsValid)
            {
                await _log.LogIt(
                    new AssetLog
                    {
                        Request = $"{assetTransaction.Id} " + $"{assetTransaction.UniqueId} " + $"{assetTransaction.WarehouseId} " + $"{assetTransaction.SymbolId}",
                        UniqueId = assetTransaction.UniqueId,
                        Description = "خطای ValidationResult"
                    });

                return false;
            }

            return await processor.AllocateInMemoryAsync(assetTransaction, context);
        }
    }
}
