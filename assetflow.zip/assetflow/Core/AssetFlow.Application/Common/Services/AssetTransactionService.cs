﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace AssetFlow.Application.Common.Services
{
    public class AssetTransactionService : IAssetTransactionService
    {
        private readonly IAssetTransactionRepository _assetTransactionRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IAllocatorJob _allocatorJob;
        private readonly IAssetLogRepository _log;


        public AssetTransactionService(IAssetTransactionRepository assetTransactionRepository,
            IUnitOfWork unitOfWork, IAllocatorJob allocatorJob, IAssetLogRepository logRepository)
        {
            _assetTransactionRepository = assetTransactionRepository;
            _unitOfWork = unitOfWork;
            _allocatorJob = allocatorJob;
            _log = logRepository;
        }


        public async Task SaveAndAllocateTransactionSingle(List<Domain.Entities.AssetTransaction> transactions)
        {
            //    //اگر دیتایی وجود دارد که تاریخ ان از تاریخ این تراکنش بزرگتر است
            //    //باید ری بیلد صورت گیرد
            //    //تا تاریخ مورد نظر هرچه الوکیت هست باید پاک شود
            //    //و از همین تراکنش به بعد باید بیلد صورت گیرد
            foreach (var item in transactions)
            {
                await ProcessSingle(item);
            }
        }

        private async Task<List<Domain.Entities.AssetTransaction>?> GetYoungerDataAsync(Domain.Entities.AssetTransaction transaction)
        {
            return await _assetTransactionRepository.GetYoungerDataAsync(Convert.ToInt64(transaction.UniqueId), transaction.WarehouseId, transaction.AssetTransactionCreateDate);
        }

        private async Task RemoveFalseAllocatedData(List<Domain.Entities.AssetTransaction>? latestAssetTransactions)
        {
            await _assetTransactionRepository.RemoveFalseAllocatedData(latestAssetTransactions);
        }


        private async Task ProcessSingle(Domain.Entities.AssetTransaction transactions)
        {
            try
            {
                List<Domain.Entities.AssetTransaction>? latestAssetTransactions = await GetYoungerDataAsync(transactions);
                if (latestAssetTransactions != null && latestAssetTransactions?.Count > 0)
                {//c
                    await RemoveFalseAllocatedData(latestAssetTransactions);
                }
                var existTransaction = await _assetTransactionRepository.AnyAsync(x => x.UniqueId == transactions.UniqueId &&
                 x.TradeId == transactions.TradeId &&
                 x.WarehouseId == transactions.WarehouseId &&
                 x.SymbolId == transactions.SymbolId &&
                 x.Price == transactions.Price &&
                 x.Quantity == transactions.Quantity &&
                 x.ClearanceId == transactions.ClearanceId &&
                 x.EntranceId == transactions.EntranceId &&
                 x.Type == transactions.Type &&
                 x.UniqueId == transactions.UniqueId
                 );
                if (!existTransaction)
                {
                    await _assetTransactionRepository.AddAsync(transactions);
                    await _unitOfWork.SaveChangesAsync();

                    //BackgroundJob.Enqueue<IAssetTransactionRepository>(x => x.CheckAbnormalTransactionsAsync(transactions.UniqueId, transactions.WarehouseId, transactions.SymbolId));
                }
                await _allocatorJob.AllocateSingleAsync(Convert.ToInt64(transactions.UniqueId), transactions.WarehouseId, transactions.SymbolId);
            }
            catch (DbUpdateException ex)
            {
                if (ex.InnerException is SqlException sqlEx && (sqlEx.Number == 2601 || sqlEx.Number == 2627))
                {
                    _unitOfWork.Detach(transactions);

                    await _log.LogIt(ex, nameof(ProcessSingle));
                    return;
                }

                await _log.LogIt(ex, nameof(ProcessSingle));
            }
            catch (Exception ex)
            {
                await _log.LogIt(ex, nameof(ProcessSingle));
            }

        }

    }
}
