﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Domain.Contracts;
using AssetFlow.Domain.Entities;
using Newtonsoft.Json;

namespace AssetFlow.Application.Common.Services
{


    public class BuyAllocatorService : IAssetTransactionAllocatorService
    {
        private readonly IAssetAllocationRepository _assetAllocationRepository;
        private readonly IAssetTransactionRepository _assetTransactionRepository;
        private readonly IAssetLogRepository _log;
        private readonly IAllocationStateStore _allocationStateStore;



        public BuyAllocatorService(IAllocationStateStore allocationStateStore,
            IAssetAllocationRepository assetAllocationRepository,
             IAssetTransactionRepository assetTransactionRepository,
            IAssetLogRepository logRepository)
        {
            _assetAllocationRepository = assetAllocationRepository;
            _assetTransactionRepository = assetTransactionRepository;
            _log = logRepository;
            _allocationStateStore = allocationStateStore;
        }
        public AssetTransactionType Type => AssetTransactionType.Buy;

        public async Task<bool> AllocateAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {
            var allocationBlockKey = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);
            //Buy
            try
            {
                AssetEntry newAssetAllocation = new()
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.MarketBuy,
                    Description = "خرید از مارکت - افزایش موجودی از منشا مارکت",
                    SymbolId = assetTransaction.SymbolId,
                    TradeId = assetTransaction.TradeId ?? 0
                };
                AssetAllocation lastAssetBalanceSnapshot = await _assetAllocationRepository.GetLatestSnapshot(newAssetAllocation);

                var anyAvailableAllocationsHasConflict = !(lastAssetBalanceSnapshot is null) && lastAssetBalanceSnapshot.HasConflict;

                var hasYoungerUntouchedAssetTransactions = await _assetTransactionRepository.AnyAsync(x =>
                    x.AssetTransactionCreateDate < assetTransaction.AssetTransactionCreateDate &&
                    x.Status == AssetTransactionStatus.UnTouched);
                if (!hasYoungerUntouchedAssetTransactions && lastAssetBalanceSnapshot?.Id > 0)
                {
                    await _assetAllocationRepository.ResolveLatestSnapshotToHasConflict(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, assetTransaction.SymbolId);
                }
                else if (lastAssetBalanceSnapshot is not null && lastAssetBalanceSnapshot.Id > 0 && lastAssetBalanceSnapshot.AvailableQuantity < 0 || anyAvailableAllocationsHasConflict)
                {
                    if (!anyAvailableAllocationsHasConflict)
                    {
                        await _assetAllocationRepository.UpdateLatestSnapshotToHasConflict(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId, assetTransaction.SymbolId);

                        await _log.LogIt(new AssetLog { Request = $"lastAssetBalanceSnapshot is -minus  lastAssetBalanceSnapshot= {JsonConvert.SerializeObject(lastAssetBalanceSnapshot)}, lastAssetBalanceSnapshot.AvailableQuantity= {lastAssetBalanceSnapshot.AvailableQuantity} assetTransaction= {JsonConvert.SerializeObject(assetTransaction)}", UniqueId = assetTransaction.UniqueId, Description = "در زمان خرید از مارکت - افزایش موجودی از منشا مارکت . مقدار اخرین موجودی منفی است" });
                    }
                    await _allocationStateStore.BlockAsync(allocationBlockKey);

                    return false;
                }

                newAssetAllocation.AvailableQuantity = assetTransaction.Quantity + (lastAssetBalanceSnapshot?.AvailableQuantity ?? 0);

                await _assetAllocationRepository.Save(newAssetAllocation);

                assetTransaction.Status = AssetTransactionStatus.Committed;
                //await _assetTransactionRepository.UpdateStatusAsync(assetTransaction);
                await _allocationStateStore.Unblock(allocationBlockKey);
                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(allocationBlockKey);

                await _log.LogIt(ex, nameof(BuyAllocatorService), assetTransaction);
                return false;
            }
        }
        public async Task<bool> AllocateAsync_(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default)
        {
            var allocationBlockKey = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);
            //Buy
            try
            {
                AssetEntry newAssetAllocation = new()
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.MarketBuy,
                    Description = "خرید از مارکت - افزایش موجودی از منشا مارکت",
                    SymbolId = assetTransaction.SymbolId,
                    TradeId = assetTransaction.TradeId ?? 0
                };
                AssetAllocation lastAssetBalanceSnapshot = await _assetAllocationRepository.GetLatestSnapshot(newAssetAllocation);

                var anyAvailableAllocationsHasConflict = !(lastAssetBalanceSnapshot is null) && lastAssetBalanceSnapshot.HasConflict;


                newAssetAllocation.AvailableQuantity = assetTransaction.Quantity + (lastAssetBalanceSnapshot?.AvailableQuantity ?? 0);

                await _assetAllocationRepository.Save(newAssetAllocation);

                assetTransaction.Status = AssetTransactionStatus.Committed;
                await _allocationStateStore.Unblock(allocationBlockKey);
                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(allocationBlockKey);

                await _log.LogIt(ex, nameof(BuyAllocatorService), assetTransaction);
                return false;
            }
        }

        public async Task<bool> AllocateInMemoryAsync(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context)
        {
            var key = new AllocationStateKey(Convert.ToInt64(assetTransaction.UniqueId), assetTransaction.WarehouseId);
            try
            {
                var hasOlderUntouched = context.HasOlderUntouchedTransactions(assetTransaction);

                if (!hasOlderUntouched && context.LastSnapshot?.Id > 0)
                {
                    context.ResolveLastSnapshotConflict();
                }
                else if ((context.LastSnapshot?.Id > 0 && context.AvailableQuantity < 0) || context.HasConflict)
                {
                    if (!context.HasConflict)
                    {
                        context.LastSnapshot!.HasConflict = true;

                        await _log.LogIt(new AssetLog
                        {
                            Request = $"Buy blocked. " + $"Available={context.AvailableQuantity} " + $"Transaction={assetTransaction.Id}",

                            UniqueId = assetTransaction.UniqueId,

                            Description = "در زمان خرید از مارکت، موجودی آخرین Snapshot منفی است."
                        });
                    }

                    await _allocationStateStore.BlockAsync(key);

                    return false;
                }

                var newAssetEntry = new AssetEntry
                {
                    WarehouseId = assetTransaction.WarehouseId,
                    OriginalQuantity = assetTransaction.Quantity,
                    RemainingQuantity = assetTransaction.Quantity,
                    AvailableQuantity = assetTransaction.Quantity + context.AvailableQuantity,
                    UniqueId = assetTransaction.UniqueId,
                    AssetTransactionId = assetTransaction.Id,
                    AssetSourceType = AssetSourceType.MarketBuy,
                    Description = "خرید از مارکت - افزایش موجودی از منشا مارکت",
                    SymbolId = assetTransaction.SymbolId,
                    TradeId = assetTransaction.TradeId ?? 0
                };

                await _assetAllocationRepository.Save(newAssetEntry);
                context.AddEntry(newAssetEntry);

                assetTransaction.Status = AssetTransactionStatus.Committed;

                await _allocationStateStore.Unblock(key);

                return true;
            }
            catch (Exception ex)
            {
                await _allocationStateStore.BlockAsync(key);

                await _log.LogIt(ex, nameof(BuyAllocatorService), assetTransaction);

                return false;
            }
        }

    }

}
