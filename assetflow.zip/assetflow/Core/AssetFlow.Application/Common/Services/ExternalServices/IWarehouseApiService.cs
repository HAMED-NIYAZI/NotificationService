﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services.ExternalServices;

public interface IWarehouseApiService
{
    Task<IReadOnlyList<WarehouseCustomerClearance>> GetCustomersClearances(DateTime dateFrom, DateTime dateTo);
    Task<IReadOnlyList<WarehouseCustomerEntrance>> GetCustomersEntrances(DateTime dateFrom, DateTime dateTo);


}