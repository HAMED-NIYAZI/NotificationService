﻿using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.Common.Services.ExternalServices;

public interface IMarketService
{
    Task<IReadOnlyList<MarketCustomerClearance>> GetCustomersClearances(DateTime dateFrom, DateTime dateTo);
}