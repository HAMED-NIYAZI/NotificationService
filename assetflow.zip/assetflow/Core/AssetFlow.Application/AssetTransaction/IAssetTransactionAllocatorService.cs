﻿using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Domain.Entities;

namespace AssetFlow.Application.AssetTransaction
{
    public interface IAssetTransactionAllocatorService
    {
        AssetTransactionType Type { get; }
        Task<bool> AllocateAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default);
        Task<bool> AllocateAsync_(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default);
        Task<bool> AllocateInMemoryAsync(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context);
    }
}
