﻿namespace AssetFlow.Application.AssetTransaction.Dtos;

public class ExitAssetTransactionSaveDto : AssetTransactionSaveDtoBase
{
}
