﻿namespace AssetFlow.Application.AssetTransaction.Dtos;

public class EntryAssetTransactionSaveDto : AssetTransactionSaveDtoBase
{
}
