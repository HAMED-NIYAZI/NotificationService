﻿using Microsoft.AspNetCore.Http;
using System.Net;

namespace AssetFlow.Application.AssetTransaction.Dtos;

public class ResponseModel<T>
{
    public bool IsSuccess { get; set; }
    public int Count { get; set; }
    public string? Message { get; set; }
    public T? Data { get; set; }
    public int StatusCode { get; set; } = StatusCodes.Status200OK;

    public static ResponseModel<T> AccessIsDeniedResponse(string message = "Access is denied.")
    {
        var newResponse = new ResponseModel<T>() { Data = default, Message = message ?? "Access is denied.", IsSuccess = false, Count = 0, StatusCode = StatusCodes.Status403Forbidden };
        return newResponse;
    }
    public static ResponseModel<T> InputBadResponse(string message = "Bad Request.")
    {
        var newResponse = new ResponseModel<T>() { Data = default, Message = message ?? "Bad Request.", IsSuccess = false, Count = 0, StatusCode = StatusCodes.Status400BadRequest };
        return newResponse;
    }
    public static ResponseModel<T> InputNullResponse()
    {
        var newResponse = new ResponseModel<T>() { Data = default, Message = "Input model is null.", IsSuccess = false, Count = 0, StatusCode = StatusCodes.Status400BadRequest };
        return newResponse;
    }
    public static ResponseModel<T> SuccessResponse(T data, int count = 1)
    {
        var newResponse = new ResponseModel<T>() { Data = data, Message = "Successful.", IsSuccess = true, Count = count, StatusCode = StatusCodes.Status200OK };
        return newResponse;
    }

    public static ResponseModel<T> NotFoundResponse(string message = "Not found.")
    {
        var newResponse = new ResponseModel<T>() { Data = default, Message = message ?? "Not found.", IsSuccess = false, Count = 0, StatusCode = StatusCodes.Status404NotFound };
        return newResponse;
    }

    public static ResponseModel<T> InternalServerErrorResponse(string message = "Internal Server Error 500.")
    {
        var newResponse = new ResponseModel<T>() { Data = default, Message = message ?? "Internal Server Error 500.", IsSuccess = false, Count = 0, StatusCode = StatusCodes.Status500InternalServerError };
        return newResponse;
    }

    public static ResponseModel<T> Result(T? data, int count = 0, string? message = "", bool isSuccess = false, int statusCode = StatusCodes.Status200OK)
    {
        var newResponse = new ResponseModel<T>() { Data = data, Count = count, Message = message, IsSuccess = isSuccess, StatusCode = statusCode };
        return newResponse;
    }
    public static ResponseModel<T> Failed(T data, int count = 0, string message = "", bool isSuccess = false, int statusCode = StatusCodes.Status400BadRequest)
    {
        var newResponse = new ResponseModel<T>() { Data = data, Count = count, Message = message, IsSuccess = isSuccess, StatusCode = statusCode };
        return newResponse;
    }

}



public class ResponseDto<T>
{
    public string? Message { get; set; }
    public T? Data { get; set; }
    public int StatusCode { get; set; } = 200;


    public static ResponseDto<T> AccessIsDeniedResponse(string message = "Access is denied.")
    {
        var newResponse = new ResponseDto<T>() { Data = default, Message = message ?? "Access is denied.", StatusCode = StatusCodes.Status403Forbidden };
        return newResponse;
    }
    public static ResponseDto<T> InputBadResponse(string message = "Bad Request.")
    {
        var newResponse = new ResponseDto<T>() { Data = default, Message = message ?? "Bad Request.", StatusCode = StatusCodes.Status400BadRequest };
        return newResponse;
    }
    public static ResponseDto<T> InputNullResponse()
    {
        var newResponse = new ResponseDto<T>() { Data = default, Message = "Input model is null.", StatusCode = StatusCodes.Status400BadRequest };
        return newResponse;
    }
    public static ResponseDto<T> SuccessResponse(T data)
    {
        var newResponse = new ResponseDto<T>() { Data = data, Message = "Successful.", StatusCode = StatusCodes.Status200OK };
        return newResponse;
    }

    public static ResponseDto<T> NotFoundResponse(string message = "Not found.")
    {
        var newResponse = new ResponseDto<T>() { Data = default, Message = message ?? "Not found.", StatusCode = StatusCodes.Status404NotFound };
        return newResponse;
    }

    public static ResponseDto<T> InternalServerErrorResponse(string message = "Internal Server Error 500.")
    {
        var newResponse = new ResponseDto<T>() { Data = default, Message = message ?? "Internal Server Error 500.", StatusCode = StatusCodes.Status500InternalServerError };
        return newResponse;
    }

    public static ResponseDto<T> Result(T data, string message = "", int statusCode = StatusCodes.Status200OK)
    {
        var newResponse = new ResponseDto<T>() { Data = data, Message = message, StatusCode = statusCode };
        return newResponse;
    }
    public static ResponseDto<T> Failed(T data, string message = "", int statusCode = StatusCodes.Status400BadRequest)
    {
        var newResponse = new ResponseDto<T>() { Data = data, Message = message, StatusCode = statusCode };
        return newResponse;
    }
}



public class RequestDto<T>
{
    public int CallerUserId { get; set; }
    public T? Data { get; set; }
    public string ExMessage { get; set; }

    public int Status { get; set; }
    public int Count { get; set; }

    public string? Message { get; set; }
    public string Request { get; set; }
    public ResponseModel<T> Response { get; set; }

    public RequestDto()
    {
        Data = default;
        ExMessage = string.Empty;
        Status = 404;
        Count = 0;
        Message = string.Empty;
        Request = string.Empty;
        Response = new ResponseModel<T>();
    }

    public void GetSqlExceptionResult(string exMessage)
    {
        ExMessage = exMessage;
        Status = (int)HttpStatusCode.BadRequest;
        Message = exMessage;
        Data = default;

    }






    public void GetIsNotSuccessFullResult(int? statusCode, string? _message)
    {
        Status = (int)(statusCode > 0 ? statusCode : StatusCodes.Status404NotFound);
        Message = _message;
        Data = default;
    }


}
