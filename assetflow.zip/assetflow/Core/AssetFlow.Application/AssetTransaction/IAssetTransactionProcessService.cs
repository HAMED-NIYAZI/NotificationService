﻿using AssetFlow.Application.Common.Services.BackgroundJobs;

namespace AssetFlow.Application.AssetTransaction
{
    public interface IAssetTransactionProcessService
    {
        Task<bool> ProcessAsync(Domain.Entities.AssetTransaction assetTransaction, CancellationToken cancellationToken = default);
        Task<bool> ProcessAsyncInMemory(Domain.Entities.AssetTransaction assetTransaction, AllocationWorkContext context);
    }
}
