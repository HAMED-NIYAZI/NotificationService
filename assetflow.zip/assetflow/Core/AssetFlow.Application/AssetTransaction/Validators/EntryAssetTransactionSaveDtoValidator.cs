﻿using AssetFlow.Application.AssetTransaction.Dtos;
using FluentValidation;

namespace AssetFlow.Application.AssetTransaction.Validators
{
    public class EntryAssetTransactionSaveDtoValidator : AbstractValidator<EntryAssetTransactionSaveDto>
    {
        public EntryAssetTransactionSaveDtoValidator()
        {
            RuleFor(x => x.UniqueId).GreaterThan(0);
            RuleFor(x => x.SymbolId).GreaterThan(0);
            RuleFor(x => x.WarehouseId).GreaterThan(0);
            RuleFor(x => x.Quantity).GreaterThan(0);
            RuleFor(x => x.AssetTransactionCreateDate).NotEmpty();
        }
    }
}
