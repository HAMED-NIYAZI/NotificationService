﻿using AssetFlow.Application.AssetTransaction.Dtos;
using FluentValidation;

namespace AssetFlow.Application.AssetTransaction.Validators
{
    public class ExitAssetTransactionSaveDtoValidator : AbstractValidator<ExitAssetTransactionSaveDto>
    {
        public ExitAssetTransactionSaveDtoValidator()
        {
            RuleFor(x => x.UniqueId).GreaterThan(0);
            RuleFor(x => x.SymbolId).GreaterThan(0);
            RuleFor(x => x.WarehouseId).GreaterThan(0);
            RuleFor(x => x.Quantity).GreaterThan(0);
            RuleFor(x => x.AssetTransactionCreateDate).NotEmpty();
        }
    }
}
