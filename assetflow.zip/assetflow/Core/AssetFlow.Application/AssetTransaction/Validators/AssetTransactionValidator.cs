﻿using AssetFlow.Domain.Entities;
using FluentValidation;

namespace AssetFlow.Application.AssetTransaction.Validators
{
    public class AssetTransactionValidator : AbstractValidator<Domain.Entities.AssetTransaction>
    {
        public AssetTransactionValidator()
        {
            RuleFor(x => x.UniqueId).GreaterThan(0).WithMessage("AssetTransaction UniqueId be GreaterThan 0.");
            RuleFor(x => x.CustomerId).GreaterThan(0).WithMessage("AssetTransaction UniqueId be GreaterThan 0.");
            RuleFor(x => x.SymbolId).GreaterThan(0).WithMessage("AssetTransaction SymbolId must be GreaterThan 0.");
            RuleFor(x => x.WarehouseId).GreaterThan(0).WithMessage("AssetTransaction WarehouseId must be GreaterThan 0.");
            RuleFor(x => x.Quantity).GreaterThan(0).WithMessage("AssetTransaction Quantity must be GreaterThan 0.");
            RuleFor(x => x.AssetTransactionCreateDate).NotEmpty().WithMessage("AssetTransactionCreateDate is required.");
            RuleFor(x => x.Type).IsInEnum().WithMessage("AssetTransaction Type is invalid.");
            RuleFor(x => x.Status).Equal(AssetTransactionStatus.UnTouched).WithMessage("AssetTransaction Status must be equal to UnTouched.");

            RuleFor(x => x.TradeId)
                           .GreaterThan(0)
                           .When(x => x.Type is AssetTransactionType.Buy or AssetTransactionType.Sell)
                           .WithMessage("TradeId must be greater than zero for Buy or Sell transactions.");

            RuleFor(x => x.EntranceId)
                           .GreaterThan(0)
                           .When(x => x.Type == AssetTransactionType.Entry)
                           .WithMessage("EntranceId must be greater than zero for Entry transactions.");

            RuleFor(x => x.ClearanceId)
                           .GreaterThan(0)
                           .When(x => x.Type == AssetTransactionType.Clearance)
                           .WithMessage("ClearanceId must be greater than zero for Clearance transactions.");

            RuleFor(x => x.Price)
                           .GreaterThanOrEqualTo(0)
                           .WithMessage("AssetTransaction Price is invalid.");


        }
    }
}
