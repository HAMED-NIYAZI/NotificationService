﻿namespace AssetFlow.Application.AssetTransaction
{
    public interface IAssetTransactionService
    {
        Task SaveAndAllocateTransactionSingle(List<Domain.Entities.AssetTransaction> transactions);
    }
}
