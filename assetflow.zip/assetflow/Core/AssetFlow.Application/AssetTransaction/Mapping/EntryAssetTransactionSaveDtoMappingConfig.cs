﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Domain.Entities;
using Mapster;

namespace AssetFlow.Application.AssetTransaction.Mapping
{
    public class EntryAssetTransactionSaveDtoMappingConfig : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
            config.NewConfig<Domain.Entities.AssetTransaction, EntryAssetTransactionSaveDto>();


            config.NewConfig<CdcTrade, EntryAssetTransactionSaveDto>()
                .Map(destination => destination.Type, source => AssetTransactionType.Buy)
                .Map(destination => destination.Status, source => AssetTransactionStatus.UnTouched)
                .Map(destination => destination.Direction, source => AssetDirection.In)
                .Map(destination => destination.Quantity, source => source.Count)
                .Map(destination => destination.SymbolId, source => source.ContractID)
                .Map(destination => destination.TradeId, source => source.TradeID)
                .Map(destination => destination.CustomerId, source => source.BuyerCustomerID)
                .Map(destination => destination.AssetTransactionCreateDate, source => source.RecCreateTime);

            config.NewConfig<WarehouseCustomerEntrance, EntryAssetTransactionSaveDto>()
                .Map(destination => destination.Type, source => AssetTransactionType.Entry)
                .Map(destination => destination.Status, source => AssetTransactionStatus.UnTouched)
                .Map(destination => destination.Direction, source => AssetDirection.In)
                .Map(destination => destination.Quantity, source => source.assetQuantity)
                .Map(destination => destination.WarehouseId, source => source.warehouseGroupID)
                 .Map(destination => destination.EntranceId, source => source.WarehouseCustomerEntranceId)
                .Map(destination => destination.UniqueId, source => source.uniqueID)
                .Map(destination => destination.AssetTransactionCreateDate, source => source.receiveTime);


        }
    }
}
