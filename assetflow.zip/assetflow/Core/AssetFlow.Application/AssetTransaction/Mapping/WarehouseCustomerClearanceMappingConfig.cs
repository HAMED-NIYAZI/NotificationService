﻿using AssetFlow.Application.Common.Services;
using AssetFlow.Domain.Entities;
using Mapster;

namespace AssetFlow.Application.AssetTransaction.Mapping
{
    public class WarehouseCustomerClearanceMappingConfig : IRegister
    {

        public void Register(TypeAdapterConfig config)
        {

            config.NewConfig<CustomerAssetClearanceDto, WarehouseCustomerClearance>()
                 .Map(destination => destination.executedQuantity, source => source.amount)
                 .Map(destination => destination.referenceId, source => Convert.ToInt64(source.referenceId))
                 .Map(destination => destination.warehouseGroupID, source => source.warehouseGroupId)
                .Map(destination => destination.uniqueID, source => source.assetOwnerUniqueCode)
                .Map(destination => destination.WarehouseCustomerClearanceId, source => source.transactionId)
                .Map(destination => destination.receiveTime, source => source.date);

            config.NewConfig<WarehouseCustomerClearance, CustomerAssetClearanceDto>()
                .Map(destination => destination.amount, source => source.executedQuantity)
                .Map(destination => destination.referenceId, source => source.referenceId.ToString())
                .Map(destination => destination.warehouseGroupId, source => source.warehouseGroupID)
               .Map(destination => destination.assetOwnerUniqueCode, source => source.uniqueID)
               .Map(destination => destination.transactionId, source => source.WarehouseCustomerClearanceId)
               .Map(destination => destination.date, source => source.receiveTime);



            config.NewConfig<CustomerAssetEntryDto, WarehouseCustomerEntrance>()
                 .Map(destination => destination.assetQuantity, source => source.amount)
                                  .Map(destination => destination.warehouseGroupID, source => source.warehouseGroupId)
                .Map(destination => destination.uniqueID, source => source.assetOwnerUniqueCode)
                .Map(destination => destination.WarehouseCustomerEntranceId, source => source.transactionId)
                .Map(destination => destination.receiveTime, source => source.date);

            config.NewConfig<WarehouseCustomerEntrance, CustomerAssetEntryDto>()
                .Map(destination => destination.amount, source => source.assetQuantity)
                .Map(destination => destination.warehouseGroupId, source => source.warehouseGroupID)
               .Map(destination => destination.assetOwnerUniqueCode, source => source.uniqueID)
               .Map(destination => destination.transactionId, source => source.WarehouseCustomerEntranceId)
               .Map(destination => destination.date, source => source.receiveTime);

        }
    }

}
