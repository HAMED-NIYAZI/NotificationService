﻿namespace AssetFlow.Application.AssetTransaction.Mapping;

public class AssemblyReference() { }
