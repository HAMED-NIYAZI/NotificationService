﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Domain.Entities;
using Mapster;

namespace AssetFlow.Application.AssetTransaction.Mapping
{


    public class ExitAssetTransactionSaveDtoMappingConfig : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
            config.NewConfig<Domain.Entities.AssetTransaction, ExitAssetTransactionSaveDto>();

            config.NewConfig<CdcTrade, ExitAssetTransactionSaveDto>()
                 .Map(destination => destination.Type, source => AssetTransactionType.Sell)
                 .Map(destination => destination.Status, source => AssetTransactionStatus.UnTouched)
                 .Map(destination => destination.Direction, source => AssetDirection.Out)
                 .Map(destination => destination.Quantity, source => source.Count)
                 .Map(destination => destination.SymbolId, source => source.ContractID)
                 .Map(destination => destination.TradeId, source => source.TradeID)
                 .Map(destination => destination.CustomerId, source => source.SellerCustomerID)
                 .Map(destination => destination.AssetTransactionCreateDate, source => source.RecCreateTime);



            config.NewConfig<ClearanceWarehouse, ExitAssetTransactionSaveDto>()
                 .Map(destination => destination.Type, source => AssetTransactionType.Clearance)
                 .Map(destination => destination.Status, source => AssetTransactionStatus.UnTouched)
                 .Map(destination => destination.Direction, source => AssetDirection.Out)
                 .Map(destination => destination.Quantity, source => source.ExecutedQuantity)
                 .Map(destination => destination.WarehouseId, source => source.Warehouse_ResponseID)
                 .Map(destination => destination.UniqueId, source => source.UniqueID)
                 .Map(destination => destination.ClearanceId, source => source.Id)
                 .Map(destination => destination.AssetTransactionCreateDate, source => source.ReceiveTime);


            config.NewConfig<WarehouseCustomerClearance, ExitAssetTransactionSaveDto>()
                 .Map(destination => destination.Type, source => AssetTransactionType.Clearance)
                 .Map(destination => destination.Status, source => AssetTransactionStatus.UnTouched)
                 .Map(destination => destination.Direction, source => AssetDirection.Out)
                 .Map(destination => destination.Quantity, source => source.executedQuantity)
                 .Map(destination => destination.WarehouseId, source => source.warehouseGroupID)
                  .Map(destination => destination.ClearanceId, source => source.WarehouseCustomerClearanceId)
                 .Map(destination => destination.AssetTransactionCreateDate, source => source.receiveTime)
                 .Map(destination => destination.ReferenceId, source => source.referenceId)
                 .Map(destination => destination.UniqueId, source => source.uniqueID);



        }
    }
}


