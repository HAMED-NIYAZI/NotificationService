﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetClearanceTaxSummary
{
    public class GetClearanceTaxSummaryCommand : IRequest<ResponseModel<AssetProcessDto?>>
    {
        public long ReferenceId { get; set; }
        public decimal FromAmount { get; set; }
        public decimal ToAmount { get; set; }
    }
}
