﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetClearanceTaxSummary
{
    public class GetClearanceTaxSummaryCommandHandler : IRequestHandler<GetClearanceTaxSummaryCommand, ResponseModel<AssetProcessDto?>>
    {
        private readonly ITaxDetailService _taxDetailService;

        public GetClearanceTaxSummaryCommandHandler(ITaxDetailService taxDetailService)
        {
            _taxDetailService = taxDetailService;
        }


        public async Task<ResponseModel<AssetProcessDto?>> Handle(GetClearanceTaxSummaryCommand request, CancellationToken cancellationToken)
        {
            ResponseModel<AssetProcessDto?> result = await _taxDetailService.GetClearanceTaxSummary(new Dtos.GetClearanceTaxSummaryRequest { ReferenceId = request.ReferenceId, FromAmount = request.FromAmount, ToAmount = request.ToAmount });
            return result;
        }
    }
}
