﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetTaxSummaries
{
    public class GetTaxSummariesCommandHandler : IRequestHandler<GetTaxSummariesCommand, ResponseModel<List<AssetProcessDto>?>>
    {
        private readonly ITaxDetailService _taxDetailService;

        public GetTaxSummariesCommandHandler(ITaxDetailService taxDetailService)
        {
            _taxDetailService = taxDetailService;
        }


        public async Task<ResponseModel<List<AssetProcessDto>?>> Handle(GetTaxSummariesCommand request, CancellationToken cancellationToken)
        {
            ResponseModel<List<AssetProcessDto>?> result = await _taxDetailService.GetTaxSummaries(new Dtos.GetSellTaxSummariesRequest { WarehouseGroupId = request.WarehouseGroupId, TaxDate = request.Date });
            return result;
        }
    }
}
