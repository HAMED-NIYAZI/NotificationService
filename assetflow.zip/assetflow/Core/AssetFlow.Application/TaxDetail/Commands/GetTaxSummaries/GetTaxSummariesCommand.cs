﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetTaxSummaries
{
    public class GetTaxSummariesCommand : IRequest<ResponseModel<List<AssetProcessDto>?>>
    {
        public int WarehouseGroupId { get; set; }
        public DateTime Date { get; set; }
    }
}
