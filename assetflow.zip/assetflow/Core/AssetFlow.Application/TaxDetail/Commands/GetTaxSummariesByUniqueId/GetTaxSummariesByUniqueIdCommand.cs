﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetTaxSummariesByUniqueId
{
    public class GetTaxSummariesByUniqueIdCommand : IRequest<ResponseModel<AssetProcessDto>>
    {
        public long UniqueId { get; set; }
        public long ReferenceId { get; set; }
    }
}
