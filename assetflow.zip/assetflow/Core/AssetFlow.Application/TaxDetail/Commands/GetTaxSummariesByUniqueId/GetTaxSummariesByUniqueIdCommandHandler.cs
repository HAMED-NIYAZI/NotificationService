﻿using AssetFlow.Application.AssetTransaction.Dtos;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Domain.Dtos;
using MediatR;

namespace AssetFlow.Application.TaxDetail.Commands.GetTaxSummariesByUniqueId
{
    public class GetTaxSummariesByUniqueIdCommandHandler : IRequestHandler<GetTaxSummariesByUniqueIdCommand, ResponseModel<AssetProcessDto>>
    {
        private readonly ITaxDetailService _taxDetailService;

        public GetTaxSummariesByUniqueIdCommandHandler(ITaxDetailService taxDetailService)
        {
            _taxDetailService = taxDetailService;
        }

        public async Task<ResponseModel<AssetProcessDto>> Handle(GetTaxSummariesByUniqueIdCommand request, CancellationToken cancellationToken)
        {
            ResponseModel<AssetProcessDto> AssetProcess = await _taxDetailService.GetTaxSummariesByUniqueId(new Dtos.GetTaxSummariesByUniqueIdRequest { UniqueId = request.UniqueId, ReferenceId = request.ReferenceId });
            return AssetProcess;
        }
    }
}
