﻿namespace AssetFlow.Application.TaxDetail.Dtos
{
    public class GetTaxSummariesByUniqueIdRequest
    {
        public long UniqueId { get; set; }
        public long ReferenceId { get; set; }
    };
}
