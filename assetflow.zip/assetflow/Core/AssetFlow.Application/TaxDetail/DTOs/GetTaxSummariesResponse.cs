﻿namespace AssetFlow.Application.TaxDetail.Dtos
{
    public class GetTaxSummariesResponse
    {
        public int UniqueId { get; set; }
        public int NationalId { get; set; }
        public int TaxCode { get; set; }//202501010010100
        public int TaxType { get; set; } //SELL Exit
        public int SumValue { get; set; } //price
        public int SumCount { get; set; } //qty
        public int AveragePrice { get; set; } // settelmentPrice
        public int WarehouseGroupId { get; set; }
        public int PersianTaxDate { get; set; }
        public int TaxDate { get; set; }
        public int ReferenceId { get; set; }

    }
}
