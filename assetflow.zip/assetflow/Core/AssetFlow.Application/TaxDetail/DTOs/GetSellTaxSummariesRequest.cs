﻿namespace AssetFlow.Application.TaxDetail.Dtos;

public class GetSellTaxSummariesRequest
{
    public int WarehouseGroupId { get; set; }
    public DateTime TaxDate { get; set; }
}
