﻿namespace AssetFlow.Application.TaxDetail.Dtos;

public class GetClearanceTaxSummaryRequest
{
    public long ReferenceId { get; set; }
    public decimal FromAmount { get; set; }
    public decimal ToAmount { get; set; }
};
