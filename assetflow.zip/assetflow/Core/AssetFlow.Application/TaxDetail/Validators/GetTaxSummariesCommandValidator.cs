﻿using AssetFlow.Application.TaxDetail.Commands.GetTaxSummaries;
using FluentValidation;

namespace AssetFlow.Application.TaxDetail.Validators
{
    public class GetTaxSummariesCommandValidator : AbstractValidator<GetTaxSummariesCommand>
    {
        public GetTaxSummariesCommandValidator()
        {
            RuleFor(x => x.WarehouseGroupId).GreaterThan(0).WithMessage("ReferenceId must be GreaterThan 0.");
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date must not be empty.")
                .NotEqual(default(DateTime))
                .WithMessage("Date must not be empty.");
        }



    }
}
