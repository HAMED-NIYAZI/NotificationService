﻿using AssetFlow.Application.TaxDetail.Commands.GetTaxSummariesByUniqueId;
using FluentValidation;

namespace AssetFlow.Application.TaxDetail.Validators
{
    public class GetTaxSummariesByUniqueIdCommandValidator : AbstractValidator<GetTaxSummariesByUniqueIdCommand>
    {
        public GetTaxSummariesByUniqueIdCommandValidator()
        {
            RuleFor(x => x.ReferenceId).GreaterThan(0).WithMessage("ReferenceId must be GreaterThan 0.");
            RuleFor(x => x.UniqueId).GreaterThan(0).WithMessage("UniqueId must be GreaterThan 0.");
        }
    }
}
