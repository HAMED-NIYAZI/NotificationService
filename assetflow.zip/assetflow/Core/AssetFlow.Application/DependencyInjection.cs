﻿using AssetFlow.Application.AssetTransaction;
using AssetFlow.Application.Common.Behaviors;
using AssetFlow.Application.Common.Services;
using AssetFlow.Application.Common.Services.BackgroundJobs;
using AssetFlow.Application.Common.Services.Contracts;
using AssetFlow.Application.Common.Services.Contracts.BackgroundJobs;
using AssetFlow.Application.Common.Services.ExternalServices;
using FluentValidation;
using Mapster;
using MapsterMapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Client;
using System.Reflection;

namespace AssetFlow.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<IAssetTransactionService, AssetTransactionService>();
        services.AddScoped<IAssetTransactionProcessService, AssetTransactionProcessService>();
        services.AddScoped<IAssetTransactionAllocatorService, BuyAllocatorService>();
        services.AddScoped<IAssetTransactionAllocatorService, EntryAllocatorService>();
        services.AddScoped<IAssetTransactionAllocatorService, SellAllocatorService>();
        services.AddScoped<IAssetTransactionAllocatorService, ClearanceAllocatorService>();
        services.AddScoped<ITaxDetailService, TaxDetailService>();
        services.AddScoped<IWarehouseGroupTaxRule, WarehouseGroupTaxRule>();
        services.AddScoped<IRule, WarehouseGroupSellTaxRule>();
        services.AddScoped<IRule, WarehouseGroupClearanceTaxRule>();
        services.AddScoped<ICdcWarehouseManagementService, CdcWarehouseManagementService>();
        services.AddScoped<ISyncClearanceAndEntranceFromMarket, SyncClearanceAndEntranceFromMarket>();

        services.AddHttpClient("WarehouseClient", client =>
        {
            client.BaseAddress = new Uri("https://whmapp.ime.co.ir:8080");
            client.DefaultRequestHeaders.Add("accept", "text/plain");
        })
        .ConfigurePrimaryHttpMessageHandler(() =>
        {
            var handler = new HttpClientHandler();
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;
            return handler;
        });




        services.Configure<MarketApiOptions>(configuration.GetSection("MarketApi"));
        services.AddHttpClient<IMarketService, MarketService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<MarketApiOptions>>().Value;
            client.BaseAddress = new Uri(options.BaseUrl);
            client.Timeout = TimeSpan.FromSeconds(60);
        });



        services.AddScoped<IRecurringJobScheduler, HangfireRecurringJobScheduler>();
        services.AddScoped<ISyncAllDataJob, SyncAllDataJob>();
        services.AddScoped<IAllocatorJob, AllocatorJob>();
        services.AddSingleton<IGroupJobRegistry, InMemoryGroupJobRegistry>();
        services.AddScoped<ISyncDataAndAllocateCustomerJob, SyncDataAndAllocateCustomerJob>();
        services.AddScoped<ISyncSettelmentPriceJob, SyncSettelmentPriceJob>();
        services.AddScoped<ISyncClearanceAndEntranceFromWarehouse, SyncClearanceAndEntranceFromWarehouse>();


        services.AddMapster();
        var config = TypeAdapterConfig.GlobalSettings;
        config.Scan(typeof(AssetTransaction.Mapping.AssemblyReference).Assembly);
        services.AddSingleton(config);
        services.AddScoped<IMapper, ServiceMapper>();





        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        services.AddMediatR(cfg =>
       {
           cfg.RegisterServicesFromAssembly(typeof(DependencyInjection).Assembly);
       });


        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));


        return services;
    }



}